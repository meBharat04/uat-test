package com.dell.webservice.scim.ansira;

import com.dell.webservice.scim.ansira.api.AnsiraHttpLoggingInterceptor;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpResponse;

import java.io.ByteArrayInputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class AnsiraHttpLoggingInterceptorTest {

    @Test
    void disabled_passesThroughWithoutReadingResponseBody() throws Exception {
        HttpRequest request = mockRequest();
        byte[] body = "req-body".getBytes(StandardCharsets.UTF_8);
        ClientHttpResponse expectedResponse = mock(ClientHttpResponse.class);
        ClientHttpRequestExecution execution = mock(ClientHttpRequestExecution.class);
        when(execution.execute(any(), any())).thenReturn(expectedResponse);

        AnsiraHttpLoggingInterceptor interceptor = new AnsiraHttpLoggingInterceptor(() -> false);
        ClientHttpResponse actual = interceptor.intercept(request, body, execution);

        assertSame(expectedResponse, actual);
        verify(execution, times(1)).execute(request, body);
        // Disabled path must never touch the response body — getBody() should be untouched.
        verify(expectedResponse, times(0)).getBody();
    }

    @Test
    void enabled_stillReturnsResponseUnchangedAndBodyRemainsReadable() throws Exception {
        HttpRequest request = mockRequest();
        byte[] body = "req-body".getBytes(StandardCharsets.UTF_8);

        String responseBody = "resp-body";
        ClientHttpResponse response = mock(ClientHttpResponse.class);
        when(response.getBody()).thenReturn(new ByteArrayInputStream(responseBody.getBytes(StandardCharsets.UTF_8)));
        when(response.getStatusCode()).thenReturn(HttpStatusCode.valueOf(200));

        ClientHttpRequestExecution execution = mock(ClientHttpRequestExecution.class);
        when(execution.execute(any(), any())).thenReturn(response);

        AnsiraHttpLoggingInterceptor interceptor = new AnsiraHttpLoggingInterceptor(() -> true);
        ClientHttpResponse actual = interceptor.intercept(request, body, execution);

        assertSame(response, actual);
        verify(execution, times(1)).execute(request, body);
    }

    @Test
    void enabled_toleratesNullOrEmptyRequestBody() throws Exception {
        HttpRequest request = mockRequest();
        ClientHttpResponse response = mock(ClientHttpResponse.class);
        when(response.getBody()).thenReturn(new ByteArrayInputStream(new byte[0]));
        when(response.getStatusCode()).thenReturn(HttpStatusCode.valueOf(204));

        ClientHttpRequestExecution execution = mock(ClientHttpRequestExecution.class);
        when(execution.execute(any(), any())).thenReturn(response);

        AnsiraHttpLoggingInterceptor interceptor = new AnsiraHttpLoggingInterceptor(() -> true);
        // GET requests are called with an empty body in AnsiraConnectorApi's outbound
        // calls — must not NPE.
        ClientHttpResponse actual = interceptor.intercept(request, new byte[0], execution);

        assertSame(response, actual);
    }

    private static HttpRequest mockRequest() {
        HttpRequest request = mock(HttpRequest.class);
        when(request.getMethod()).thenReturn(HttpMethod.GET);
        when(request.getURI()).thenReturn(URI.create("https://api.ansiraservices.com/prod/v1/identity-api/core/identity/Account"));
        return request;
    }
}
