package com.dell.webservice.scim.ansira;

import tools.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.dell.webservice.scim.ansira.api.AnsiraConnectorApi;
import com.dell.webservice.scim.ansira.mapper.AnsiraMapper;
import com.okta.ps.scim.pojos.Name;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import org.apache.hc.client5.http.auth.StandardAuthScheme;
import org.apache.hc.client5.http.config.Configurable;
import org.apache.hc.client5.http.config.RequestConfig;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.containing;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.put;
import static com.github.tomakehurst.wiremock.client.WireMock.putRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AnsiraConnectorApiTest {

    private WireMockServer wm;
    private AnsiraConnectorApi api;

    private static final String API_KEY = "test-api-key";

    @BeforeEach
    void setUp() {
        wm = new WireMockServer(WireMockConfiguration.wireMockConfig().dynamicPort());
        wm.start();

        ObjectMapper objectMapper = new ObjectMapper();
        AnsiraMapper mapper = new AnsiraMapper(objectMapper);
        api = new AnsiraConnectorApi(mapper, objectMapper, "http://localhost:" + wm.port(), API_KEY);
    }

    @AfterEach
    void tearDown() {
        wm.stop();
    }

    // ---- auth: X-API-KEY forwarded, never minted ---------------------------

    @Test
    void getUsers_sendsApiKeyAsHeader_notBearerToken() {
        wm.stubFor(get(urlPathEqualTo("/Account"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"data\":[]}")));

        api.getUsers(1, 50, null);

        wm.verify(getRequestedFor(urlPathEqualTo("/Account"))
                .withHeader("X-API-KEY", equalTo(API_KEY)));
    }

    // ---- getUsers -----------------------------------------------------------

    @Test
    void getUsers_mapsFullList() {
        wm.stubFor(get(urlPathEqualTo("/Account"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":[
                                  {"userName":"1000123","firstName":"Alex","lastName":"Synthetic",
                                   "emailAddress":"alex.synthetic@example.com","title":"Sales Rep",
                                   "isActive":true,"groupId":"3010","groupName":"Sales Standard"},
                                  {"userName":"1000456","firstName":"Jordan","lastName":"Synthetic",
                                   "isActive":true,"groupId":"3020","groupName":"Sales Manager"}
                                ]}
                                """)));

        List<ScimUserV2> users = api.getUsers(1, 50, null);
        assertEquals(2, users.size());
        assertEquals("1000123", users.get(0).getUserName());
        assertEquals("3010", users.get(0).getEntitlements().get(0).getValue());
    }

    @Test
    void getUsers_cachesWithinTtl_onlyOneUpstreamCall() {
        wm.stubFor(get(urlPathEqualTo("/Account"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"data\":[]}")));

        for (int i = 0; i < 6; i++) {
            api.getUsers(1, 50, null);
        }
        wm.verify(1, getRequestedFor(urlPathEqualTo("/Account")));
    }

    @Test
    void getUsers_filterByUserName() {
        wm.stubFor(get(urlPathEqualTo("/Account"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":[{"userName":"1000123","isActive":true},
                                         {"userName":"1000456","isActive":true}]}
                                """)));

        ScimFilter filter = new ScimFilter("userName", ScimFilter.Operator.EQ, "1000123", null);
        List<ScimUserV2> users = api.getUsers(1, 50, filter);
        assertEquals(1, users.size());
        assertEquals("1000123", users.get(0).getUserName());
    }

    // ---- getUser --------------------------------------------------------------

    @Test
    void getUser_mapsSingleUser() {
        wm.stubFor(get(urlPathEqualTo("/Account/1000123"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":[{"userName":"1000123","firstName":"Alex","lastName":"Synthetic",
                                         "isActive":true,"groupId":"3010","groupName":"Sales Standard"}]}
                                """)));

        ScimUserV2 user = api.getUser("1000123");
        assertEquals("1000123", user.getUserName());
        assertEquals("3010", user.getEntitlements().get(0).getValue());
    }

    @Test
    void getUser_nonTwoXx_returnsNull() {
        // Not-found response shape is a confirmed permanent gap (OQ-006) — any
        // non-2xx (this test uses 404) must be treated as not-found, not thrown.
        wm.stubFor(get(urlPathEqualTo("/Account/9999"))
                .willReturn(aResponse().withStatus(404)));
        assertNull(api.getUser("9999"));
    }

    // ---- getEntitlements --------------------------------------------------------

    @Test
    void getEntitlements_derivedFromGetUser_noSeparateCall() {
        wm.stubFor(get(urlPathEqualTo("/Account/1000123"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":[{"userName":"1000123","isActive":true,
                                         "groupId":"3010","groupName":"Sales Standard"}]}
                                """)));

        List<com.okta.ps.scim.pojos.UserEntitlement> ents = api.getEntitlements("1000123");
        assertEquals(1, ents.size());
        assertEquals("3010", ents.get(0).getValue());
    }

    @Test
    void getEntitlements_userHasNoGroup_returnsEmpty() {
        wm.stubFor(get(urlPathEqualTo("/Account/1000456"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"data\":[{\"userName\":\"1000456\",\"isActive\":true}]}")));

        assertTrue(api.getEntitlements("1000456").isEmpty());
    }

    @Test
    void getEntitlements_userNotFound_returnsEmpty() {
        wm.stubFor(get(urlPathEqualTo("/Account/9999"))
                .willReturn(aResponse().withStatus(404)));
        assertTrue(api.getEntitlements("9999").isEmpty());
    }

    // ---- createUser: requires exactly one entitlement (CONFIRMED OQ-002) ------

    @Test
    void createUser_withGroupId_postsConfirmedBodyAndRefetches() {
        wm.stubFor(post(urlPathEqualTo("/Account")).willReturn(aResponse().withStatus(200)));
        wm.stubFor(get(urlPathEqualTo("/Account/new.user"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":[{"userName":"new.user","firstName":"New","lastName":"User",
                                         "isActive":true,"groupId":"3010","groupName":"Sales Standard"}]}
                                """)));

        ScimUserV2 input = newUserInput("new.user", "New", "User", "new.user@example.com", "Sales Rep", "3010");
        ScimUserV2 created = api.createUser(input);

        assertEquals("new.user", created.getUserName());
        wm.verify(postRequestedFor(urlPathEqualTo("/Account"))
                .withRequestBody(containing("\"userName\":\"new.user\""))
                .withRequestBody(containing("\"groupId\":\"3010\""))
                .withRequestBody(containing("\"isActive\":true")));
    }

    @Test
    void createUser_missingGroupId_failsLoudlyWithoutCallingTarget() {
        ScimUserV2 input = newUserInput("new.user", "New", "User", "new.user@example.com", "Sales Rep", null);
        assertThrows(ScimErrorException.class, () -> api.createUser(input));
        wm.verify(0, postRequestedFor(urlPathEqualTo("/Account")));
    }

    // ---- replaceUser / activateUser: permanently out of scope (CONFIRMED) -----

    @Test
    void replaceUser_noGenuineProfileChange_returnsCurrentUserWithoutThrowing() {
        // Core unconditionally calls replaceUser at the tail of every PUT,
        // including pure deactivate/activate/entitlement-only requests that
        // carry no real profile change — this must not throw, or PUT-based
        // deactivation could never complete (see the method's own javadoc).
        wm.stubFor(get(urlPathEqualTo("/Account/1000123"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":[{"userName":"1000123","firstName":"Alex","lastName":"Synthetic",
                                         "emailAddress":"alex.synthetic@example.com","title":"Sales Rep","isActive":true}]}
                                """)));

        ScimUserV2 incoming = newUserInput("1000123", "Alex", "Synthetic",
                "alex.synthetic@example.com", "Sales Rep", null);
        ScimUserV2 result = api.replaceUser("1000123", incoming);

        assertEquals("1000123", result.getUserName());
    }

    @Test
    void replaceUser_genuineFieldChange_throwsNotImplemented() {
        wm.stubFor(get(urlPathEqualTo("/Account/1000123"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"data\":[{\"userName\":\"1000123\",\"firstName\":\"Alex\",\"lastName\":\"Synthetic\",\"isActive\":true}]}")));

        ScimUserV2 incoming = newUserInput("1000123", "Alexandra", "Synthetic", null, null, null);
        ScimErrorException ex = assertThrows(ScimErrorException.class,
                () -> api.replaceUser("1000123", incoming));
        assertEquals(org.springframework.http.HttpStatus.NOT_IMPLEMENTED, ex.getStatus());
    }

    @Test
    void replaceUser_accountAlreadyUnreachable_reportsTrueInactiveStateInsteadOf404() {
        // Most likely already deactivated by this same PUT (e.g. revoking
        // the account's one entitlement, CONFIRMED OQ-003) — report the
        // true resulting state rather than null, which would trigger
        // core's "not found" 404 fallback for an operation that actually
        // succeeded.
        wm.stubFor(get(urlPathEqualTo("/Account/1000123")).willReturn(aResponse().withStatus(404)));

        ScimUserV2 incoming = newUserInput("1000123", "Alex", "Synthetic", null, null, null);
        incoming.setActive(true); // Okta's PUT itself may still say active:true
        ScimUserV2 result = api.replaceUser("1000123", incoming);

        assertEquals("1000123", result.getUserName());
        assertFalse(result.getActive());
    }

    @Test
    void activateUser_alwaysThrowsNotImplemented() {
        ScimErrorException ex = assertThrows(ScimErrorException.class, () -> api.activateUser("1000123"));
        assertEquals(org.springframework.http.HttpStatus.NOT_IMPLEMENTED, ex.getStatus());
    }

    // ---- deactivateUser: CONFIRMED single call, never the 4021 admin step -----

    @Test
    void deactivateUser_callsDeactivateEndpointOnly() {
        wm.stubFor(put(urlPathEqualTo("/Account/1000123/Deactivate")).willReturn(aResponse().withStatus(200)));

        api.deactivateUser("1000123");

        wm.verify(putRequestedFor(urlPathEqualTo("/Account/1000123/Deactivate")));
        // The "Disable Account (1.1)" admin-only step must never be called from here.
        wm.verify(0, putRequestedFor(urlPathEqualTo("/Account/1000123")));
    }

    @Test
    void deactivateUser_genuineFailure_stillActiveOnRecheck_throws() {
        wm.stubFor(put(urlPathEqualTo("/Account/1000123/Deactivate")).willReturn(aResponse().withStatus(500)));
        wm.stubFor(get(urlPathEqualTo("/Account/1000123"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("{\"data\":[{\"userName\":\"1000123\",\"isActive\":true}]}")));

        assertThrows(ScimErrorException.class, () -> api.deactivateUser("1000123"));
    }

    @Test
    void deactivateUser_failureButAlreadyUnreachable_treatedAsSuccess() {
        // Simulates the double-fire: the core's deactivate-then-strip-entitlements
        // orchestration already deactivated this account via the OTHER call
        // (setEntitlement(remove) or a prior deactivateUser), so this redundant
        // call fails, but the account is confirmed unreachable via GET.
        wm.stubFor(put(urlPathEqualTo("/Account/1000123/Deactivate")).willReturn(aResponse().withStatus(500)));
        wm.stubFor(get(urlPathEqualTo("/Account/1000123")).willReturn(aResponse().withStatus(404)));

        api.deactivateUser("1000123"); // must not throw
    }

    // ---- setEntitlement: add replaces the single group; remove aliases deactivate ---

    @Test
    void setEntitlement_add_putsGroupIdBody() {
        wm.stubFor(put(urlPathEqualTo("/Account/1000123")).willReturn(aResponse().withStatus(200)));

        api.setEntitlement("1000123", "3020", true);

        wm.verify(putRequestedFor(urlPathEqualTo("/Account/1000123"))
                .withRequestBody(equalToJson("{\"groupId\":\"3020\"}")));
    }

    @Test
    void setEntitlement_removeCommittedViaReplaceUser_hitsTheSameEndpointAsDeactivateUser() {
        // Superseded by the deferred-remove design (see setEntitlement's
        // javadoc): remove() alone no longer calls Ansira directly — see
        // setEntitlement_removeAloneNeverFollowedByAdd_doesNotCallDeactivateOnItsOwn
        // and setEntitlement_removeThenReplaceUser_commitsTheDeferredDeactivate
        // for the up-to-date behavior. This test just confirms the eventual
        // commit still never touches the "add" endpoint.
        wm.stubFor(put(urlPathEqualTo("/Account/1000123/Deactivate")).willReturn(aResponse().withStatus(200)));
        wm.stubFor(get(urlPathEqualTo("/Account/1000123")).willReturn(aResponse().withStatus(404)));

        api.setEntitlement("1000123", "3020", false);
        api.replaceUser("1000123", newUserInput("1000123", "Alex", "Synthetic", null, null, null));

        wm.verify(putRequestedFor(urlPathEqualTo("/Account/1000123/Deactivate")));
        wm.verify(0, putRequestedFor(urlPathEqualTo("/Account/1000123")));
    }

    @Test
    void setEntitlement_doubleFire_secondRedundantCommitDoesNotThrow() {
        // The exact scenario from behaviors.deprovision: deactivateUser
        // (direct call, e.g. from core's deactivate-then-strip branch) already
        // succeeded — account now unreachable — then the entitlement-strip
        // loop's setEntitlement(remove) marks a deferred deactivate that
        // replaceUser later tries to commit against that same now-deactivated
        // account. The redundant second attempt must not surface as a failure.
        wm.stubFor(put(urlPathEqualTo("/Account/1000123/Deactivate")).willReturn(aResponse().withStatus(410)));
        wm.stubFor(get(urlPathEqualTo("/Account/1000123")).willReturn(aResponse().withStatus(404)));

        api.setEntitlement("1000123", "3010", false); // marks pending, no call yet
        ScimUserV2 incoming = newUserInput("1000123", "Alex", "Synthetic", null, null, null);
        incoming.setActive(false);
        api.replaceUser("1000123", incoming); // must not throw despite the 410
    }

    @Test
    void setEntitlement_blankEntitlementId_failsLoudly() {
        assertThrows(ScimErrorException.class, () -> api.setEntitlement("1000123", "", true));
        assertThrows(ScimErrorException.class, () -> api.setEntitlement("1000123", null, true));
    }

    // ---- setEntitlement swap: remove is deferred, add cancels it (IMPLEMENTATION DISCOVERY) ----

    @Test
    void setEntitlement_removeThenAdd_neverCallsDeactivate_onlyTheAddPut() {
        // Mirrors core's applyEntitlementDiff order for an entitlement SWAP:
        // remove(old) called first, then add(new). The remove must NOT fire
        // the deactivate endpoint — add() alone correctly replaces the
        // account's single group.
        wm.stubFor(put(urlPathEqualTo("/Account/1000123")).willReturn(aResponse().withStatus(200)));

        api.setEntitlement("1000123", "3010", false); // old — deferred, no call yet
        api.setEntitlement("1000123", "4054", true);  // new — cancels the deferred remove

        wm.verify(0, putRequestedFor(urlPathEqualTo("/Account/1000123/Deactivate")));
        wm.verify(putRequestedFor(urlPathEqualTo("/Account/1000123"))
                .withRequestBody(equalToJson("{\"groupId\":\"4054\"}")));
    }

    @Test
    void setEntitlement_removeAloneNeverFollowedByAdd_doesNotCallDeactivateOnItsOwn() {
        // remove() alone must not call Ansira at all — it only marks intent.
        // Only replaceUser (core's guaranteed tail-of-PUT call) commits it.
        api.setEntitlement("1000123", "3010", false);
        wm.verify(0, putRequestedFor(urlPathEqualTo("/Account/1000123/Deactivate")));
    }

    @Test
    void setEntitlement_removeThenReplaceUser_commitsTheDeferredDeactivate() {
        // Genuine revoke-to-zero: no add follows, so replaceUser (called
        // unconditionally at the tail of every PUT) must commit it.
        wm.stubFor(put(urlPathEqualTo("/Account/1000123/Deactivate")).willReturn(aResponse().withStatus(200)));
        wm.stubFor(get(urlPathEqualTo("/Account/1000123")).willReturn(aResponse().withStatus(404)));

        api.setEntitlement("1000123", "3010", false);
        ScimUserV2 incoming = newUserInput("1000123", "Alex", "Synthetic", null, null, null);
        incoming.setActive(true);
        ScimUserV2 result = api.replaceUser("1000123", incoming);

        wm.verify(putRequestedFor(urlPathEqualTo("/Account/1000123/Deactivate")));
        assertFalse(result.getActive());
    }

    // ---- getGroups / group (entitlement) catalog -------------------------------

    @Test
    void getGroups_alwaysEmpty() {
        assertTrue(api.getGroups(1, 50).isEmpty());
    }

    @Test
    void listGroupEntitlements_mapsAndCaches() {
        wm.stubFor(get(urlPathEqualTo("/Group"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json")
                        .withBody("""
                                {"data":[{"groupId":"3010","groupName":"Sales Standard"},
                                         {"groupId":"3020","groupName":"Sales Manager"}]}
                                """)));

        List<com.okta.ps.scim.pojos.Entitlement> catalog = api.listGroupEntitlements();
        assertEquals(2, catalog.size());
        assertEquals("3010", catalog.get(0).getId());
        assertEquals("Sales Standard", catalog.get(0).getDisplayName());

        api.listGroupEntitlements();
        wm.verify(1, getRequestedFor(urlPathEqualTo("/Group")));
    }

    private static ScimUserV2 newUserInput(String userName, String givenName, String familyName,
                                            String email, String title, String groupId) {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName(userName);
        Name name = new Name();
        name.setGivenName(givenName);
        name.setFamilyName(familyName);
        user.setName(name);
        com.okta.ps.scim.pojos.Email e = new com.okta.ps.scim.pojos.Email();
        e.setValue(email);
        e.setPrimary(true);
        user.getEmails().add(e);
        user.setTitle(title);
        if (groupId != null) {
            user.getEntitlements().add(new UserEntitlement(groupId, groupId));
        }
        return user;
    }

    // ---- proxy Negotiate auth wiring ----------------------------------------
    //
    // The actual GSS/SPNEGO token exchange can't be exercised here (needs a real
    // Kerberos proxy) — this is a regression test for the exact bug class hit by
    // hand for scim-connector-blackline: the auth scheme registry alone is
    // silently never consulted unless RequestConfig.setProxyPreferredAuthSchemes
    // is ALSO set. See AnsiraConnectorApi.buildApacheHttpClient()'s field comment.

    @Test
    void negotiateEnabled_wiresProxyPreferredAuthSchemes() {
        api.reconfigureProxyForTest("proxy.example.com", 80, true);

        RequestConfig config = ((Configurable) api.getApacheHttpClientForTest()).getConfig();
        assertEquals(List.of(StandardAuthScheme.SPNEGO), config.getProxyPreferredAuthSchemes());
    }

    @Test
    void negotiateDisabled_doesNotSetProxyPreferredAuthSchemes() {
        api.reconfigureProxyForTest("proxy.example.com", 80, false);

        RequestConfig config = ((Configurable) api.getApacheHttpClientForTest()).getConfig();
        assertNull(config.getProxyPreferredAuthSchemes());
    }

    @Test
    void negotiateEnabled_withNoProxyHost_stillConfiguresWithoutThrowing() {
        api.reconfigureProxyForTest("", 80, true);

        assertNotNull(api.getApacheHttpClientForTest());
    }
}
