package com.dell.webservice.scim.ansira;

import com.okta.ps.scim.ScimConnectorApplication;
import com.okta.ps.scim.pojos.ScimSchemas;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = {ScimConnectorApplication.class, AnsiraApplication.class})
@AutoConfigureMockMvc
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
class ContractTests {

    private static final String SCIM_JSON = "application/scim+json";
    private static final String ALEX_ID = "1000123";
    private static final String JORDAN_ID = "1000456";

    @Autowired private MockMvc mvc;

    @Test
    void listReturnsSeededUsers() throws Exception {
        mvc.perform(get("/v2/Users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.schemas", hasItem(ScimSchemas.LIST_RESPONSE)))
                .andExpect(jsonPath("$.totalResults", is(2)))
                .andExpect(jsonPath("$.Resources[*].userName", containsInAnyOrder(ALEX_ID, JORDAN_ID)));
    }

    @Test
    void getUserIncludesNameAndEntitlement() throws Exception {
        mvc.perform(get("/v2/Users/" + ALEX_ID))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name.givenName", is("Alex")))
                .andExpect(jsonPath("$.name.familyName", is("Synthetic")))
                .andExpect(jsonPath("$.entitlements[0].value", is("3010")));
    }

    @Test
    void filterUserNameEqReturnsExactlyOne() throws Exception {
        mvc.perform(get("/v2/Users").param("filter", "userName eq \"" + ALEX_ID + "\""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalResults", is(1)))
                .andExpect(jsonPath("$.Resources[0].userName", is(ALEX_ID)));
    }

    @Test
    void paginationWorks() throws Exception {
        mvc.perform(get("/v2/Users").param("startIndex", "1").param("count", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalResults", is(2)))
                .andExpect(jsonPath("$.Resources.length()", is(1)));
    }

    @Test
    void postWithOneEntitlementCreatesUser() throws Exception {
        // CONFIRMED (OQ-002): Okta sends exactly one entitlement alongside creation.
        String body = """
                {
                  "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
                  "userName": "1000789",
                  "name": {"givenName": "New", "familyName": "User"},
                  "emails": [{"value": "new.user@example.com", "primary": true}],
                  "title": "Sales Rep",
                  "active": true,
                  "entitlements": [{"value": "3010"}]
                }
                """;
        mvc.perform(post("/v2/Users").contentType(SCIM_JSON).content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.userName", is("1000789")))
                .andExpect(jsonPath("$.active", is(true)))
                .andExpect(jsonPath("$.entitlements[0].value", is("3010")));
    }

    @Test
    void postWithoutEntitlementFailsLoudly() throws Exception {
        // CONFIRMED (OQ-002): missing groupId must be rejected, not defaulted.
        String body = """
                {
                  "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
                  "userName": "1000789",
                  "name": {"givenName": "New", "familyName": "User"},
                  "active": true
                }
                """;
        mvc.perform(post("/v2/Users").contentType(SCIM_JSON).content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.scimType", is("invalidValue")));
    }

    @Test
    void postDuplicateActiveReturnsUniquenessError() throws Exception {
        mvc.perform(post("/v2/Users").contentType(SCIM_JSON).content("""
                {"schemas":["urn:ietf:params:scim:schemas:core:2.0:User"],
                 "userName":"1000123","active":true,"entitlements":[{"value":"3010"}]}
                """))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.scimType", is("uniqueness")));
    }

    // ---- Deactivation: the core's deactivate-then-strip-entitlements step
    // calls BOTH deactivateUser and setEntitlement(remove) for this one PUT —
    // on this target both alias the same call, so this also exercises the
    // double-fire idempotency guard end-to-end (see behaviors.deprovision).

    @Test
    void putWithActiveFalseDeactivatesAndReportsTrueStateNotAnError() throws Exception {
        // The PUT itself must succeed and report the TRUE resulting state
        // (inactive) — see AnsiraConnectorApi.replaceUser's javadoc: an
        // operation that succeeded exactly as this target's confirmed
        // business rules dictate must not surface to Okta as an error.
        mvc.perform(put("/v2/Users/" + ALEX_ID).contentType(SCIM_JSON).content("""
                {"schemas":["urn:ietf:params:scim:schemas:core:2.0:User"],
                 "userName":"1000123","name":{"givenName":"Alex","familyName":"Synthetic"},
                 "active":false}
                """))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.active", is(false)));

        // CONFIRMED (OQ-005): deactivation makes the account unreachable via
        // GET, not merely inactive — a SEPARATE subsequent GET still 404s.
        mvc.perform(get("/v2/Users")).andExpect(jsonPath("$.totalResults", is(1)));
        mvc.perform(get("/v2/Users/" + ALEX_ID)).andExpect(status().isNotFound());
    }

    // core >=1.1.1 stops diffing entitlements on PUT once patch.supported is
    // true — PATCH is the sole channel now (see UserController.replace()/patch()).
    // These two mirror the PUT-based scenarios above but via PATCH, the same
    // way scim-connector-prismacloud/salesworks already adapted.

    @Test
    void deleteEntitlementWhileStayingActiveAlsoDeactivatesTheWholeAccount() throws Exception {
        // CONFIRMED (OQ-003): there is no independent "remove only the
        // entitlement" path on this target — revoking it always deactivates
        // the whole account. The response must still report the TRUE
        // resulting state (inactive) rather than erroring — this is the exact
        // real-world scenario found via Okta's "Manage Access" > Revoke
        // Entitlement action. Jordan seeds with entitlement "3020".
        mvc.perform(patch("/v2/Users/" + JORDAN_ID).contentType(SCIM_JSON).content(patchOp(
                        op("remove", "entitlements[value eq \"3020\"]", null))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.active", is(false)));

        mvc.perform(get("/v2/Users/" + JORDAN_ID)).andExpect(status().isNotFound());
    }

    @Test
    void swappingEntitlementWhileStayingActiveDoesNotDeactivateTheAccount() throws Exception {
        // IMPLEMENTATION DISCOVERY (live testing): Okta's "Customize
        // Entitlements" (remove one, add another) diffs to a single PATCH
        // with toRemove=[old]/toAdd=[new], and core reorders removes before
        // adds regardless of request order. Naively deactivating on the
        // removal op (correct for a genuine revoke-to-zero) would kill the
        // account before the addition ever ran — this is the exact bug a
        // real customer test hit: the request succeeded but the account
        // vanished and the entitlement-add 404'd. The account must stay
        // ACTIVE with the NEW entitlement, not disappear. Jordan seeds with
        // entitlement "3020".
        mvc.perform(patch("/v2/Users/" + JORDAN_ID).contentType(SCIM_JSON).content(patchOp(
                        op("remove", "entitlements[value eq \"3020\"]", null),
                        op("add", "entitlements", "[{\"value\":\"3010\"}]"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.active", is(true)))
                .andExpect(jsonPath("$.entitlements[0].value", is("3010")));

        // The account must still be reachable and correctly reflect the swap.
        mvc.perform(get("/v2/Users/" + JORDAN_ID))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.active", is(true)))
                .andExpect(jsonPath("$.entitlements[0].value", is("3010")));
    }

    @Test
    void getMissingMemberReturns404() throws Exception {
        mvc.perform(get("/v2/Users/nonexistent"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.scimType", is("noTarget")));
    }

    @Test
    void invalidFilterReturns400() throws Exception {
        mvc.perform(get("/v2/Users").param("filter", "this is not valid"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.scimType", is("invalidFilter")));
    }

    @Test
    void postWithoutUserNameReturnsInvalidValue() throws Exception {
        mvc.perform(post("/v2/Users").contentType(SCIM_JSON).content("""
                {"schemas":["urn:ietf:params:scim:schemas:core:2.0:User"],"active":true}
                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.scimType", is("invalidValue")));
    }

    @Test
    void serviceProviderConfigAdvertisesCorrectly() throws Exception {
        mvc.perform(get("/v2/ServiceProviderConfig"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.patch.supported", is(true)))
                .andExpect(jsonPath("$.patch.maxOperations", is(100)))
                .andExpect(jsonPath("$.bulk.supported", is(false)))
                .andExpect(jsonPath("$.changePassword.supported", is(false)))
                .andExpect(jsonPath("$.filter.supported", is(true)))
                .andExpect(jsonPath("$.filter.maxResults", is(100)))
                .andExpect(jsonPath("$['urn:okta:schemas:scim:providerconfig:2.0'].userManagementCapabilities",
                        containsInAnyOrder("IMPORT_NEW_USERS", "IMPORT_PROFILE_UPDATES", "IMPORT_USER_SCHEMA",
                                "PUSH_NEW_USERS", "GROUP_PUSH", "PUSH_USER_DEACTIVATION", "PUSH_PROFILE_UPDATES")));
    }

    @Test
    void groupsEndpointReturnsEmpty() throws Exception {
        // No SCIM Group in scope — Ansira's group is modeled as an Entitlement.
        mvc.perform(get("/v2/Groups"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalResults", is(0)));
    }

    @Test
    void entitlementsEndpointReturnsCatalog() throws Exception {
        mvc.perform(get("/v2/Entitlements"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.schemas", hasItem(ScimSchemas.LIST_RESPONSE)))
                .andExpect(jsonPath("$.totalResults", is(3)))
                .andExpect(jsonPath("$.Resources[*].id", containsInAnyOrder("3010", "3020", "4021")));
    }

    @Test
    void resourceTypesAdvertisesUserAndEntitlementOnly() throws Exception {
        mvc.perform(get("/v2/ResourceTypes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalResults", is(2)))
                .andExpect(jsonPath("$.Resources[*].id", containsInAnyOrder("User", "Entitlement")));
    }

    private static String[] op(String op, String path, String valueJson) {
        return new String[] {op, path, valueJson};
    }

    private static String patchOp(String[]... ops) {
        StringBuilder operations = new StringBuilder();
        for (int i = 0; i < ops.length; i++) {
            if (i > 0) {
                operations.append(',');
            }
            String[] o = ops[i];
            operations.append('{').append("\"op\":\"").append(o[0]).append('"');
            if (o[1] != null) {
                operations.append(",\"path\":\"").append(o[1].replace("\"", "\\\"")).append('"');
            }
            if (o[2] != null) {
                operations.append(",\"value\":").append(o[2]);
            }
            operations.append('}');
        }
        return """
                {
                  "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                  "Operations": [%s]
                }
                """.formatted(operations);
    }
}
