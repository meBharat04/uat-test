package com.dell.webservice.scim.ansira;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;
import com.dell.webservice.scim.ansira.mapper.AnsiraMapper;
import com.okta.ps.scim.pojos.Email;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Name;
import com.okta.ps.scim.pojos.ScimUserV2;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class AnsiraMapperTest {

    private AnsiraMapper mapper;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        mapper = new AnsiraMapper(objectMapper);
    }

    // ---- target -> SCIM -----------------------------------------------------

    @Test
    void listItems_extractsDataArray() throws Exception {
        JsonNode list = objectMapper.readTree("""
                {"data":[{"userName":"1000123"},{"userName":"1000456"}]}
                """);
        List<JsonNode> items = mapper.listItems(list);
        assertEquals(2, items.size());
        assertEquals("1000123", items.get(0).path("userName").asText());
    }

    @Test
    void singleItem_extractsFirstElementOfDataArray() throws Exception {
        // CONFIRMED against a live tenant: single-user GET wraps "data" in a
        // single-element array, exactly like the list endpoint — not a bare
        // object as the SailPoint export alone suggested.
        JsonNode resp = objectMapper.readTree("""
                {"data":[{"userName":"1000123"}],"message":"Success"}
                """);
        JsonNode item = mapper.singleItem(resp);
        assertEquals("1000123", item.path("userName").asText());
    }

    @Test
    void singleItem_emptyDataArray_returnsNull() throws Exception {
        JsonNode resp = objectMapper.readTree("""
                {"data":[],"message":"Success"}
                """);
        assertNull(mapper.singleItem(resp));
    }

    @Test
    void singleItem_missingData_returnsNull() throws Exception {
        JsonNode resp = objectMapper.readTree("{}");
        assertNull(mapper.singleItem(resp));
    }

    @Test
    void toScimUser_mapsAllFieldsAndEntitlement() throws Exception {
        JsonNode row = objectMapper.readTree("""
                {"userName":"1000123","firstName":"Alex","lastName":"Synthetic",
                 "emailAddress":"alex.synthetic@example.com","title":"Sales Rep",
                 "isActive":true,"groupId":"3010","groupName":"Sales Standard"}
                """);

        ScimUserV2 user = mapper.toScimUser(row);

        assertEquals("1000123", user.getId());
        assertEquals("1000123", user.getExternalId());
        assertEquals("1000123", user.getUserName());
        assertEquals("Alex", user.getName().getGivenName());
        assertEquals("Synthetic", user.getName().getFamilyName());
        assertEquals("Alex Synthetic", user.getName().getFormatted());
        assertEquals("alex.synthetic@example.com", user.getEmails().get(0).getValue());
        assertTrue(user.getEmails().get(0).getPrimary());
        assertEquals("Sales Rep", user.getTitle());
        assertTrue(user.getActive());
        assertEquals(1, user.getEntitlements().size());
        assertEquals("3010", user.getEntitlements().get(0).getValue());
        assertEquals("Sales Standard", user.getEntitlements().get(0).getDisplay());
        assertEquals(AnsiraMapper.TYPE_GROUP, user.getEntitlements().get(0).getType());
    }

    @Test
    void toScimUser_noGroupId_noEntitlements() throws Exception {
        JsonNode row = objectMapper.readTree("""
                {"userName":"1000123","firstName":"Alex","lastName":"Synthetic",
                 "isActive":true}
                """);
        ScimUserV2 user = mapper.toScimUser(row);
        assertTrue(user.getEntitlements().isEmpty());
    }

    @Test
    void toScimUser_inactiveUser() throws Exception {
        JsonNode row = objectMapper.readTree("""
                {"userName":"1000456","isActive":false}
                """);
        ScimUserV2 user = mapper.toScimUser(row);
        assertFalse(user.getActive());
    }

    @Test
    void toGroupCatalog_mapsGroupIdAndName() throws Exception {
        JsonNode resp = objectMapper.readTree("""
                {"data":[{"groupId":"3010","groupName":"Sales Standard"},
                         {"groupId":"3020","groupName":"Sales Manager"}]}
                """);
        List<Entitlement> catalog = mapper.toGroupCatalog(resp);
        assertEquals(2, catalog.size());
        assertEquals("3010", catalog.get(0).getId());
        assertEquals("Sales Standard", catalog.get(0).getDisplayName());
        assertEquals(AnsiraMapper.TYPE_GROUP, catalog.get(0).getType());
    }

    // ---- SCIM -> target -------------------------------------------------

    @Test
    void toCreateBody_hasConfirmedShapeAndHardcodedIsActiveTrue() {
        ScimUserV2 user = scimUser("1000789", "New", "User", "new.user@example.com", "Sales Rep");
        ObjectNode body = mapper.toCreateBody(user, "3010");

        assertEquals("New", body.path("firstName").asText());
        assertEquals("User", body.path("lastName").asText());
        assertEquals("1000789", body.path("userName").asText());
        assertEquals("new.user@example.com", body.path("emailAddress").asText());
        assertEquals("Sales Rep", body.path("title").asText());
        assertEquals("3010", body.path("groupId").asText());
        assertTrue(body.path("isActive").asBoolean());
    }

    @Test
    void toSetGroupBody_containsOnlyGroupId() {
        ObjectNode body = mapper.toSetGroupBody("3020");
        assertEquals("3020", body.path("groupId").asText());
        assertEquals(1, body.size());
    }

    private static ScimUserV2 scimUser(String userName, String givenName, String familyName, String email, String title) {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName(userName);
        Name name = new Name();
        name.setGivenName(givenName);
        name.setFamilyName(familyName);
        user.setName(name);
        Email e = new Email();
        e.setValue(email);
        e.setPrimary(true);
        user.getEmails().add(e);
        user.setTitle(title);
        return user;
    }
}
