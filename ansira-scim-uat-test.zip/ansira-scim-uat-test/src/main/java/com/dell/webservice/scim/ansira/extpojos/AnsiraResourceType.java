package com.dell.webservice.scim.ansira.extpojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.okta.ps.scim.pojos.ScimResource;

/**
 * Ansira-specific {@link ScimResource} used to advertise the resource types exposed via
 * /v2/ResourceTypes ("User", "Entitlement") with name/schema/endpoint — core@1.0.0 (main)'s
 * bare ScimResource carries none of those fields. Same pattern as
 * scim-connector-synchro-scim/scim-connector-prismacloud/scim-connector-salesworks/
 * scim-connector-blackline's extpojos.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AnsiraResourceType extends ScimResource {

    private String name;
    private String description;
    private String schema;
    private String endpoint;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSchema() { return schema; }
    public void setSchema(String schema) { this.schema = schema; }

    public String getEndpoint() { return endpoint; }
    public void setEndpoint(String endpoint) { this.endpoint = endpoint; }
}
