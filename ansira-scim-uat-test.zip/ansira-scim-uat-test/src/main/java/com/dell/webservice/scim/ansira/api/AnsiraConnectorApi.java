package com.dell.webservice.scim.ansira.api;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.dell.webservice.scim.ansira.mapper.AnsiraMapper;
import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.Name;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import com.okta.ps.scim.utils.StandardLogger;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.hc.client5.http.SystemDefaultDnsResolver;
import org.apache.hc.client5.http.auth.AuthSchemeFactory;
import org.apache.hc.client5.http.auth.KerberosConfig;
import org.apache.hc.client5.http.auth.StandardAuthScheme;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.auth.CredentialsProviderBuilder;
import org.apache.hc.client5.http.impl.auth.SPNegoSchemeFactory;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.HttpHost;
import org.apache.hc.core5.http.config.Registry;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriUtils;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
@Profile("!in-memory")
public class AnsiraConnectorApi implements ConnectorApi, AnsiraEntitlementSource {

    private static final StandardLogger LOG = StandardLogger.forClass(AnsiraConnectorApi.class);

    private final AnsiraMapper mapper;
    private final ObjectMapper objectMapper;

    @Value("${ansira.base.url:}")
    private String baseUrl;

    @Value("${ansira.request.timeout.seconds:60}")
    private long requestTimeoutSeconds;

    @Value("${ansira.app_name:}")
    private String appName;

    // Ansira is a public cloud API — like Blackline and PrismaCloud, this
    // network requires outbound calls to it (and any other external SaaS) to
    // route through the corporate egress proxy. Leave ansira.proxy.host blank
    // to connect directly (no proxy), e.g. in an environment where one isn't
    // required. Scoped to this RestTemplate's own request factory (see
    // configureTimeout()) rather than JVM-wide http.proxyHost/https.proxyHost
    // system properties, which would affect every other application deployed
    // in the same Tomcat. See framework/specs/ansira.yaml delivery.network_egress.
    @Value("${ansira.proxy.host:}")
    private String proxyHost;

    @Value("${ansira.proxy.port:80}")
    private int proxyPort;

    // Confirmed working live against this same proxy for scim-connector-blackline:
    // java.net.http.HttpClient and HttpURLConnection never attempt Negotiate
    // proxy auth at all (traced via full internal debug logging — no GSS
    // activity, no retry, just a pass-through 407). Apache HttpClient 5.x's
    // SPNegoSchemeFactory does work, using the ambient identity of whatever
    // Windows account this JVM runs as (no credentials configured here), but
    // ONLY once BOTH the scheme registry AND RequestConfig.setProxyPreferredAuthSchemes
    // are set — the registry alone is silently never consulted otherwise, since
    // DefaultAuthenticationStrategy.select() filters candidate scheme names
    // against RequestConfig's preferred-schemes list (hardcoded default
    // [Bearer, Digest, Basic] when unset) BEFORE ever looking a scheme up in
    // the registry. See buildApacheHttpClient() below and
    // scim-connector-blackline's BlacklineConnectorApi (same field) /
    // ApacheHttpClientProxyNegotiateTest.java for the investigation this came
    // from. SPNegoSchemeFactory is @Deprecated in httpclient5 ("no longer
    // supported" per Apache's own javadoc) but still functional — accepted
    // tradeoff. Requires -Dsun.security.jgss.native=true as a JVM option
    // (Tomcat setenv.bat/service config — NOT settable from application
    // properties) — init() warns if this is enabled without that flag.
    @Value("${ansira.proxy.auth.negotiate.enabled:false}")
    private boolean proxyAuthNegotiateEnabled;

    // Default TRUE for this connector (differs from Blackline's default-false,
    // per explicit engagement direction) — see framework/specs/ansira.yaml
    // delivery.http_logging.
    @Value("${ansira.http.logging.enabled:true}")
    private boolean httpLoggingEnabled;

    @Value("${ansira.userlist.cache.ttl.ms:20000}")
    private long userlistCacheTtlMs;

    @Value("${ansira.groupcatalog.cache.ttl.ms:20000}")
    private long groupcatalogCacheTtlMs;

    // GET /Account and GET /Group have no server-side pagination (CONFIRMED —
    // see framework/specs/ansira.yaml target_api.pagination). MANDATORY per
    // behaviors.list_caching.
    private final TimedCache<List<ScimUserV2>> userListCache = new TimedCache<>(() -> userlistCacheTtlMs);
    private final TimedCache<List<Entitlement>> groupCatalogCache = new TimedCache<>(() -> groupcatalogCacheTtlMs);

    // Deferred-deactivate bookkeeping for setEntitlement(remove) — see that
    // method's javadoc. Keyed by userId (not a ThreadLocal): a plain map with
    // a short TTL means an entry that's never consumed (e.g. because a
    // sibling call in the same request threw) just expires harmlessly,
    // rather than risking leaking into an unrelated later request on a
    // reused Tomcat worker thread.
    private final Map<String, Long> pendingDeactivate = new ConcurrentHashMap<>();
    private static final long PENDING_DEACTIVATE_TTL_MS = 10_000L;

    // NOT a token/session flow (see generateToken) — the real X-API-KEY value
    // is never held in Vault/env/config. It arrives per-request via the
    // inbound SCIM request's own Basic Authorization header's password
    // sub-field (username sub-field is arbitrary and ignored). This field
    // stays null in production (Spring never injects it) and is set only by
    // the test constructor, which has no real inbound request to decode. See
    // framework/specs/ansira.yaml connector_api.generateToken.secret_refs.
    private String apiKey;

    private RestTemplate restTemplate;

    // Held separately from restTemplate's request factory so shutdown() can
    // close it explicitly — HttpComponentsClientHttpRequestFactory isn't
    // itself a Spring bean here (built manually in configureTimeout()), so
    // nothing closes its pooled connections automatically on a Tomcat WAR
    // undeploy/redeploy without this.
    private CloseableHttpClient apacheHttpClient;

    @Autowired
    public AnsiraConnectorApi(AnsiraMapper mapper, ObjectMapper objectMapper) {
        this.mapper = mapper;
        this.objectMapper = objectMapper;
        this.restTemplate = buildRestTemplate();
    }

    /** Test constructor — injects the API key directly, bypasses inbound-request decoding and @PostConstruct validation. */
    public AnsiraConnectorApi(AnsiraMapper mapper, ObjectMapper objectMapper, String baseUrl, String apiKey) {
        this.mapper = mapper;
        this.objectMapper = objectMapper;
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.requestTimeoutSeconds = 60;
        // Matches the @Value defaults above — this constructor bypasses Spring
        // injection entirely, so without this the fields would default to 0 and
        // defeat caching (every call would immediately re-fetch).
        this.userlistCacheTtlMs = 20_000;
        this.groupcatalogCacheTtlMs = 20_000;
        this.proxyAuthNegotiateEnabled = false;
        this.restTemplate = buildRestTemplate();
        configureTimeout();
    }

    /**
     * Every ConnectorApi method interprets status code + body itself, so the
     * error handler must never throw — Spring's default handler throws
     * HttpClientErrorException on any 4xx/5xx, which would bypass that
     * interpretation entirely.
     */
    private RestTemplate buildRestTemplate() {
        RestTemplate rt = new RestTemplate();
        rt.setErrorHandler(new ResponseErrorHandler() {
            @Override
            public boolean hasError(ClientHttpResponse response) {
                return false;
            }

            @Override
            public void handleError(URI url, HttpMethod method, ClientHttpResponse response) {
                // unreachable — hasError() always returns false
            }
        });
        // httpLoggingEnabled isn't injected yet at this point (this runs from the
        // constructor, before Spring populates @Value fields) — the interceptor
        // reads it lazily per-request via this supplier instead of capturing it now.
        rt.getInterceptors().add(new AnsiraHttpLoggingInterceptor(() -> httpLoggingEnabled));
        return rt;
    }

    /** Test-only hook to exercise the logging-enabled path without a full Spring context. */
    public void setHttpLoggingEnabled(boolean enabled) {
        this.httpLoggingEnabled = enabled;
    }

    @Override
    @PostConstruct
    public void init() {
        String configPath = "application.properties (WEB-INF/classes/application.properties in the WAR)";
        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalStateException("ansira.base.url is required — set it in " + configPath);
        }
        if (proxyAuthNegotiateEnabled) {
            if (proxyHost == null || proxyHost.isBlank()) {
                LOG.warn("ansira.proxy.auth.negotiate.enabled=true but ansira.proxy.host is blank — "
                        + "Negotiate has no proxy to authenticate to and will do nothing");
            }
            if (!"true".equals(System.getProperty("sun.security.jgss.native"))) {
                LOG.warn("ansira.proxy.auth.negotiate.enabled=true but -Dsun.security.jgss.native=true is "
                        + "not set on this JVM — Negotiate will fail per-request; set it in Tomcat's JVM "
                        + "options (setenv.bat/service config), not here");
            }
        }
        configureTimeout();
        LOG.info("AnsiraConnectorApi initialized, baseUrl={}, app_name={}", baseUrl, appName);
    }

    // requestTimeoutSeconds is @Value-injected AFTER the constructor runs — reading
    // it inside a constructor would always see the Java default (0), so this is
    // applied from init() (Spring path) and directly from the test constructor
    // (which bypasses init() entirely), never from a constructor body.
    //
    // Uses Apache HttpClient 5.x rather than SimpleClientHttpRequestFactory
    // specifically because it's the only client confirmed (live, against the
    // real proxy) to support proxy Negotiate auth at all — see
    // proxyAuthNegotiateEnabled's field comment.
    private void configureTimeout() {
        Duration timeout = Duration.ofSeconds(requestTimeoutSeconds);
        closeApacheHttpClientIfPresent();
        this.apacheHttpClient = buildApacheHttpClient();
        HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(apacheHttpClient);
        factory.setReadTimeout(timeout);
        // Buffering lets AnsiraHttpLoggingInterceptor read the response body
        // without exhausting the stream before the message converter reads it too.
        restTemplate.setRequestFactory(new BufferingClientHttpRequestFactory(factory));
    }

    private CloseableHttpClient buildApacheHttpClient() {
        // Every ConnectorApi method interprets status code + body itself
        // (hasError() above always returns false), so a request retried
        // silently behind our backs by Apache's own default retry strategy
        // would be invisible to that inspection — disabled so execute()'s
        // single-attempt semantics are the only retry behavior in effect.
        HttpClientBuilder builder = HttpClients.custom().disableAutomaticRetries();

        if (proxyHost != null && !proxyHost.isBlank()) {
            builder.setProxy(new HttpHost(proxyHost, proxyPort));
            LOG.info("Outbound Ansira calls routed via proxy {}:{}", proxyHost, proxyPort);
        }

        if (proxyAuthNegotiateEnabled) {
            // Both of the following are REQUIRED together — the registry
            // alone is silently never consulted without the RequestConfig
            // entry (see proxyAuthNegotiateEnabled's field comment). Scoped
            // to PROXY auth only (setProxyPreferredAuthSchemes, never
            // setTargetPreferredAuthSchemes) — execute() sets the X-API-KEY
            // header directly rather than relying on challenge/response, so
            // there's no live exposure to Ansira's own endpoint regardless,
            // but this keeps the scoping explicit.
            Registry<AuthSchemeFactory> authSchemeRegistry = RegistryBuilder.<AuthSchemeFactory>create()
                    .register(StandardAuthScheme.SPNEGO,
                            new SPNegoSchemeFactory(KerberosConfig.DEFAULT, SystemDefaultDnsResolver.INSTANCE))
                    .build();
            RequestConfig requestConfig = RequestConfig.custom()
                    .setProxyPreferredAuthSchemes(Collections.singletonList(StandardAuthScheme.SPNEGO))
                    .build();
            builder.setDefaultAuthSchemeRegistry(authSchemeRegistry)
                    // Empty on purpose — SPNEGO doesn't need real credentials (falls
                    // back to a null GSSCredential, i.e. "use the ambient identity"),
                    // but the provider object itself must be non-null for the
                    // framework to attempt any scheme at all.
                    .setDefaultCredentialsProvider(CredentialsProviderBuilder.create().build())
                    .setDefaultRequestConfig(requestConfig);
            LOG.info("Proxy Negotiate authentication enabled (ambient SSPI/native GSS identity)");
        }

        return builder.build();
    }

    private void closeApacheHttpClientIfPresent() {
        if (apacheHttpClient != null) {
            try {
                apacheHttpClient.close();
            } catch (IOException e) {
                LOG.warn("Error closing previous Apache HttpClient during reconfiguration: {}", e.getMessage());
            }
        }
    }

    @PreDestroy
    public void shutdown() {
        closeApacheHttpClientIfPresent();
    }

    /** Test-only hook to exercise proxy/Negotiate configuration not reachable via the constructor. */
    public void reconfigureProxyForTest(String proxyHost, int proxyPort, boolean negotiateEnabled) {
        this.proxyHost = proxyHost;
        this.proxyPort = proxyPort;
        this.proxyAuthNegotiateEnabled = negotiateEnabled;
        configureTimeout();
    }

    /** Test-only accessor for asserting on the constructed Apache HttpClient's proxy/auth wiring. */
    public CloseableHttpClient getApacheHttpClientForTest() {
        return apacheHttpClient;
    }

    // -------------------------------------------------------------------------
    // ConnectorApi implementation
    // -------------------------------------------------------------------------

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        List<ScimUserV2> all = userListCache.get(this::fetchAllUsers);
        if (filter != null && filter.isUserNameEq()) {
            String userName = filter.getValue();
            List<ScimUserV2> matches = new ArrayList<>();
            for (ScimUserV2 u : all) {
                if (userName.equalsIgnoreCase(u.getUserName())) {
                    matches.add(u);
                }
            }
            return matches;
        }
        return all;
    }

    /**
     * GET /Account — CONFIRMED no native pagination (paginationSteps null,
     * pagingSize=50 never wired into a loop); returns the full dataset in one
     * call. SCIM startIndex/count/filter are applied in-memory against the
     * cached result, never against a fresh fetch per SCIM page.
     */
    private List<ScimUserV2> fetchAllUsers() {
        ResponseEntity<String> resp = execute(HttpMethod.GET, "/Account", null);
        if (!resp.getStatusCode().is2xxSuccessful()) {
            throw errorFor(resp, "Failed to list Ansira users");
        }
        List<ScimUserV2> result = new ArrayList<>();
        for (JsonNode row : mapper.listItems(parseJson(resp.getBody()))) {
            result.add(mapper.toScimUser(row));
        }
        return result;
    }

    @Override
    public ScimUserV2 getUser(String id) {
        // core's PATCH path (unlike PUT's replaceUser) never calls replaceUser(),
        // so a PATCH-driven setEntitlement(remove) would otherwise mark a pending
        // deactivate that's never committed — getUser() is what PATCH calls to
        // build its response, so committing here closes that gap the same way
        // replaceUser() already does for PUT. Unlike replaceUser (which has the
        // caller's own user object to fall back on), getUser only has the id, and
        // a live GET right after deactivating returns nothing (CONFIRMED OQ-005)
        // — so on a fresh commit, synthesize the true resulting state (inactive)
        // instead of falling through to fetchRawProfile, which would now 404.
        if (commitPendingDeactivateIfAny(id)) {
            ScimUserV2 stub = new ScimUserV2();
            stub.setId(id);
            stub.setUserName(id);
            stub.setActive(false);
            return stub;
        }
        JsonNode row = fetchRawProfile(id);
        return row == null ? null : mapper.toScimUser(row);
    }

    /**
     * GET /Account/{userId} — identical row shape to getUsers. Not-found
     * response shape is a confirmed permanent gap (OQ-006), not something
     * more customer input will resolve — treats any non-2xx as not-found
     * rather than throwing, since that's also what a GET on an
     * already-deactivated user returns (CONFIRMED OQ-005).
     */
    private JsonNode fetchRawProfile(String id) {
        ResponseEntity<String> resp = execute(HttpMethod.GET, "/Account/" + encodePathSegment(id), null);
        if (!resp.getStatusCode().is2xxSuccessful()) {
            return null;
        }
        return mapper.singleItem(parseJson(resp.getBody()));
    }

    /**
     * POST /Account. CONFIRMED (OQ-002): Okta sends exactly one entitlement
     * assignment alongside account creation — createAccountWithEntReq=true
     * means Ansira REQUIRES a non-empty groupId on every create call. Fail
     * loudly if none is supplied rather than defaulting or sending an empty
     * string. There is no id in the response (resMappingObj is null on
     * Create Account) — the connector uses the userName value it just sent
     * as the new account's identifier, then re-fetches for the canonical
     * return value.
     */
    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        String groupId = requireGroupId(user);
        ResponseEntity<String> resp = execute(HttpMethod.POST, "/Account", serialize(mapper.toCreateBody(user, groupId)));
        if (!resp.getStatusCode().is2xxSuccessful()) {
            throw errorFor(resp, "Failed to create Ansira user " + user.getUserName());
        }
        return getUser(user.getUserName());
    }

    private static String requireGroupId(ScimUserV2 user) {
        List<UserEntitlement> entitlements = user.getEntitlements();
        if (entitlements == null || entitlements.isEmpty() || entitlements.get(0).getValue() == null
                || entitlements.get(0).getValue().isBlank()) {
            throw ScimErrorException.invalidValue(
                    "Ansira requires exactly one entitlement (groupId) to be set on every account creation — "
                            + "none was supplied for userName " + user.getUserName());
        }
        return entitlements.get(0).getValue();
    }

    /**
     * CONFIRMED (OQ-001): genuine profile-field updates (firstName, lastName,
     * emailAddress, title) are permanently out of scope. BUT core's
     * UserController.replace() unconditionally calls this method at the tail
     * of EVERY PUT /v2/Users/{id} — including pure deactivate/activate/
     * entitlement-only requests that carry no intended profile change (core
     * clears body.getEntitlements() before calling this, and Okta typically
     * echoes back the same profile fields it already knows about). Throwing
     * unconditionally here would make PUT-based deactivation permanently
     * return 501 instead of ever completing — a real gap discovered while
     * writing ContractTests, not something the spec anticipated. So: compare
     * the incoming profile fields against the freshly fetched current
     * profile (which already reflects whatever deactivateUser/
     * setEntitlement just did) and reject ONLY a genuine field-level change.
     *
     * Also the guaranteed commit point for a deferred setEntitlement(remove)
     * — see that method's javadoc for why the deactivate can't fire
     * immediately when called.
     */
    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        commitPendingDeactivateIfAny(id);
        JsonNode raw = fetchRawProfile(id);
        if (raw == null) {
            // Unreachable — most likely just deactivated by this same PUT
            // (deactivateUser / setEntitlement(remove) already ran, e.g. via
            // CONFIRMED OQ-003: revoking the account's one entitlement
            // always fully deactivates it, even when Okta's PUT itself asked
            // to stay active). Returning null here would trigger core's
            // "not found" 404 fallback — technically accurate (the record
            // really is gone) but surfaces to Okta as a provisioning ERROR
            // for an operation that actually succeeded exactly as this
            // target's confirmed business rules dictate. Report the TRUE
            // resulting state instead: core already cleared entitlements on
            // `user` before calling this method, so just correct `active`
            // to reflect reality and hand it back — a deactivated user is a
            // state Okta understands natively, not an error.
            user.setActive(false);
            return user;
        }
        if (hasGenuineProfileChange(raw, user)) {
            throw ScimErrorException.notImplemented(
                    "Ansira has no profile-update endpoint — replaceUser is permanently out of scope for "
                            + "genuine profile-field changes (see framework/specs/ansira.yaml behaviors.update_mechanism)");
        }
        return mapper.toScimUser(raw);
    }

    private static boolean hasGenuineProfileChange(JsonNode currentRaw, ScimUserV2 incoming) {
        Name name = incoming.getName();
        return !fieldsEqual(currentRaw.path("firstName").asText(null), name != null ? name.getGivenName() : null)
                || !fieldsEqual(currentRaw.path("lastName").asText(null), name != null ? name.getFamilyName() : null)
                || !fieldsEqual(currentRaw.path("emailAddress").asText(null), primaryEmail(incoming))
                || !fieldsEqual(currentRaw.path("title").asText(null), incoming.getTitle());
    }

    private static boolean fieldsEqual(String a, String b) {
        String na = (a == null || a.isBlank()) ? null : a;
        String nb = (b == null || b.isBlank()) ? null : b;
        return na == null ? nb == null : na.equals(nb);
    }

    private static String primaryEmail(ScimUserV2 user) {
        if (user.getEmails() == null) return null;
        for (com.okta.ps.scim.pojos.Email e : user.getEmails()) {
            if (Boolean.TRUE.equals(e.getPrimary())) return e.getValue();
        }
        return user.getEmails().isEmpty() ? null : user.getEmails().get(0).getValue();
    }

    /** CONFIRMED (OQ-004): permanently out of scope — no reactivate operation exists; re-create via createUser instead. */
    @Override
    public void activateUser(String id) {
        throw ScimErrorException.notImplemented(
                "Ansira has no reactivate operation — a deactivated account must be re-created via createUser (see framework/specs/ansira.yaml behaviors.reactivation)");
    }

    /** CONFIRMED (OQ-005): PUT /Account/{userId}/Deactivate only — see callDeactivateEndpoint for the shared implementation. */
    @Override
    public void deactivateUser(String id) {
        callDeactivateEndpoint(id);
    }

    /**
     * CONFIRMED: no dedicated per-user entitlement-read endpoint exists —
     * derive from the same Account read used by getUser rather than making a
     * separate call.
     */
    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 user = getUser(userId);
        return user == null || user.getEntitlements() == null ? List.of() : new ArrayList<>(user.getEntitlements());
    }

    /**
     * add: PUT /Account/{userId} body {"groupId": entitlementId} — REPLACES
     * the account's single group assignment (isMulti=false), not additive.
     * remove: CONFIRMED (OQ-003/OQ-005) there is no independent
     * "remove-only-the-entitlement" operation on this target — the remove
     * endpoint IS deactivateUser's endpoint. Removing this connector's one
     * entitlement type therefore deactivates the WHOLE account; callers
     * (including the core's own entitlement-diff/strip logic) must be aware
     * of that account-wide side effect.
     *
     * DEFERRED remove, NOT immediate — IMPLEMENTATION DISCOVERY (live
     * testing): core's applyEntitlementDiff() always calls setEntitlement
     * for every removed value BEFORE every added value, for the SAME PUT.
     * An entitlement SWAP (remove old, add new — Okta's "Customize
     * Entitlements") therefore looked like: remove(old) fires first,
     * deactivating the whole account before add(new) ever runs — which then
     * 404s against an account that no longer exists. But a swap doesn't need
     * a remove call at all: add() already REPLACES the account's single
     * group, so the correct fix is to never let remove's deactivate fire
     * when an add for the same user follows in the same request. remove()
     * only marks intent; add() cancels any pending mark before doing its own
     * PUT; replaceUser (called unconditionally at the tail of every PUT)
     * commits any mark still pending once no add has canceled it — the
     * genuine revoke-to-zero case, unchanged from before.
     */
    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        if (entitlementId == null || entitlementId.isBlank()) {
            throw ScimErrorException.invalidValue("entitlementId must not be blank");
        }
        if (add) {
            pendingDeactivate.remove(userId);
            ResponseEntity<String> resp = execute(HttpMethod.PUT, "/Account/" + encodePathSegment(userId),
                    serialize(mapper.toSetGroupBody(entitlementId)));
            if (!resp.getStatusCode().is2xxSuccessful()) {
                throw errorFor(resp, "Failed to set entitlement " + entitlementId + " for Ansira user " + userId);
            }
        } else {
            pendingDeactivate.put(userId, System.currentTimeMillis());
        }
    }

    /**
     * Commits a still-pending deferred deactivate for this user, if one was
     * marked by setEntitlement(remove) and not since canceled by a
     * setEntitlement(add) — see that method's javadoc. Called from
     * replaceUser, which core calls unconditionally at the tail of every
     * PUT, guaranteeing this always gets a chance to run within the same
     * request that marked it.
     */
    private boolean commitPendingDeactivateIfAny(String userId) {
        Long markedAt = pendingDeactivate.remove(userId);
        if (markedAt != null && System.currentTimeMillis() - markedAt <= PENDING_DEACTIVATE_TTL_MS) {
            callDeactivateEndpoint(userId);
            return true;
        }
        return false;
    }

    /**
     * PUT /Account/{userId}/Deactivate, no body — shared by deactivateUser
     * and setEntitlement(remove) (CONFIRMED OQ-005, same endpoint). The
     * other configured step ("Disable Account 1.1", reassign to group
     * "4021") is a separate ADMIN-ONLY operation and is never called here.
     *
     * Idempotency guard: the core's deactivate-then-strip-entitlements
     * orchestration (see UserController.replace()/patch()) calls BOTH
     * deactivateUser and setEntitlement(remove) for one Okta deactivation,
     * and both land on this identical endpoint — so a single logical
     * deactivation fires it twice. On a non-2xx response, verify
     * independently via a fresh GET whether the account is already
     * unreachable (CONFIRMED OQ-005: GET on a deactivated user returns no
     * response) before deciding this call is safe to ignore, rather than
     * blindly swallowing every non-2xx: error_model is a confirmed permanent
     * gap (OQ-006), but silently treating a genuine first-time failure as
     * success would leave a user provisioned when Okta believes they were
     * deactivated — the more dangerous failure mode for a deprovisioning
     * operation.
     */
    private void callDeactivateEndpoint(String userId) {
        ResponseEntity<String> resp = execute(HttpMethod.PUT, "/Account/" + encodePathSegment(userId) + "/Deactivate", null);
        if (resp.getStatusCode().is2xxSuccessful()) {
            return;
        }
        if (fetchRawProfile(userId) == null) {
            LOG.info("Deactivate call for {} returned HTTP {} but the account is already unreachable via GET — "
                            + "treating as already deactivated by a companion call, not failing",
                    userId, resp.getStatusCode().value());
            return;
        }
        throw errorFor(resp, "Failed to deactivate Ansira user " + userId);
    }

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        // No SCIM Group in scope — Ansira's group is a target-native access-level
        // concept (OIG Entitlement), not an Okta-pushed group. See
        // framework/specs/ansira.yaml scim_advertisement.resource_types. core's
        // generic GroupController is unconditionally present regardless of what
        // ResourceTypes advertises, so this can't be removed, only made a no-op.
        return List.of();
    }

    /**
     * GET /Group — CONFIRMED no native pagination, backs the Entitlement
     * catalog (not SCIM Groups — see getGroups). Cached per
     * ansira.groupcatalog.cache.ttl.ms, same mandatory reasoning as getUsers.
     */
    @Override
    public List<Entitlement> listGroupEntitlements() {
        return groupCatalogCache.get(() -> {
            ResponseEntity<String> resp = execute(HttpMethod.GET, "/Group", null);
            if (!resp.getStatusCode().is2xxSuccessful()) {
                throw errorFor(resp, "Failed to list Ansira group catalog");
            }
            return mapper.toGroupCatalog(parseJson(resp.getBody()));
        });
    }

    // -------------------------------------------------------------------------
    // Auth: per-request X-API-KEY forwarded from the inbound Basic Auth header
    // -------------------------------------------------------------------------

    private String resolveApiKey() {
        if (apiKey != null && !apiKey.isBlank()) {
            return apiKey;
        }
        return apiKeyFromInboundBasicAuth();
    }

    /**
     * Decodes the inbound SCIM request's own Basic Authorization header per
     * RFC 7617. CONFIRMED (OQ-008): the username sub-field is arbitrary and
     * ignored; the password sub-field carries the real X-API-KEY value, which
     * this connector forwards verbatim as the outbound X-API-KEY header — see
     * framework/specs/ansira.yaml delivery.agent_to_server_auth.
     */
    private String apiKeyFromInboundBasicAuth() {
        String header = currentRequest().getHeader(HttpHeaders.AUTHORIZATION);
        if (header == null || !header.regionMatches(true, 0, "Basic ", 0, 6)) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Missing Basic Authorization header — Okta must be configured to send the "
                            + "Ansira X-API-KEY value as the Basic Auth password (username is arbitrary)");
        }

        String decoded;
        try {
            decoded = new String(Base64.getDecoder().decode(header.substring(6).trim()),
                    StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Malformed Basic Authorization header");
        }

        int colon = decoded.indexOf(':');
        if (colon < 0) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Malformed Basic Authorization header");
        }

        String keyValue = decoded.substring(colon + 1);
        if (keyValue.isBlank()) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Basic Authorization password (Ansira X-API-KEY value) must not be blank");
        }
        return keyValue;
    }

    private HttpServletRequest currentRequest() {
        RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
        if (!(attrs instanceof ServletRequestAttributes servletAttrs)) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "No inbound HTTP request available to read the Ansira X-API-KEY from");
        }
        return servletAttrs.getRequest();
    }

    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------

    private static String encodePathSegment(String value) {
        return UriUtils.encodePathSegment(value, StandardCharsets.UTF_8);
    }

    private ResponseEntity<String> execute(HttpMethod method, String path, String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-API-KEY", resolveApiKey());
        if (body != null) {
            headers.setContentType(MediaType.APPLICATION_JSON);
        }
        return restTemplate.exchange(URI.create(baseUrl + path), method, new HttpEntity<>(body, headers), String.class);
    }

    /**
     * error_model is a confirmed permanent gap (OQ-006) — no specific error
     * codes/bodies are assumed; any non-2xx maps generically by HTTP status class.
     */
    private ScimErrorException errorFor(ResponseEntity<String> resp, String context) {
        int status = resp.getStatusCode().value();
        String detail = context + ": HTTP " + status;

        if (status == HttpStatus.NOT_FOUND.value()) {
            return ScimErrorException.notFound(detail);
        }
        if (status == HttpStatus.CONFLICT.value()) {
            return ScimErrorException.uniqueness(detail);
        }
        if (status == HttpStatus.TOO_MANY_REQUESTS.value()) {
            return new ScimErrorException(HttpStatus.TOO_MANY_REQUESTS, null, detail);
        }
        if (status >= 400 && status < 500) {
            return ScimErrorException.invalidValue(detail);
        }
        return new ScimErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "serverError", detail);
    }

    private JsonNode parseJson(String body) {
        if (body == null || body.isBlank()) {
            return objectMapper.createObjectNode();
        }
        try {
            return objectMapper.readTree(body);
        } catch (JacksonException e) {
            throw new ScimErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "serverError",
                    "Failed to parse Ansira response: " + e.getMessage());
        }
    }

    private String serialize(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JacksonException e) {
            throw new ScimErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "serverError",
                    "Failed to serialize request body: " + e.getMessage());
        }
    }
}
