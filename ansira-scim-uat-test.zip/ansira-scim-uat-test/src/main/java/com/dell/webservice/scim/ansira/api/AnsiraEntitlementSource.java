package com.dell.webservice.scim.ansira.api;

import com.okta.ps.scim.pojos.Entitlement;

import java.util.List;

/**
 * Lets AnsiraConnectorDescriptor fetch the group (entitlement) catalog from
 * whichever ConnectorApi bean is active (real or in-memory), mirroring
 * scim-connector-blackline's BlacklineEntitlementSource pattern — a small
 * dedicated interface Spring resolves per-profile, rather than the
 * descriptor depending on a concrete implementation.
 */
public interface AnsiraEntitlementSource {
    List<Entitlement> listGroupEntitlements();
}
