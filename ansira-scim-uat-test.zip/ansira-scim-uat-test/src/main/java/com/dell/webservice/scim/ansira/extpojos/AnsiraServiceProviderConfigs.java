package com.dell.webservice.scim.ansira.extpojos;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.okta.ps.scim.pojos.ServiceProviderConfigs;

import java.util.Map;

/**
 * Ansira-specific {@link ServiceProviderConfigs}, carrying the Okta-proprietary
 * userManagementCapabilities list under the urn:okta:schemas:scim:providerconfig:2.0
 * custom schema. core@1.0.0 (main) has no first-class support for this vendor
 * extension, so it's added here locally rather than in core — same pattern as
 * scim-connector-synchro-scim/scim-connector-prismacloud/scim-connector-salesworks/
 * scim-connector-blackline's extpojos.
 */
public class AnsiraServiceProviderConfigs extends ServiceProviderConfigs {

    @JsonProperty("urn:okta:schemas:scim:providerconfig:2.0")
    private Map<String, Object> customPropertiesMap;

    public Map<String, Object> getCustomPropertiesMap() { return customPropertiesMap; }
    public void setCustomPropertiesMap(Map<String, Object> customPropertiesMap) { this.customPropertiesMap = customPropertiesMap; }
}
