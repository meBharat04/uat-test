package com.dell.webservice.scim.ansira.api;

import com.dell.webservice.scim.ansira.mapper.AnsiraMapper;
import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.pojos.Email;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.Meta;
import com.okta.ps.scim.pojos.Name;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import com.okta.ps.scim.utils.StandardLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Component
@Profile("in-memory")
public class AnsiraConnectorApiInMem implements ConnectorApi, AnsiraEntitlementSource {

    private static final StandardLogger LOG = StandardLogger.forClass(AnsiraConnectorApiInMem.class);

    /** Keyed by userName — no separate opaque id exists on this target. */
    private final Map<String, ScimUserV2> users = new ConcurrentHashMap<>();
    private final List<Entitlement> groups = new ArrayList<>();

    /** Mirrors AnsiraConnectorApi's deferred-deactivate bookkeeping — see setEntitlement's javadoc. */
    private final Map<String, Long> pendingDeactivate = new ConcurrentHashMap<>();
    private static final long PENDING_DEACTIVATE_TTL_MS = 10_000L;

    @PostConstruct
    public void seed() {
        init();

        ScimUserV2 alex = newUser("1000123", "Alex", "Synthetic",
                "alex.synthetic@example.com", "Sales Rep", "3010");
        ScimUserV2 jordan = newUser("1000456", "Jordan", "Synthetic",
                "jordan.synthetic@example.com", "Sales Manager", "3020");
        users.put(alex.getUserName(), alex);
        users.put(jordan.getUserName(), jordan);

        groups.add(makeEntitlement("3010", "Sales Standard"));
        groups.add(makeEntitlement("3020", "Sales Manager"));
        // CONFIRMED (OQ-005) admin-only baseline group used by the separate,
        // non-automated "Disable Account (1.1)" step — kept in the catalog for
        // documentation/reference parity with framework/specs/ansira.yaml
        // test_fixtures.sample_groups; this double never calls it automatically.
        groups.add(makeEntitlement("4021", "Standard Access View Only"));

        LOG.info("AnsiraConnectorApiInMem seeded {} users", users.size());
    }

    @Override
    public void init() {
        LOG.info("AnsiraConnectorApiInMem initialized (in-memory, no real target).");
    }

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        return users.values().stream()
                .filter(u -> matches(u, filter))
                .collect(Collectors.toCollection(ArrayList::new));
    }

    @Override
    public ScimUserV2 getUser(String id) {
        // Mirrors AnsiraConnectorApi.getUser: core's PATCH path never calls
        // replaceUser(), so a PATCH-driven setEntitlement(remove) would otherwise
        // mark a pending deactivate that's never committed. Unlike replaceUser
        // (which has the caller's own user object to fall back on), getUser only
        // has the id — so on a fresh commit, synthesize the true resulting state
        // (inactive) instead of falling through to a lookup that would now 404.
        if (commitPendingDeactivateIfAny(id)) {
            ScimUserV2 stub = new ScimUserV2();
            stub.setId(id);
            stub.setUserName(id);
            stub.setActive(false);
            return stub;
        }
        return users.get(id);
    }

    /** Mirrors AnsiraConnectorApi.createUser: requires exactly one entitlement (CONFIRMED OQ-002). */
    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        String groupId = requireGroupId(user);
        ScimUserV2 stored = new ScimUserV2();
        stored.setId(user.getUserName());
        stored.setExternalId(user.getUserName());
        stored.setUserName(user.getUserName());
        stored.setName(user.getName());
        copyPrimaryEmail(user, stored);
        stored.setTitle(user.getTitle());
        stored.setActive(true); // hardcoded by Ansira's own provisioning policy, not a connector decision
        Meta m = new Meta("User");
        m.setCreated(Instant.now());
        m.setLastModified(Instant.now());
        stored.setMeta(m);

        UserEntitlement ent = new UserEntitlement(groupId, groupNameFor(groupId));
        ent.setType(AnsiraMapper.TYPE_GROUP);
        stored.getEntitlements().add(ent);

        users.put(stored.getUserName(), stored);
        return stored;
    }

    /**
     * Mirrors AnsiraConnectorApi.replaceUser: core unconditionally calls this
     * at the tail of every PUT, including pure deactivate/activate/
     * entitlement-only requests — see that method's javadoc for why a blind
     * throw would break PUT-based deactivation. Reject only a genuine
     * profile-field change; on an already-deactivated (removed) account,
     * report the true resulting state (inactive) rather than returning null
     * — a 404 from core's fallback would surface as an error for an
     * operation that actually succeeded.
     */
    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        commitPendingDeactivateIfAny(id);
        ScimUserV2 current = users.get(id);
        if (current == null) {
            // Mirrors AnsiraConnectorApi.replaceUser: most likely just
            // deactivated by this same PUT (CONFIRMED OQ-003 — revoking the
            // account's one entitlement always fully deactivates it). Report
            // the true resulting state instead of null, which would trigger
            // core's 404 fallback and surface as an error for an operation
            // that actually succeeded.
            user.setActive(false);
            return user;
        }
        if (hasGenuineProfileChange(current, user)) {
            throw ScimErrorException.notImplemented(
                    "Ansira has no profile-update endpoint — replaceUser is permanently out of scope for genuine profile-field changes");
        }
        return current;
    }

    private static boolean hasGenuineProfileChange(ScimUserV2 current, ScimUserV2 incoming) {
        Name currentName = current.getName();
        Name incomingName = incoming.getName();
        return !fieldsEqual(currentName != null ? currentName.getGivenName() : null,
                        incomingName != null ? incomingName.getGivenName() : null)
                || !fieldsEqual(currentName != null ? currentName.getFamilyName() : null,
                        incomingName != null ? incomingName.getFamilyName() : null)
                || !fieldsEqual(primaryEmailOf(current), primaryEmailOf(incoming))
                || !fieldsEqual(current.getTitle(), incoming.getTitle());
    }

    private static boolean fieldsEqual(String a, String b) {
        String na = (a == null || a.isBlank()) ? null : a;
        String nb = (b == null || b.isBlank()) ? null : b;
        return na == null ? nb == null : na.equals(nb);
    }

    private static String primaryEmailOf(ScimUserV2 user) {
        if (user.getEmails() == null) return null;
        for (Email e : user.getEmails()) {
            if (Boolean.TRUE.equals(e.getPrimary())) return e.getValue();
        }
        return user.getEmails().isEmpty() ? null : user.getEmails().get(0).getValue();
    }

    /** CONFIRMED (OQ-004): permanently out of scope. */
    @Override
    public void activateUser(String id) {
        throw ScimErrorException.notImplemented(
                "Ansira has no reactivate operation — a deactivated account must be re-created via createUser");
    }

    /**
     * Idempotent by design, mirroring AnsiraConnectorApi.callDeactivateEndpoint:
     * removing an absent key is a no-op, not an error — the real target's
     * single Deactivate endpoint is called twice per Okta deactivation (once
     * from here, once from setEntitlement(remove) below) and must tolerate
     * the redundant second call the same way.
     */
    @Override
    public void deactivateUser(String id) {
        users.remove(id);
    }

    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 u = getUser(userId);
        return u == null || u.getEntitlements() == null ? List.of() : new ArrayList<>(u.getEntitlements());
    }

    /**
     * add: REPLACES the account's single group. remove: CONFIRMED
     * (OQ-003/OQ-005) alias to deactivateUser — this target has no
     * independent "remove only the entitlement" operation.
     *
     * Mirrors AnsiraConnectorApi.setEntitlement's deferred-remove behavior:
     * core's applyEntitlementDiff() always processes removals before
     * additions for the same PUT, so an immediate deactivate on remove would
     * break an entitlement SWAP (remove old, add new) by killing the account
     * before the add ever runs. remove() only marks intent; add() cancels
     * any pending mark (its own PUT already achieves the swap); replaceUser
     * commits any mark still pending — the genuine revoke-to-zero case.
     */
    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        if (entitlementId == null || entitlementId.isBlank()) {
            throw ScimErrorException.invalidValue("entitlementId must not be blank");
        }
        if (add) {
            pendingDeactivate.remove(userId);
            ScimUserV2 u = users.get(userId);
            if (u == null) {
                return;
            }
            u.getEntitlements().clear();
            UserEntitlement ent = new UserEntitlement(entitlementId, groupNameFor(entitlementId));
            ent.setType(AnsiraMapper.TYPE_GROUP);
            u.getEntitlements().add(ent);
        } else {
            pendingDeactivate.put(userId, System.currentTimeMillis());
        }
    }

    private boolean commitPendingDeactivateIfAny(String userId) {
        Long markedAt = pendingDeactivate.remove(userId);
        if (markedAt != null && System.currentTimeMillis() - markedAt <= PENDING_DEACTIVATE_TTL_MS) {
            deactivateUser(userId);
            return true;
        }
        return false;
    }

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        return List.of();
    }

    @Override
    public List<Entitlement> listGroupEntitlements() {
        return new ArrayList<>(groups);
    }

    // -------------------------------------------------------------------------

    private static boolean matches(ScimUserV2 u, ScimFilter f) {
        if (f == null) return true;
        if (f.isUserNameEq()) {
            return f.getValue().equalsIgnoreCase(u.getUserName());
        }
        return true;
    }

    private static String requireGroupId(ScimUserV2 user) {
        List<UserEntitlement> entitlements = user.getEntitlements();
        if (entitlements == null || entitlements.isEmpty() || entitlements.get(0).getValue() == null
                || entitlements.get(0).getValue().isBlank()) {
            throw ScimErrorException.invalidValue(
                    "Ansira requires exactly one entitlement (groupId) to be set on every account creation — "
                            + "none was supplied for userName " + user.getUserName());
        }
        return entitlements.get(0).getValue();
    }

    private String groupNameFor(String groupId) {
        for (Entitlement e : groups) {
            if (groupId.equals(e.getId())) {
                return e.getDisplayName();
            }
        }
        return groupId;
    }

    private static void copyPrimaryEmail(ScimUserV2 from, ScimUserV2 to) {
        to.getEmails().clear();
        if (from.getEmails() != null && !from.getEmails().isEmpty()) {
            to.getEmails().addAll(from.getEmails());
        }
    }

    private static ScimUserV2 newUser(String userName, String firstName, String lastName,
                                       String email, String title, String groupId) {
        ScimUserV2 u = new ScimUserV2();
        u.setId(userName);
        u.setExternalId(userName);
        u.setUserName(userName);
        Name name = new Name();
        name.setGivenName(firstName);
        name.setFamilyName(lastName);
        name.setFormatted(firstName + " " + lastName);
        u.setName(name);
        Email e = new Email();
        e.setValue(email);
        e.setPrimary(true);
        u.getEmails().add(e);
        u.setTitle(title);
        u.setActive(true);
        UserEntitlement ent = new UserEntitlement(groupId, groupId);
        ent.setType(AnsiraMapper.TYPE_GROUP);
        u.getEntitlements().add(ent);
        Meta m = new Meta("User");
        m.setCreated(Instant.now());
        m.setLastModified(Instant.now());
        u.setMeta(m);
        return u;
    }

    private static Entitlement makeEntitlement(String id, String displayName) {
        Entitlement e = new Entitlement();
        e.setId(id);
        e.setDisplayName(displayName);
        e.setType(AnsiraMapper.TYPE_GROUP);
        return e;
    }
}
