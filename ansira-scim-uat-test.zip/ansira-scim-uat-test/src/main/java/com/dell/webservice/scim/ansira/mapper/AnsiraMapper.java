package com.dell.webservice.scim.ansira.mapper;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;
import com.okta.ps.scim.pojos.Email;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Name;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class AnsiraMapper {

    public static final String TYPE_GROUP = "group";

    private final ObjectMapper objectMapper;

    public AnsiraMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    // ---- Target -> SCIM (read direction) -----------------------------------

    /** GET /Account (list) or GET /Account/{userName} (single, wrapped the same way) — rootPath $.data. */
    public List<JsonNode> listItems(JsonNode listResponse) {
        List<JsonNode> items = new ArrayList<>();
        JsonNode arr = listResponse.path("data");
        if (arr.isArray()) {
            for (JsonNode n : arr) {
                items.add(n);
            }
        }
        return items;
    }

    /**
     * GET /Account/{userName} — CONFIRMED against a live tenant: wraps
     * "data" in a single-element ARRAY, exactly like the list endpoint —
     * NOT a bare object as originally assumed from the SailPoint export
     * alone. Reuses listItems() rather than duplicating the unwrap logic.
     * Returns null if the array is empty (not-found case).
     */
    public JsonNode singleItem(JsonNode singleResponse) {
        List<JsonNode> items = listItems(singleResponse);
        return items.isEmpty() ? null : items.get(0);
    }

    /**
     * Builds the full SCIM user from one Account row (identical shape whether
     * it came from the list or single-user endpoint — CONFIRMED, see
     * framework/specs/ansira.yaml connector_api.getUser.response_shape).
     * userName IS the identifier — there is no separate opaque id field on
     * this target (see attribute_mapping.match_key), so id/externalId are
     * both set from the same "userName" field read here, not passed in
     * separately.
     */
    public ScimUserV2 toScimUser(JsonNode row) {
        ScimUserV2 user = new ScimUserV2();
        String userName = row.path("userName").asText(null);
        user.setId(userName);
        user.setExternalId(userName);
        user.setUserName(userName);

        Name name = new Name();
        String firstName = row.path("firstName").asText(null);
        String lastName = row.path("lastName").asText(null);
        name.setGivenName(firstName);
        name.setFamilyName(lastName);
        if (firstName != null || lastName != null) {
            name.setFormatted(((firstName != null ? firstName : "") + " " +
                    (lastName != null ? lastName : "")).trim());
        }
        user.setName(name);

        String email = row.path("emailAddress").asText(null);
        if (email != null && !email.isBlank()) {
            Email e = new Email();
            e.setValue(email);
            e.setPrimary(true);
            user.getEmails().add(e);
        }

        user.setTitle(row.path("title").asText(null));

        JsonNode activeNode = row.path("isActive");
        user.setActive(activeNode.isMissingNode() || activeNode.isNull() ? null : activeNode.asBoolean());

        // groupId/groupName: NOT surfaced as inline SCIM user attributes — exposed only
        // via getEntitlementsByUserId as an Entitlement resource (see entitlements.model).
        String groupId = row.path("groupId").asText(null);
        if (groupId != null && !groupId.isBlank()) {
            String groupName = row.path("groupName").asText(groupId);
            UserEntitlement ent = new UserEntitlement(groupId, groupName);
            ent.setType(TYPE_GROUP);
            user.getEntitlements().add(ent);
        }

        return user;
    }

    /** GET /Group — {"data": [{"groupId","groupName"}]}. */
    public List<Entitlement> toGroupCatalog(JsonNode listResponse) {
        List<Entitlement> result = new ArrayList<>();
        JsonNode arr = listResponse.path("data");
        if (arr.isArray()) {
            for (JsonNode n : arr) {
                String groupId = n.path("groupId").asText(null);
                if (groupId == null || groupId.isBlank()) continue;
                Entitlement e = new Entitlement();
                e.setId(groupId);
                e.setDisplayName(n.path("groupName").asText(groupId));
                e.setType(TYPE_GROUP);
                result.add(e);
            }
        }
        return result;
    }

    // ---- SCIM -> Target (write direction) ----------------------------------

    /**
     * POST /Account body — CONFIRMED exact shape (see
     * framework/specs/ansira.yaml connector_api.createUser.request_shape).
     * The wire-level "userName" field's value is sourced from the identity's
     * employeeNumber/identificationNumber, but that already equals
     * user.getUserName() on this target (both fed from the same IDN
     * attribute per the Account Provisioning Policy) — the connector only
     * needs the one source value. isActive:true is sent explicitly to match
     * the confirmed template, even though Ansira's own provisioning policy
     * hardcodes it regardless (see attribute_mapping.hardcoded_fields).
     * groupId is REQUIRED non-blank — see AnsiraConnectorApi.createUser for
     * the fail-loudly check; this method assumes it has already been
     * validated non-blank by the caller.
     */
    public ObjectNode toCreateBody(ScimUserV2 user, String groupId) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("firstName", givenName(user));
        body.put("lastName", familyName(user));
        body.put("userName", user.getUserName());
        body.put("emailAddress", primaryEmail(user));
        body.put("title", user.getTitle());
        body.put("groupId", groupId);
        body.put("isActive", true);
        return body;
    }

    /** PUT /Account/{userId} body — add/replace this account's single group assignment. */
    public ObjectNode toSetGroupBody(String groupId) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("groupId", groupId);
        return body;
    }

    private static String givenName(ScimUserV2 user) {
        return user.getName() != null ? user.getName().getGivenName() : null;
    }

    private static String familyName(ScimUserV2 user) {
        return user.getName() != null ? user.getName().getFamilyName() : null;
    }

    private static String primaryEmail(ScimUserV2 user) {
        if (user.getEmails() == null) return null;
        for (Email e : user.getEmails()) {
            if (Boolean.TRUE.equals(e.getPrimary())) return e.getValue();
        }
        return user.getEmails().isEmpty() ? null : user.getEmails().get(0).getValue();
    }
}
