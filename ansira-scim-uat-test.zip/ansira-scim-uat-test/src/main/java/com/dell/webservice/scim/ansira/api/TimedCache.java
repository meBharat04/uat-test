package com.dell.webservice.scim.ansira.api;

import java.util.function.LongSupplier;
import java.util.function.Supplier;

/**
 * Caches a single value for a configurable TTL. Same pattern as
 * scim-connector-blackline/prismacloud/salesworks's TimedCache — connector
 * modules are independent siblings, not a shared library, so this is a
 * deliberate copy, not a shared dependency (see framework/developer-agent.md
 * "List caching").
 *
 * Used here for getUserList and the group (entitlement) catalog: neither
 * GET /Account nor GET /Group has server-side pagination (both return the
 * full dataset regardless of parameters — CONFIRMED, see
 * framework/specs/ansira.yaml target_api.pagination), but Okta's
 * on-premises provisioning agent still pages SCIM-level GET /Users/GET
 * /Entitlements in chunks — without this, every chunk would re-fetch the
 * entire upstream list.
 *
 * Takes a LongSupplier rather than a fixed long so the TTL is read lazily on
 * every get() — it always reflects the current configured value and picks up
 * config changes on the next expiry without a restart.
 */
class TimedCache<T> {

    private final LongSupplier ttlMillis;
    private T value;
    private long expiresAtMillis;

    TimedCache(LongSupplier ttlMillis) {
        this.ttlMillis = ttlMillis;
    }

    synchronized T get(Supplier<T> loader) {
        long now = System.currentTimeMillis();
        if (value == null || now >= expiresAtMillis) {
            value = loader.get();
            expiresAtMillis = now + ttlMillis.getAsLong();
        }
        return value;
    }
}
