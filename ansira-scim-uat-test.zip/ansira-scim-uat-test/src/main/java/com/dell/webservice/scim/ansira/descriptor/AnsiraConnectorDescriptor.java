package com.dell.webservice.scim.ansira.descriptor;

import com.okta.ps.scim.api.ConnectorDescriptor;
import com.dell.webservice.scim.ansira.api.AnsiraEntitlementSource;
import com.dell.webservice.scim.ansira.extpojos.AnsiraResourceType;
import com.dell.webservice.scim.ansira.extpojos.AnsiraServiceProviderConfigs;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.SchemaAttribute;
import com.okta.ps.scim.pojos.ScimResource;
import com.okta.ps.scim.pojos.ScimSchema;
import com.okta.ps.scim.pojos.ScimSchemas;
import com.okta.ps.scim.pojos.ServiceProviderConfigs;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class AnsiraConnectorDescriptor implements ConnectorDescriptor {

    private final AnsiraEntitlementSource entitlementSource;

    public AnsiraConnectorDescriptor(AnsiraEntitlementSource entitlementSource) {
        this.entitlementSource = entitlementSource;
    }

    @Override
    public ServiceProviderConfigs serviceProviderConfig() {
        AnsiraServiceProviderConfigs cfg = new AnsiraServiceProviderConfigs();
        cfg.getSchemas().add("urn:okta:schemas:scim:providerconfig:2.0");

        // patch: true — core's core >=1.1.1 PATCH-based entitlement reconciliation
        // covers this connector's one-entitlement-per-user model via the existing
        // getEntitlements/setEntitlement calls; no ConnectorApi changes needed.
        // core no longer diffs entitlements on PUT once PATCH is supported, so
        // this also restores the swap/revoke-to-zero behavior PUT used to own.
        // filter maxResults explicitly 100 per framework/specs/ansira.yaml
        // scim_advertisement.service_provider_config (a deliberate deviation from
        // the ServiceProviderConfigs default of 200 — filtering is applied
        // in-memory, no native target filter).
        cfg.setPatch(new ServiceProviderConfigs.Patch(true, 100));
        cfg.setChangePassword(new ServiceProviderConfigs.Supported(false));
        cfg.setFilter(new ServiceProviderConfigs.FilterFeature(true, 100));

        // Capabilities per spec scim_advertisement.user_management_capabilities:
        //   IMPORT_NEW_USERS: GET /Account
        //   IMPORT_PROFILE_UPDATES: getUser() always live-reads
        //   IMPORT_USER_SCHEMA: schemas()/resourceTypes() below declare real attributes —
        //     without this, Okta's "Test Connector Configuration" skips schema-driven
        //     attribute discovery entirely (lesson learned on Blackline/PrismaCloud/SalesWorks)
        //   PUSH_NEW_USERS: POST /Account
        //   GROUP_PUSH: setEntitlement add/remove (CONFIRMED OQ-003/OQ-005 — remove is an
        //     alias to deactivateUser's endpoint, full account deactivation)
        //   PUSH_USER_DEACTIVATION: PUT /Account/{userId}/Deactivate (CONFIRMED OQ-005)
        //   PUSH_PROFILE_UPDATES: advertised DESPITE OQ-001's "profile updates are out of
        //     scope" answer — live testing found Okta's OPP agent gates ANY non-deactivating
        //     PUT to /Users/{id} (including an entitlement-only "Revoke Entitlement" PUT
        //     that leaves active=true) behind this same capability flag, not just genuine
        //     profile-field edits. Without it, the agent never even attempted the entitlement
        //     revoke PUT. Safe to advertise: replaceUser is field-aware (see its javadoc) and
        //     still rejects a GENUINE firstName/lastName/emailAddress/title change with
        //     501/notImplemented — this only unblocks entitlement-only/deactivate-only PUTs
        //     that were always in scope.
        // NEVER advertised, CONFIRMED permanently out of scope: REACTIVATE_USERS (OQ-004)
        // NEVER advertised, confirmed absent: OPP_SCIM_INCREMENTAL_IMPORTS (deltaAggregationEnabled=false)
        cfg.setCustomPropertiesMap(Map.of("userManagementCapabilities", List.of(
                "IMPORT_NEW_USERS",
                "IMPORT_PROFILE_UPDATES",
                "IMPORT_USER_SCHEMA",
                "PUSH_NEW_USERS",
                "GROUP_PUSH",
                "PUSH_USER_DEACTIVATION",
                "PUSH_PROFILE_UPDATES")));

        cfg.getAuthenticationSchemes().add(
                new ServiceProviderConfigs.AuthenticationScheme(
                        "httpbasic",
                        "HTTP Basic Authorization",
                        "CONFIRMED (OQ-008): username sub-field is arbitrary/ignored; password "
                                + "sub-field carries the real Ansira X-API-KEY value, forwarded verbatim "
                                + "as the outbound X-API-KEY header on every call to Ansira"));

        return cfg;
    }

    @Override
    public List<Entitlement> entitlementCatalog() {
        return entitlementSource.listGroupEntitlements();
    }

    @Override
    public List<ScimResource> resourceTypes() {
        AnsiraResourceType userType = new AnsiraResourceType();
        userType.getSchemas().add(ScimSchemas.RESOURCE_TYPE);
        userType.setId("User");
        userType.setName("User");
        userType.setDescription("User Accounts");
        userType.setSchema(ScimSchemas.USER);
        userType.setEndpoint("/Users");
        // No enterprise extension — enterprise_extension: false in the spec
        // (employeeNumber's value already equals userName on this target).

        AnsiraResourceType entitlementType = new AnsiraResourceType();
        entitlementType.getSchemas().add(ScimSchemas.RESOURCE_TYPE);
        entitlementType.setId("Entitlement");
        entitlementType.setName("Entitlement");
        entitlementType.setDescription("Ansira access group entitlement");
        entitlementType.setSchema(ScimSchemas.ENTITLEMENT);
        entitlementType.setEndpoint("/Entitlements");

        // No Group — Ansira's group is a target-native access-level concept
        // (OIG Entitlement), not an Okta-pushed group. See
        // framework/specs/ansira.yaml scim_advertisement.resource_types.
        return List.of(userType, entitlementType);
    }

    @Override
    public List<ScimSchema> schemas() {
        ScimSchema userSchema = new ScimSchema();
        userSchema.setId(ScimSchemas.USER);
        userSchema.setName("User");
        userSchema.setAttributes(List.of(
                SchemaAttribute.simple("userName", "string", true),
                SchemaAttribute.simple("active", "boolean", false),
                SchemaAttribute.simple("title", "string", false),
                nameAttribute(),
                emailsAttribute()));

        ScimSchema entitlementSchema = new ScimSchema();
        entitlementSchema.setId(ScimSchemas.ENTITLEMENT);
        entitlementSchema.setName("Entitlement");

        return List.of(userSchema, entitlementSchema);
    }

    private static SchemaAttribute nameAttribute() {
        SchemaAttribute name = SchemaAttribute.simple("name", "complex", false);
        name.setSubAttributes(List.of(
                SchemaAttribute.simple("givenName", "string", false),
                SchemaAttribute.simple("familyName", "string", false),
                SchemaAttribute.simple("formatted", "string", false)));
        return name;
    }

    private static SchemaAttribute emailsAttribute() {
        SchemaAttribute emails = SchemaAttribute.simple("emails", "complex", false);
        emails.setMultiValued(true);
        emails.setSubAttributes(List.of(
                SchemaAttribute.simple("value", "string", false),
                SchemaAttribute.simple("primary", "boolean", false)));
        return emails;
    }
}
