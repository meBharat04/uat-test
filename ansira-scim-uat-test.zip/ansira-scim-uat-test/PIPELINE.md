# Dell GitLab Pipeline — Setup Reference

> This document covers the Dell GitLab CI/CD pipeline for SCIM connectors. It applies to both
> human developers and AI agents working on new connectors. The OpenText ECM nonprod connector
> was the first to go through this process and is the reference implementation.

---

## How it works

Each connector is delivered as a **standalone GitLab project** on Dell's GitLab
(`gitlab.dell.com/security/iam/okta/corp/iga/<connector-name>`). The pipeline is defined by
`.gitlab-ci.yml` and runs automatically on every push to a `feature/*` or `main` branch.

### Pipeline stages

```
build → verify-build
```

| Stage | Job | Hard stop? | Purpose |
|---|---|---|---|
| `build` | `compile-build` | Yes | Compiles and packages the WAR via Maven |
| `verify-build` | `unit-test` | No | Runs JUnit tests |
| `verify-build` | `code-quality1` | No | SonarQube static analysis |
| `verify-build` | `xray-scan1` | Yes | JFrog Xray vulnerability scan |
| `verify-build` | `sast-scan` | No | Static Application Security Testing |
| `verify-build` | `sca-scan` | No | Snyk Software Composition Analysis |

Deploy stages (`pre-deploy`, `deploy`, `validate-deploy`, `rollback`) are defined but require
Jebastin / Dell DevOps to confirm IGA-specific values before enabling — see TODOs in
`.gitlab-ci.yml`.

---

## Files in this directory

| File | Purpose | Needs change for new connector? |
|---|---|---|
| `.gitlab-ci.yml` | Pipeline definition — copy and update `APP_NAME` | Yes — `APP_NAME` only |
| `setting.xml` | Maven settings pointing to Dell Artifactory | No — shared across all connectors |
| `.mvn/wrapper/maven-wrapper.properties` | Pins Maven 3.9.9 | No |
| `Dockerfile` | Container image build (Tomcat + JRE21 + Dell certs) | Yes — update WAR filename |
| `k8s_configs/manifest.yml` | kob deployment manifest (PCF format with `((placeholders))`) | No |
| `k8s_configs/deployment-test.yml` | K8s Deployment spec for testing | Yes — update `name` and `image` |
| `k8s_configs/service-test.yml` | K8s Service spec | Yes — update `name` |

---

## Setting up the pipeline for a new connector

### Step 1 — Create the GitLab project

Ask the Dell GitLab admin (Jebastin / OMC team) to create the project under
`security/iam/okta/corp/iga/<connector-name>` with a README (required to create branches).

### Step 2 — Copy pipeline files

Copy all files from this directory to the new connector:
- `.gitlab-ci.yml`
- `setting.xml`
- `.mvn/wrapper/maven-wrapper.properties`
- `Dockerfile`
- `k8s_configs/`

### Step 3 — Update connector-specific values

**`.gitlab-ci.yml`** — change only `APP_NAME`:
```yaml
APP_NAME: <your-connector-name>   # e.g. fuse-scim, list-price-manager-scim
```

**`Dockerfile`** — change the WAR filename:
```dockerfile
COPY target/*.war /usr/local/tomcat/webapps/<your-connector-name>.war
```

**`k8s_configs/deployment-test.yml`** — update `name` and `image` (3 places each):
```yaml
name: <your-connector-name>
image: harbor.dell.com/iam-okta-harbor/<your-connector-name>:_BUILD_VERSION
```

**`k8s_configs/service-test.yml`** — update `name`:
```yaml
name: <your-connector-name>-service
```

### Step 4 — Confirm deploy values with Jebastin

The `.gitlab-ci.yml` has a TODO block for `.kobvariablesdev`. Get the correct values for
the IGA namespace from Jebastin before enabling deploy jobs:

```yaml
# TODO: confirm with Jebastin
GLOBAL_DOMAIN: "opa-dev.kob.dell.com"      # may differ for IGA
CLUSTER_DOMAIN: "opa-dev-a4-np.kob.dell.com"  # may differ for IGA
VAULT_CONFIG_PATH: kv/KOB/dev-core         # may differ for IGA
```

### Step 5 — Add pom.xml plugins

The connector `pom.xml` must include the SonarQube and JaCoCo plugins for `code-quality1`
to work. See this connector's `pom.xml` for the exact plugin definitions.

### Step 6 — Application class — critical WAR deployment fix

The connector's main application class **must** have `@Configuration` to ensure Spring
processes the `@ComponentScan` when the WAR starts in external Tomcat. Without it,
Spring cannot find the `ConnectorDescriptor` bean and the app fails to start.

```java
import org.springframework.context.annotation.Configuration;

@Configuration  // ← required — DO NOT OMIT
@ComponentScan(basePackages = {"com.okta.ps.scim", "com.dell.webservice.scim.<connector>"})
public class <App>Application extends SpringBootServletInitializer {
    ...
}
```

---

## Delivery structure vs. forge structure

This forge repo uses `connectors/<name>/` nesting. The Dell GitLab delivery is **flat**
(connector files at repo root). The only difference this causes is in `pom.xml`:

| Location | `<repositories>` URL |
|---|---|
| This forge repo | `file://${project.basedir}/../../repo` |
| Dell GitLab delivery | `file://${project.basedir}/repo` |

When packaging for Dell GitLab delivery, change the repo URL in `pom.xml`.

---

## Known issues encountered during OpenText setup

| Issue | Cause | Fix |
|---|---|---|
| `mvn: command not found` | `$JAVA_21_JDK_IMG` group variable not inherited | Ask Jebastin to confirm variable is set at IGA group level |
| `DependencyResolutionException` on `scim-connector-core` | Core POMs in `repo/` had `null object or invalid expression` version and old parent | Fix all `.pom` files in `repo/.../1.1.0-SNAPSHOT/` — see correct POM content below |
| `ConnectorDescriptor bean not found` on K8s deploy | `@Configuration` missing from application class | Add `@Configuration` to the connector's `Application.java` |
| `No plugin found for prefix 'sonar'` | `sonar-maven-plugin` not in `pom.xml` | Add sonar + jacoco plugins to `pom.xml` |
| SSH port 22 and 443 timeout to GitLab | Mac not on Dell corporate network | Use PAT over HTTPS once on VPN, or push from VDI |

### Correct Core POM content for `repo/`

All `.pom` files under `repo/com/okta/ps/scim/scim-connector-core/1.1.0-SNAPSHOT/` must be:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.okta.ps.scim</groupId>
    <artifactId>scim-connector-core</artifactId>
    <version>1.1.0-SNAPSHOT</version>
    <packaging>jar</packaging>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
            <version>3.5.0</version>
            <exclusions>
                <exclusion>
                    <groupId>org.springframework.boot</groupId>
                    <artifactId>spring-boot-starter-logging</artifactId>
                </exclusion>
            </exclusions>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-log4j2</artifactId>
            <version>3.5.0</version>
        </dependency>
    </dependencies>
</project>
```

---

## Viewing scan results

| Scan | Where to view |
|---|---|
| Xray (vuln scan) | `artifacts.dell.com` → Xray → Violations |
| SAST | GitLab project → Security & Compliance → Vulnerability Report |
| Snyk (SCA) | URL printed in `sca-scan` job log → `app.snyk.io/org/dell-1011273/...` |
| SonarQube | `sonarqube.dell.com` → search project by name |
