# CSE SCIM 2.0 Connector

Welcome to your new repo, **CSE-scim**!  
This connector is built to integrate **Okta** with **CSE** using SCIM 2.0 standards.
 
---

## CSE Configuration Properties

>  All CSE connection settings are configured in
> `src/main/resources/application.properties` and injected via Spring `@Value`.

| Property        | Sample Value                                                                                              | Mandatory | Description                                                                 |
|------------------|------------------------------------------------------------------------------------------------------------|-----------|-------------------------------------------------------------------------------|
| cse.token-url    | https://www-sit-g4.dell.com/di/api/v3/oauth/token                                                          | Yes       | CSE OAuth token endpoint used to obtain the bearer access token               |
| cse.base-url     | https://csengagementservices-projectemployeemanagement-ge4.cscore-np.pcf.dell.com/Api/v1/EmployeeDetails   | Yes       | Base URL for all CSE Employee Details API calls (users, roles, create, add/remove role) |
| cse.grant-type   | client_credentials                                                                                          | Yes       | OAuth grant type sent when requesting the access token                       |

The individual API paths (get users, get user by id, get roles, create user, add/remove role)
are appended to `cse.base-url` in code (`CSEApiImpl`), so they don't need to be configured separately.

---

## Client ID / Client Secret Handling

`CLIENT_ID` and `CLIENT_SECRET` are **not** stored in any properties file. Okta calls this
connector with HTTP Basic Authentication on every request, and the credentials are handled
per-request:

1. Okta sends the request with an `Authorization: Basic <base64(clientId:clientSecret)>` header.
2. `HelperUtils.extractAndSetClientCredentials(...)` decodes that header on each controller call
   and sets `CLIENT_ID` / `CLIENT_SECRET` on the shared `Properties` instance.
3. `CSEApiImpl.generateToken()` reads those values back out of `Properties` and uses them, along
   with `cse.grant-type`, to request an OAuth access token from `cse.token-url`.
4. The resulting access token is cached and reused for subsequent CSE API calls until it expires
   or a `401` is received, at which point a new token is generated.

Because the credentials come from the inbound Basic Auth header rather than a config file, they
never need to be manually configured or rotated in this project — only the Okta connector
configuration needs the correct client id/secret.

---

## Prerequisites

- Java 21+
- Maven 3.8+

## Running the Application

1. Set the `cse.token-url`, `cse.base-url`, and `cse.grant-type` values in
   `src/main/resources/application.properties` for the target environment.
2. Build the project:
   mvn clean package
3. Deploy the generated WAR file (CSEScim.war) to Tomcat or run the JAR file if packaged as JAR:
   java -jar target/CSEScim.jar
4. Access the SCIM service:
   http://localhost:8080/CSEScim/
