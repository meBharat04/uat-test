package com.dell.webservice.api;

import com.dell.webservice.pojos.ScimFilter;
import com.dell.webservice.utils.HelperUtils;
import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;

import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

public class CSEApiInMem implements CSEApi{
    ObjectMapper objectMapper = new ObjectMapper();
    private final Map<String, ObjectNode> roles = new ConcurrentHashMap<>();
    private final Map<String, ObjectNode> users = new ConcurrentHashMap<>();
    private static final String ROLES_JSON = "[\n" +
            "  {\n" +
            "    \"RoleId\": 2.0,\n" +
            "    \"RoleDescription\": \"USER_ADMIN\",\n" +
            "    \"RoleName\": \"Manage Users and Assign User Roles\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 1.0,\n" +
            "    \"RoleDescription\": \"PRODUCT_ADMIN\",\n" +
            "    \"RoleName\": \"Manage LOB, Chassis\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 9.0,\n" +
            "    \"RoleDescription\": \"CC Engineer\",\n" +
            "    \"RoleName\": \"CC Engineer Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 10.0,\n" +
            "    \"RoleDescription\": \"PROC_Vendor\",\n" +
            "    \"RoleName\": \"Procurement Vendor Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 11.0,\n" +
            "    \"RoleDescription\": \"PROC_ReadOnly\",\n" +
            "    \"RoleName\": \"Procurement ReadOnly Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 14.0,\n" +
            "    \"RoleDescription\": \"Project Manager\",\n" +
            "    \"RoleName\": \"Project Manager\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 4.0,\n" +
            "    \"RoleDescription\": \"WIP Lead\",\n" +
            "    \"RoleName\": \"WIP Lead Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 5.0,\n" +
            "    \"RoleDescription\": \"Dev Engineer\",\n" +
            "    \"RoleName\": \"Dev Engineer Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 6.0,\n" +
            "    \"RoleDescription\": \"Audit Engineer\",\n" +
            "    \"RoleName\": \"Audit Engineer Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 7.0,\n" +
            "    \"RoleDescription\": \"IVE Engineer\",\n" +
            "    \"RoleName\": \"IVE Engineer Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 8.0,\n" +
            "    \"RoleDescription\": \"OFA Engineer\",\n" +
            "    \"RoleName\": \"OFA Engineer Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 3.0,\n" +
            "    \"RoleDescription\": \"ORDER_ADMIN\",\n" +
            "    \"RoleName\": \"Order First Admin Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 12.0,\n" +
            "    \"RoleDescription\": \"FactoryAdmin\",\n" +
            "    \"RoleName\": \"Factory Admin Functions\"\n" +
            "  },\n" +
            "  {\n" +
            "    \"RoleId\": 13.0,\n" +
            "    \"RoleDescription\": \"Sales Representative\",\n" +
            "    \"RoleName\": \"Sales Representative\"\n" +
            "  }\n" +
            "]";

    String USER_JSON = "{\n" +
            "   \"employeeDetails\": [\n" +
            "      {\n" +
            "         \"emp_id\": 1.0,\n" +
            "         \"emp_login_name\": \"Arunachalam_Ramaiah_XXX\",\n" +
            "         \"emp_roles\": null,\n" +
            "         \"emp_email\": \"Arunachalam.Ramaiah.XXX@Dell.com\",\n" +
            "         \"emp_status\": false,\n" +
            "         \"emp_first_name\": \"Arunachalam\",\n" +
            "         \"emp_last_name\": \"Ramaiah\",\n" +
            "         \"emp_timezone_ref_id\": null,\n" +
            "         \"emp_timezone_name\": null,\n" +
            "         \"emp_timezone_description\": null,\n" +
            "         \"UserGroups\": [],\n" +
            "         \"EmployeeRoles\": null\n" +
            "      },\n" +
            "      {\n" +
            "         \"emp_id\": 2.0,\n" +
            "         \"emp_login_name\": \"EMEA_WISE\",\n" +
            "         \"emp_roles\": null,\n" +
            "         \"emp_email\": \"XXX.XXX.ROBERT.WISE@DELL.COM\",\n" +
            "         \"emp_status\": true,\n" +
            "         \"emp_first_name\": \"EMEA\",\n" +
            "         \"emp_last_name\": \"Wise\",\n" +
            "         \"emp_timezone_ref_id\": null,\n" +
            "         \"emp_timezone_name\": null,\n" +
            "         \"emp_timezone_description\": null,\n" +
            "         \"UserGroups\": [],\n" +
            "         \"EmployeeRoles\": null\n" +
            "      },\n" +
            "      {\n" +
            "         \"emp_id\": 3.0,\n" +
            "         \"emp_login_name\": \"CHAD_A_RIVES\",\n" +
            "         \"emp_roles\": null,\n" +
            "         \"emp_email\": \"XXX.XXX.CHAD.A.RIVES@DELL.COM\",\n" +
            "         \"emp_status\": true,\n" +
            "         \"emp_first_name\": \"Chad\",\n" +
            "         \"emp_last_name\": \"Rives\",\n" +
            "         \"emp_timezone_ref_id\": null,\n" +
            "         \"emp_timezone_name\": null,\n" +
            "         \"emp_timezone_description\": null,\n" +
            "         \"UserGroups\": [],\n" +
            "         \"EmployeeRoles\": null\n" +
            "      },\n" +
            "      {\n" +
            "         \"emp_id\": 4.0,\n" +
            "         \"emp_login_name\": \"rona_mayer\",\n" +
            "         \"emp_roles\": null,\n" +
            "         \"emp_email\": \"XXX.XXX.Rona.Mayer@Dell.com\",\n" +
            "         \"emp_status\": true,\n" +
            "         \"emp_first_name\": \"Rona\",\n" +
            "         \"emp_last_name\": \"Mayer\",\n" +
            "         \"emp_timezone_ref_id\": null,\n" +
            "         \"emp_timezone_name\": null,\n" +
            "         \"emp_timezone_description\": null,\n" +
            "         \"UserGroups\": [],\n" +
            "         \"EmployeeRoles\": null\n" +
            "      },\n" +
            "      {\n" +
            "         \"emp_id\": 5.0,\n" +
            "         \"emp_login_name\": \"hiep_m_nguyen\",\n" +
            "         \"emp_roles\": null,\n" +
            "         \"emp_email\": \"XXX.XXX.hiep.m.nguyen@dell.com\",\n" +
            "         \"emp_status\": true,\n" +
            "         \"emp_first_name\": \"Hiep\",\n" +
            "         \"emp_last_name\": \"M_nguyen\",\n" +
            "         \"emp_timezone_ref_id\": null,\n" +
            "         \"emp_timezone_name\": null,\n" +
            "         \"emp_timezone_description\": null,\n" +
            "  \"UserGroups\": [\n" +
            "    {\n" +
            "      \"GroupName\": \"AMF_WIPL\",\n" +
            "      \"GroupId\": 1,\n" +
            "      \"UserId\": 0,\n" +
            "      \"Description\": null,\n" +
            "      \"Region\": 0,\n" +
            "      \"JobId\": 0,\n" +
            "      \"JobCode\": null,\n" +
            "      \"Status\": false,\n" +
            "      \"NumberOfUsers\": null,\n" +
            "      \"employeeDetailsList\": null,\n" +
            "      \"IsFavourite\": null,\n" +
            "      \"NumberOfUnassignedTasks\": null,\n" +
            "      \"CreatedDate\": \"0001-01-01T00:00:00\",\n" +
            "      \"CreatedBy\": null,\n" +
            "      \"ModifiedDate\": null,\n" +
            "      \"ModifiedBy\": null,\n" +
            "      \"DevelopmentLocation\": null,\n" +
            "      \"DevelopmentLocationRefId\": 0,\n" +
            "      \"JobRoleId\": null,\n" +
            "      \"ErrorMsg\": null,\n" +
            "      \"IsFederal\": false,\n" +
            "      \"DevelopmentLocationRef\": null\n" +
            "    }\n" +
            "  ],\n" +
            "    \"EmployeeRoles\": [\n" +
            "      {\n" +
            "        \"EmployeeRoleId\": 51012.0,\n" +
            "        \"EmployeeID\": 5.0,\n" +
            "        \"RoleId\": 12.0,\n" +
            "        \"RoleName\": \"FactoryAdmin\",\n" +
            "        \"CreatedDate\": \"0001-01-01T00:00:00\",\n" +
            "        \"CreatedBy\": \"IdentityNow\",\n" +
            "        \"ModifiedDate\": null,\n" +
            "        \"ModifiedBy\": \"IdentityNow\"\n" +
            "      },\n" +
            "      {\n" +
            "        \"EmployeeRoleId\": 51013.0,\n" +
            "        \"EmployeeID\": 5.0,\n" +
            "        \"RoleId\": 9.0,\n" +
            "        \"RoleName\": \"CC Engineer\",\n" +
            "        \"CreatedDate\": \"0001-01-01T00:00:00\",\n" +
            "        \"CreatedBy\": \"IdentityNow\",\n" +
            "        \"ModifiedDate\": null,\n" +
            "        \"ModifiedBy\": \"IdentityNow\"\n" +
            "      }\n" +
            "    ]\n" +
            "      },\n" +
            "      {\n" +
            "         \"emp_id\": 6.0,\n" +
            "         \"emp_login_name\": \"stephan_moran\",\n" +
            "         \"emp_roles\": null,\n" +
            "         \"emp_email\": \"XXX.XXX.stephan.moran@dell.com\",\n" +
            "         \"emp_status\": true,\n" +
            "         \"emp_first_name\": \"Stephan\",\n" +
            "         \"emp_last_name\": \"Moran\",\n" +
            "         \"emp_timezone_ref_id\": null,\n" +
            "         \"emp_timezone_name\": null,\n" +
            "         \"emp_timezone_description\": null,\n" +
            "         \"UserGroups\": [],\n" +
            "         \"EmployeeRoles\": null\n" +
            "      },\n" +
            "      {\n" +
            "         \"emp_id\": 7.0,\n" +
            "         \"emp_login_name\": \"marcelo_juliano\",\n" +
            "         \"emp_roles\": null,\n" +
            "         \"emp_email\": \"XXX.XXX.Marcelo.juliano@dell.com\",\n" +
            "         \"emp_status\": true,\n" +
            "         \"emp_first_name\": \"Marcelo\",\n" +
            "         \"emp_last_name\": \"Juliano\",\n" +
            "         \"emp_timezone_ref_id\": null,\n" +
            "         \"emp_timezone_name\": null,\n" +
            "         \"emp_timezone_description\": null,\n" +
            "         \"UserGroups\": [],\n" +
            "         \"EmployeeRoles\": null\n" +
            "      }\n" +
            "   ]\n" +
            "}";

    public CSEApiInMem() {
        try {
            JsonNode rootNode = objectMapper.readTree(ROLES_JSON);
            if (rootNode.isArray()) {
                ArrayNode list = (ArrayNode) rootNode;
                for (JsonNode node : list) {
                    String id = HelperUtils.normalizeId(node.get("RoleId"));
                    roles.put(id, (ObjectNode) node);
                }
            }

            JsonNode rootNode1 = objectMapper.readTree(USER_JSON);
            JsonNode employeeArray = rootNode1.get("employeeDetails");
            if (employeeArray != null && employeeArray.isArray()) {
                for (JsonNode node : employeeArray) {
                    String id = HelperUtils.normalizeId(node.get("emp_id"));
                    users.put(id, (ObjectNode) node);
                }
            }
        } catch (JacksonException e) {
            throw new RuntimeException("Failed to initialize CSEApiInMem", e);
        }
    }
    @Override
    public Properties getProperties() {
        Properties fakeProps = new Properties();
        return fakeProps;
    }
    @Override
    public void generateToken() {
//        return "InMem";
    }
    @Override
    public JsonNode getRoles() {
        String json = ROLES_JSON;
        JsonNode jsonNode = null;
        try {
            JsonNode rootArray = objectMapper.readTree(json);
            return rootArray;
        } catch (JacksonException e) {
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public JsonNode getUsers(Integer pageNo, Integer pageSize, ScimFilter filter) {
        try {
            return objectMapper.readTree(USER_JSON);
//            return root.get("employeeDetails");
        } catch (JacksonException e) {
            e.printStackTrace();
            return null;
        }
    }
    public JsonNode getUser(String Id) {
        return users.get(HelperUtils.normalizeId(Id));
    }
    @Override
    public JsonNode createUser(JsonNode userNode){
        String json = "{\n" +
                "  \"empId\":5.0\n" +
                "}";
        JsonNode jsonNode = null;
        try {
            JsonNode rootArray = objectMapper.readTree(json);
            return rootArray;
        } catch (JacksonException e) {
            e.printStackTrace();
            return null;
        }
    }
    public JsonNode addRoles(JsonNode userNode, String userId) {

        // Only add if not already present
        JsonNode roleNode = userNode.isArray() && userNode.size() > 0 ? userNode.get(0) : userNode;
        String groupId = roleNode.get("roleId").asText();
        if (!roles.containsKey(groupId)) {
            ObjectNode groupNode = objectMapper.createObjectNode();
            ObjectNode requestedObject = objectMapper.createObjectNode();
            requestedObject.put("RoleId", groupId);
            requestedObject.put("RoleName", groupId);
            roles.put(groupId, requestedObject);
        }
        JsonNode jsonNode = null;
        try {
            return  objectMapper.readTree("true");
        } catch (JacksonException e) {
            e.printStackTrace();
            return null;
        }
    }
    @Override
    public JsonNode removeRole(JsonNode userNode,String userId) {

        JsonNode jsonNode = null;
        try {
            return  objectMapper.readTree("true");
        } catch (JacksonException e) {
            e.printStackTrace();
            return null;
        }
    }
}
