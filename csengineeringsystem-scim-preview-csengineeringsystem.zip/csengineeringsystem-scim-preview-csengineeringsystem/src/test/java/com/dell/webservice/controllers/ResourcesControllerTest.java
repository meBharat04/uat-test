package com.dell.webservice.controllers;

import com.dell.webservice.pojos.ScimResource;
import com.dell.webservice.pojos.ScimResourceList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ResourcesControllerTest {
    private ResourcesController controller;

    @BeforeEach
    void setUp() {
        controller = new ResourcesController();
    }

    @Test
    void listAllResourcesTest() throws Exception {
        ScimResourceList<ScimResource> response = controller.listAllResources();

        assertNotNull(response);
        assertEquals(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"), response.getSchemas());
        assertEquals(2, response.getTotalResults());
        assertEquals(1, response.getStartIndex());
        assertEquals(2, response.getItemsPerPage());
        assertNotNull(response.getResources());
        assertEquals(2, response.getResources().size());
    }

    @Test
    void listAllResourcesTestWithUserResource() throws Exception {
        ScimResourceList<ScimResource> response = controller.listAllResources();

        ScimResource userResource = response.getResources().stream()
                .filter(r -> "User".equals(r.getId()))
                .findFirst()
                .orElseThrow();

        assertEquals("User", userResource.getId());
        assertEquals("User", userResource.getName());
        assertEquals("User Accounts", userResource.getDescription());
        assertEquals("/Users", userResource.getEndpoint());
        assertEquals("urn:ietf:params:scim:schemas:core:2.0:User", userResource.getSchema());
    }

    @Test
    void listAllResourcesTestContainsRoleResource() throws Exception {
        ScimResourceList<ScimResource> response = controller.listAllResources();

        ScimResource roleResource = response.getResources().stream()
                .filter(r -> "Roles".equals(r.getId()))
                .findFirst()
                .orElseThrow();

        assertEquals("Roles", roleResource.getId());
        assertEquals("Roles", roleResource.getName());
        assertEquals("Roles resource", roleResource.getDescription());
        assertEquals("/Roles", roleResource.getEndpoint());
        assertEquals("urn:okta:scim:schemas:core:1.0:Role", roleResource.getSchema());
    }
}
