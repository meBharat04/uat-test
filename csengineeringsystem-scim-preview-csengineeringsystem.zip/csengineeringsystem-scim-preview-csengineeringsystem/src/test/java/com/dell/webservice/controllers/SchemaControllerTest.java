package com.dell.webservice.controllers;

import com.dell.webservice.pojos.ScimResourceList;
import com.dell.webservice.pojos.ScimSchema;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class SchemaControllerTest {
    private SchemaController controller;

    @BeforeEach
    void setUp() {
        controller = new SchemaController();
    }
    @Test
    void getCoreUserSchemaTest() throws Exception {
        ScimResourceList<ScimSchema> response = controller.defaultGet();

        assertNotNull(response);
        assertEquals(3, response.getTotalResults());
        assertEquals(3, response.getResources().size());

        ScimSchema coreUserSchema = response.getResources().get(1);
        assertEquals("urn:ietf:params:scim:schemas:core:2.0:User", coreUserSchema.getId());
        assertEquals("User", coreUserSchema.getName());
        assertEquals("User Account", coreUserSchema.getDescription());
        assertFalse(coreUserSchema.getAttributes().isEmpty());

        ScimSchema enterpriseSchema = response.getResources().get(2);
        assertEquals("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User", enterpriseSchema.getId());
        assertEquals("EnterpriseUser", enterpriseSchema.getName());
        assertEquals("Enterprise User", enterpriseSchema.getDescription());
        assertFalse(enterpriseSchema.getAttributes().isEmpty());
    }
    @Test
    void getExtendedUserSchemaTest() throws Exception {
        ScimResourceList<ScimSchema> response = controller.defaultGet();

        ScimSchema coreUserSchema = response.getResources().get(1);

        assertTrue(coreUserSchema.getAttributes()
                .stream()
                .anyMatch(attr -> attr.getName().equals("userName")));

        assertTrue(coreUserSchema.getAttributes()
                .stream()
                .anyMatch(attr -> attr.getName().equals("emails")));

        ScimSchema enterpriseSchema = response.getResources().get(2);

        assertEquals(2, enterpriseSchema.getAttributes().size());
        assertTrue(enterpriseSchema.getAttributes()
                .stream()
                .anyMatch(attr -> attr.getName().equals("employeeNumber")));
        assertTrue(enterpriseSchema.getAttributes()
                .stream()
                .anyMatch(attr -> attr.getName().equals("csId")));
    }
}
