package com.dell.webservice.controllers;

import com.dell.webservice.api.CSEApi;
import com.dell.webservice.api.CSEApiInMem;
import com.dell.webservice.pojos.*;
import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

import java.io.FileNotFoundException;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

public class UserControllerTest {
    @Mock
    private UserController controller;
    @Mock
    private CSEApi cseApi;
    private ObjectMapper objectMapper;
    private String basicAuthValue= "Basic QWRtaW5pc3RyYXRvcjpUZXN0QVBJS2V5";

    @BeforeEach
    void setUp() throws FileNotFoundException {
        cseApi = new CSEApiInMem();
        controller = new UserController(cseApi);
        objectMapper = new ObjectMapper();
    }

    @Test
    void getUsersTest() throws Exception {
        ScimResourceList<ScimUserV2> response = controller.getUsers(null, 7, 0, basicAuthValue);
        assertNotNull(response);
        assertEquals(7, response.getResources().size());
        assertEquals("1", response.getResources().getFirst().getId());
        assertEquals("Arunachalam", response.getResources().getFirst().getName().getGivenName());

    }
    @Test
    void getUserTest(){
        ScimUserV2 response = controller.getUser("5", basicAuthValue);
        assertNotNull(response);
        assertEquals("5", response.getId());
        assertEquals("Hiep", response.getName().getGivenName());
        assertNotNull(response.getScimUserV2CustomAttributes());
        assertEquals("5", response.getScimUserV2CustomAttributes().getEmployeeNumber());
        assertEquals("5", response.getScimUserV2CustomAttributes().getCsId());
    }
    @Test
    void getUserTest_normalizesDottedId(){
        ScimUserV2 response = controller.getUser("5.0", basicAuthValue);
        assertNotNull(response);
        assertEquals("5", response.getId());
    }
    @Test
    void createUserTest(){
        ScimResource resourcelist = new ScimResource();
        resourcelist.setId("5");
        resourcelist.setDescription("Description");

        List<Email> emailList = new ArrayList<>();
        Email email = new Email();
        email.setValue("test.com");
        email.setPrimary(true);
        email.setType("work");
        emailList.add(email);

        Name name = new Name();
        name.setFamilyName("test1");
        name.setGivenName("test");

        List<UserRole> list = new ArrayList<>();
        UserRole role = new UserRole();
        role.setValue("12");
        role.setDisplayName("FactoryAdmin");
        list.add(role);

        ScimUserV2CustomAttributes custom = new ScimUserV2CustomAttributes();

        ScimUserV2 newUser = new ScimUserV2();
        newUser.setUserName("test_test1");
        newUser.setName(name);
        newUser.setId("5");
        newUser.setRoles(list);
        newUser.setEmails(emailList);
        newUser.setScimUserV2CustomAttributes(custom);

        ScimUserV2 createdUser = controller.createUser(newUser, basicAuthValue);
        assertNotNull(createdUser);
        assertEquals("FactoryAdmin", createdUser.getRoles().get(0).getDisplayName());
        assertEquals("5", createdUser.getId());
    }
    @Test
    void updateUserTest() {
        ScimUserV2 before = controller.getUser("5", basicAuthValue);
        assertNotNull(before);

        ScimUserV2 req = objectMapper.convertValue(before, ScimUserV2.class);


        req.setRoles(List.of(
                new UserRole("12", "FactoryAdmin", Set.of("urn:okta:scim:schemas:core:1.0:Role"))
        ));

        ScimUserV2 after = controller.updateUser(req, "5", basicAuthValue);

        assertNotNull(after);
        List<String> afterIds = Optional.ofNullable(after.getRoles())
                .orElse(Collections.emptyList())
                .stream()
                .filter(Objects::nonNull)
                .map(UserRole::getValue)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        assertTrue(afterIds.contains("12"));
    }

    @Test
    void updateUserDeactivateRemovesOnlyRolesInPayloadTest() {
        ScimUserV2 before = controller.getUser("5", basicAuthValue);
        assertNotNull(before);
        List<String> beforeRoleIds = before.getRoles().stream().map(UserRole::getValue).collect(Collectors.toList());
        assertTrue(beforeRoleIds.contains("12"));
        assertTrue(beforeRoleIds.contains("9"));

        // Deactivate, but only list role "12" in the payload; role "9" (which the downstream
        // app also has) must be left alone since it's not in the request.
        ScimUserV2 req = objectMapper.convertValue(before, ScimUserV2.class);
        req.setActive(false);
        req.setRoles(List.of(
                new UserRole("12", "FactoryAdmin", Set.of("urn:okta:scim:schemas:core:1.0:Role"))
        ));

        ScimUserV2 after = controller.updateUser(req, "5", basicAuthValue);

        assertNotNull(after);
        assertEquals("5", after.getId());
        List<String> afterRoleIds = after.getRoles().stream().map(UserRole::getValue).collect(Collectors.toList());
        assertFalse(afterRoleIds.contains("12"), "role listed in payload should be removed");
        assertTrue(afterRoleIds.contains("9"), "role not listed in payload should be left untouched");
    }

    @Test
    void updateUserActiveAddsNewRoleWithoutDroppingExistingTest() {
        ScimUserV2 before = controller.getUser("5", basicAuthValue);
        assertNotNull(before);

        // Okta payload only lists a new role ("9"); the role the downstream app already
        // has ("12") is intentionally omitted and must not be removed.
        ScimUserV2 req = objectMapper.convertValue(before, ScimUserV2.class);
        req.setActive(true);
        req.setRoles(List.of(
                new UserRole("9", "CC Engineer Functions", Set.of("urn:okta:scim:schemas:core:1.0:Role"))
        ));

        ScimUserV2 after = controller.updateUser(req, "5", basicAuthValue);

        assertNotNull(after);
        assertEquals("5", after.getId());
        List<String> afterRoleIds = after.getRoles().stream()
                .map(UserRole::getValue)
                .collect(Collectors.toList());
        assertTrue(afterRoleIds.contains("9"), "payload role should be present");
        assertTrue(afterRoleIds.contains("12"), "existing downstream-only role should be appended, not dropped");
    }

    @Test
    void patchUserActiveTest() {
        PatchOperation op = new PatchOperation();
        op.setOp("replace");
        op.setPath("active");
        op.setValue(objectMapper.valueToTree(false));

        PatchRequest patchRequest = new PatchRequest();
        patchRequest.setOperations(List.of(op));

        ScimUserV2 result = controller.patchUser(patchRequest, "5", basicAuthValue);

        assertNotNull(result);
        assertEquals("5", result.getId());
    }

    @Test
    void patchUserAddRoleTest() {
        PatchOperation op = new PatchOperation();
        op.setOp("add");
        op.setPath("roles");
        op.setValue(objectMapper.valueToTree(List.of(Map.of("value", "12", "displayName", "FactoryAdmin"))));

        PatchRequest patchRequest = new PatchRequest();
        patchRequest.setOperations(List.of(op));

        ScimUserV2 result = controller.patchUser(patchRequest, "1", basicAuthValue);

        assertNotNull(result);
        assertEquals("1", result.getId());
    }

    @Test
    void patchUserRemoveRoleByFilterTest() {
        PatchOperation op = new PatchOperation();
        op.setOp("remove");
        op.setPath("roles[value eq \"12\"]");

        PatchRequest patchRequest = new PatchRequest();
        patchRequest.setOperations(List.of(op));

        ScimUserV2 result = controller.patchUser(patchRequest, "5", basicAuthValue);

        assertNotNull(result);
        assertEquals("5", result.getId());
    }

    @Test
    void patchUserRemoveRoleByCompoundFilterTest() {
        // Filter with an additional "and type eq ..." clause, as sent by Okta,
        // must still resolve to the plain role value ("5"), not the whole expression.
        PatchOperation addOp = new PatchOperation();
        addOp.setOp("add");
        addOp.setPath("roles");
        addOp.setValue(objectMapper.valueToTree(List.of(Map.of("value", "5", "display", "Dev Engineer Functions"))));

        PatchRequest addRequest = new PatchRequest();
        addRequest.setOperations(List.of(addOp));
        controller.patchUser(addRequest, "5", basicAuthValue);

        PatchOperation removeOp = new PatchOperation();
        removeOp.setOp("remove");
        removeOp.setPath("roles[value eq \"5\" and type eq \"Dev Engineer Functions\"]");

        PatchRequest removeRequest = new PatchRequest();
        removeRequest.setOperations(List.of(removeOp));

        ScimUserV2 result = controller.patchUser(removeRequest, "5", basicAuthValue);

        assertNotNull(result);
        List<String> roleIds = Optional.ofNullable(result.getRoles())
                .orElse(Collections.emptyList())
                .stream()
                .map(UserRole::getValue)
                .collect(Collectors.toList());
        assertFalse(roleIds.contains("5"));
    }

}
