package com.dell.webservice.controllers;

import com.dell.webservice.api.CSEApi;
import com.dell.webservice.api.CSEApiInMem;
import com.dell.webservice.pojos.Role;
import com.dell.webservice.pojos.ScimResourceList;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class RoleControllerTest {
    private RoleController controller;
    private CSEApi cseApi;
    private String basicAuthValue= "Basic QWRtaW5pc3RyYXRvcjpUZXN0QVBJS2V5";

    @BeforeEach
    void setUp() throws IOException {
        cseApi = new CSEApiInMem();
        controller = new RoleController(cseApi);
    }
    @Test
    void getRolesTest() {
        ScimResourceList<Role> response = controller.getRoles(null, 61, 0, basicAuthValue);
        assertNotNull(response);
        assertEquals(14, response.getResources().size());
        assertEquals("1", response.getResources().getFirst().getId());
        assertEquals("Manage LOB, Chassis", response.getResources().getFirst().getDisplayName());
    }
}
