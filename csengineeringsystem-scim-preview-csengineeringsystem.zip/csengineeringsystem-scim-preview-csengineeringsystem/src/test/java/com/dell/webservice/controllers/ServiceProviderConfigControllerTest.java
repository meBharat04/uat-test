package com.dell.webservice.controllers;

import com.dell.webservice.pojos.ServiceProviderConfigs;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ServiceProviderConfigControllerTest {
    private ServiceProviderConfigController controller;

    @BeforeEach
    void setUp() {
        controller = new ServiceProviderConfigController();
    }

    @Test
    void getServiceProviderConfigsTest() throws Exception {
        ServiceProviderConfigs config = controller.getServiceProviderConfigs();

        assertNotNull(config);

        Set<String> schemas = config.getSchemas();
        assertTrue(schemas.contains("urn:okta:schemas:scim:providerconfig:2.0"));
        assertTrue(schemas.contains("urn:ietf:params:scim:schemas:core:2.0:ServiceProviderConfig"));

        assertNotNull(config.getMeta());
        assertEquals("v1.0", config.getMeta().getVersion());

        assertEquals("https://support.okta.com/scim-fake-page.html", config.getDocumentationUri());

        assertEquals(Map.of("supported", true, "maxOperations", 100), config.getPatch());
        assertEquals(Map.of("supported", true), config.getBulk());
        assertEquals(Map.of("supported", true, "maxResults", 100), config.getFilter());
        assertEquals(Map.of("supported", true), config.getChangePassword());
        assertEquals(Map.of("supported", false), config.getSort());
        assertEquals(Map.of("supported", false), config.getEtag());

        assertNotNull(config.getAuthenticationSchemes());
        assertEquals(1, config.getAuthenticationSchemes().size());
        Map<String, Object> authScheme = config.getAuthenticationSchemes().get(0);
        assertEquals("oauthbearertoken", authScheme.get("type"));
        assertEquals("OAuth Bearer Token", authScheme.get("name"));
        assertEquals("Authentication scheme using the OAuth Bearer Token Standard", authScheme.get("description"));
        assertEquals("http://www.rfc-editor.org/info/rfc6750", authScheme.get("specUri"));
        assertEquals("http://example.com/help/oauth.html", authScheme.get("documentationUri"));

        assertNotNull(config.getCustomPropertiesMap());
        List<String> userManagementCapabilities = (List<String>) config.getCustomPropertiesMap().get("userManagementCapabilities");
        assertTrue(userManagementCapabilities.contains("IMPORT_NEW_USERS"));
        assertTrue(userManagementCapabilities.contains("PUSH_USER_DEACTIVATION"));
        assertTrue(userManagementCapabilities.contains("PUSH_NEW_USERS_WITHOUT_PASSWORD"));
    }
}
