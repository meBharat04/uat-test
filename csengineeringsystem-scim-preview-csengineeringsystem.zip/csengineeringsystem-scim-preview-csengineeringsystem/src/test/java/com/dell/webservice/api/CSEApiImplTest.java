
package com.dell.webservice.api;


import com.dell.webservice.ExceptionHandler.CustomException;
import com.dell.webservice.pojos.ScimFilter;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.*;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.*;

import java.lang.reflect.Field;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CSEApiImplTest {

    @Mock
    private RestClient restClient;

    @Mock
    private RestClient.ResponseSpec userResponseSpec;

    @Mock
    private RestClient.RequestHeadersUriSpec requestHeadersUriSpec;

    @Mock
    private RestClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private RestClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private RestClient.ResponseSpec responseSpec;

    @Mock
    private RestClient.ResponseSpec tokenResponseSpec;

    private CSEApiImpl cseApi;
    private Properties mockProperties;
    private ObjectMapper mapper = new ObjectMapper();

    @BeforeEach
    void setUp() throws Exception {
        MockitoAnnotations.openMocks(this);
        // 1. Reset static properties and ACCESS_TOKEN
        resetStaticState();

        // 2. Setup baseline properties needed for most methods to avoid URISyntaxExceptions
        mockProperties = new Properties();

        // 3. Initialize API with mocked dependencies
        cseApi = new CSEApiImpl(mockProperties);

        ReflectionTestUtils.setField(cseApi, "restClient", restClient);
        ReflectionTestUtils.setField(cseApi, "objectMapper", new ObjectMapper());
        ReflectionTestUtils.setField(cseApi, "tokenUrl", "http://token.mock.com");
        ReflectionTestUtils.setField(cseApi, "baseUrl", "http://mock.com/api");
        ReflectionTestUtils.setField(cseApi, "grantType", "client_credentials");
    }

    private void resetStaticState() throws Exception {
        Field tokenField = CSEApiImpl.class.getDeclaredField("ACCESS_TOKEN");
        tokenField.setAccessible(true);
        tokenField.set(null, "");

        Field propsField = CSEApiImpl.class.getDeclaredField("properties");
        propsField.setAccessible(true);
        Properties staticProps = (Properties) propsField.get(null);
        staticProps.clear();
    }

    private void injectValidToken() throws Exception {
        Field tokenField = CSEApiImpl.class.getDeclaredField("ACCESS_TOKEN");
        tokenField.setAccessible(true);
        tokenField.set(null, "valid-mock-token");

        Field expiryField = CSEApiImpl.class.getDeclaredField("TOKEN_EXPIRY_TIME");
        expiryField.setAccessible(true);
        expiryField.setLong(null, System.currentTimeMillis() + 30 * 60 * 1000); // 30 minutes from now
    }


    @Test
    void testGenerateToken_Success() throws Exception {

        // ---------- Properties ----------
        Properties props = new Properties();

        CSEApiImpl api = new CSEApiImpl(props);

        ReflectionTestUtils.setField(api, "restClient", restClient);
        ReflectionTestUtils.setField(api, "objectMapper", new ObjectMapper());
        ReflectionTestUtils.setField(api, "tokenUrl", "https://token");
        ReflectionTestUtils.setField(api, "grantType", "client_credentials");

        // ---------- Token Response ----------
        JsonNode tokenJson = mapper.readTree("{\"access_token\":\"new-mock-token\"}");

        ResponseEntity<JsonNode> tokenResponse = new ResponseEntity<>(tokenJson, HttpStatus.OK);
        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.body(any(MultiValueMap.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.retrieve()).thenReturn(tokenResponseSpec);
        when(tokenResponseSpec.toEntity(JsonNode.class)).thenReturn(tokenResponse);

        // ---------- Execute ----------
        api.generateToken();

        // ---------- Verify ----------
        Field tokenField = CSEApiImpl.class.getDeclaredField("ACCESS_TOKEN");
        tokenField.setAccessible(true);

        assertEquals("new-mock-token", tokenField.get(null));
    }


    @Test
    void testGetUser_SuccessWithDataWrapper() throws Exception {

        injectValidToken();
        JsonNode mockResponse = mapper.readTree("{\"data\":{\"id\":\"user123\",\"name\":\"John\"}}");

        ResponseEntity<JsonNode> response = new ResponseEntity<>(mockResponse, HttpStatus.OK);
        when(restClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class)).thenReturn(response);

        JsonNode result = cseApi.getUser("user123");

        assertNotNull(result);
        assertEquals("user123", result.get("id").asText());
    }


    @Test
    void testGetUsers_Success() throws Exception {

        injectValidToken();

        Properties props = new Properties();
        CSEApiImpl api = new CSEApiImpl(props);

        ReflectionTestUtils.setField(api, "restClient", restClient);
        ReflectionTestUtils.setField(api, "baseUrl", "https://test");
        JsonNode mockResponse = mapper.readTree("{\"data\":[{\"id\":\"user1\"},{\"id\":\"user2\"}]}");
        ResponseEntity<JsonNode> response = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        doReturn(requestBodyUriSpec)
                .when(requestBodyUriSpec)
                .body(any(ObjectNode.class));
        when(requestBodyUriSpec.retrieve())
                .thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class))
                .thenReturn(response);

        JsonNode result = api.getUsers(1, 10, null);

        assertTrue(result.isArray());
        assertEquals(2, result.size());
    }

    @Test
    void testCreateUser_Success() throws Exception {

        injectValidToken();

        JsonNode requestNode = mapper.readTree("{\"userName\":\"jdoe\"}");

        JsonNode responseNode = mapper.readTree("{\"id\":\"new-id\"}");

        ResponseEntity<JsonNode> response = new ResponseEntity<>(responseNode, HttpStatus.CREATED);
        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);

        doReturn(requestBodyUriSpec)
                .when(requestBodyUriSpec)
                .body(any(JsonNode.class));

        when(requestBodyUriSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class)).thenReturn(response);

        JsonNode result = cseApi.createUser(requestNode);
        assertNotNull(result);
        assertEquals("new-id", result.get("id").asText());

        verify(restClient).post();
    }

    @Test
    void testCallWithRetry_401Unauthorized_RefreshesToken() throws Exception {

        injectValidToken();

        // ---------------- Properties ----------------
        Properties props = new Properties();

        CSEApiImpl api = new CSEApiImpl(props);

        ReflectionTestUtils.setField(api, "restClient", restClient);
        ReflectionTestUtils.setField(api, "objectMapper", mapper);
        ReflectionTestUtils.setField(api, "tokenUrl", "https://token");
        ReflectionTestUtils.setField(api, "baseUrl", "https://test/users");
        ReflectionTestUtils.setField(api, "grantType", "client_credentials");

        // ---------------- Responses ----------------
        JsonNode successNode = mapper.readTree("{\"id\":\"user123\"}");

        JsonNode tokenNode = mapper.readTree("{\"access_token\":\"refreshed-token\"}");

        ResponseEntity<JsonNode> successResponse = new ResponseEntity<>(successNode, HttpStatus.OK);

        ResponseEntity<JsonNode> tokenResponse = new ResponseEntity<>(tokenNode, HttpStatus.OK);

        when(restClient.get()).thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.accept(any(MediaType.class))).thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.retrieve()).thenReturn(userResponseSpec);

        when(userResponseSpec.toEntity(JsonNode.class)).thenThrow(HttpClientErrorException.create(
                        HttpStatus.UNAUTHORIZED,
                        "Unauthorized",
                        HttpHeaders.EMPTY,
                        null,
                        null))
                .thenReturn(successResponse);

        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        doReturn(requestBodyUriSpec)
                .when(requestBodyUriSpec)
                .body(any(MultiValueMap.class));

        when(requestBodyUriSpec.retrieve())
                .thenReturn(tokenResponseSpec);

        when(tokenResponseSpec.toEntity(JsonNode.class))
                .thenReturn(tokenResponse);

        JsonNode result = api.getUser("user123");

        assertNotNull(result);
        assertEquals("user123", result.get("id").asText());

        verify(restClient, times(2)).get();
        verify(restClient).post();
    }

    @Test
    void testCallWithRetry_NonRetryableClientError() throws Exception {

        injectValidToken();

        when(restClient.get()).thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.uri(anyString()))
                .thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.headers(any()))
                .thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.accept(MediaType.APPLICATION_JSON))
                .thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.retrieve())
                .thenReturn(responseSpec);

        when(responseSpec.toEntity(JsonNode.class))
                .thenThrow(HttpClientErrorException.create(
                        HttpStatus.BAD_REQUEST,
                        "Bad Request",
                        HttpHeaders.EMPTY,
                        "Error Details".getBytes(),
                        StandardCharsets.UTF_8));

        CustomException exception =
                assertThrows(CustomException.class,
                        () -> cseApi.getUser("user123"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getStatus());
        assertTrue(exception.getMessage().contains("Client error 400"));

        verify(restClient).get();
    }

    @Test
    void testCallWithRetry_RetryableServerError_SucceedsOnSecondTry() throws Exception {

        injectValidToken();

        JsonNode successNode =
                mapper.readTree("{\"id\":\"user123\"}");

        ResponseEntity<JsonNode> successResponse =
                new ResponseEntity<>(successNode, HttpStatus.OK);

        when(restClient.get()).thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.uri(anyString()))
                .thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.headers(any()))
                .thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.accept(MediaType.APPLICATION_JSON))
                .thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.retrieve())
                .thenReturn(responseSpec);

        when(responseSpec.toEntity(JsonNode.class))
                .thenThrow(HttpServerErrorException.create(
                        HttpStatus.BAD_GATEWAY,
                        "Bad Gateway",
                        HttpHeaders.EMPTY,
                        null,
                        StandardCharsets.UTF_8))
                .thenReturn(successResponse);

        JsonNode result = cseApi.getUser("user123");

        assertNotNull(result);
        assertEquals("user123", result.get("id").asText());

        verify(responseSpec, times(2))
                .toEntity(JsonNode.class);
    }

    @Test
    void testGetRoles_Success() throws Exception {

        injectValidToken();
        JsonNode mockResponse = mapper.readTree("{\"data\":[{\"role\":\"Admin\"}]}");

        ResponseEntity<JsonNode> response = new ResponseEntity<>(mockResponse, HttpStatus.OK);

        when(restClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(any(URI.class))).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class)).thenReturn(response);

        JsonNode result = cseApi.getRoles();

        assertNotNull(result);
        assertTrue(result.isArray());
        assertEquals(1, result.size());
        assertEquals("Admin", result.get(0).get("role").asText());

        verify(restClient).get();
    }

    @Test
    void testAddRole_Success() throws Exception {

        injectValidToken();

        JsonNode requestNode = mapper.readTree("{\"role\":\"Admin\"}");
        JsonNode responseNode = mapper.readTree("{\"status\":\"added\"}");
        ResponseEntity<JsonNode> response = new ResponseEntity<>(responseNode, HttpStatus.OK);

        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);

        doReturn(requestBodyUriSpec).when(requestBodyUriSpec).body(any(JsonNode.class));
        when(requestBodyUriSpec.retrieve()).thenReturn(responseSpec);

        when(responseSpec.toEntity(JsonNode.class)).thenReturn(response);

        JsonNode result = cseApi.addRoles(requestNode, "user123");

        assertNotNull(result);
        assertEquals("added", result.get("status").asText());

        verify(restClient).post();
    }

    @Test
    void testRemoveRole_Success() throws Exception {
        injectValidToken();

        JsonNode requestNode = mapper.readTree("{\"role\":\"Admin\"}");
        JsonNode responseNode = mapper.readTree("{\"status\":\"removed\"}");
        ResponseEntity<JsonNode> response = new ResponseEntity<>(responseNode, HttpStatus.OK);

        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);
        doReturn(requestBodyUriSpec).when(requestBodyUriSpec).body(any(JsonNode.class));

        when(requestBodyUriSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class)).thenReturn(response);
        JsonNode result = cseApi.removeRole(requestNode, "user123");

        assertNotNull(result);
        assertEquals("removed", result.get("status").asText());

        verify(restClient).post();
    }
    // --- Token Generation Edge Cases ---
    @Test
    void testGenerateToken_MissingAccessTokenInResponse_ThrowsCustomException() throws Exception {

        Properties props = new Properties();

        CSEApiImpl api = new CSEApiImpl(props);

        ReflectionTestUtils.setField(api, "restClient", restClient);
        ReflectionTestUtils.setField(api, "objectMapper", mapper);
        ReflectionTestUtils.setField(api, "tokenUrl", "https://token");
        ReflectionTestUtils.setField(api, "grantType", "client_credentials");

        // ---------- Token Response (Missing access_token) ----------
        JsonNode badTokenResponse = mapper.readTree("{\"wrong_key\":\"token_value\"}");

        ResponseEntity<JsonNode> tokenResponse = new ResponseEntity<>(badTokenResponse, HttpStatus.OK);

        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_FORM_URLENCODED)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        doReturn(requestBodyUriSpec).when(requestBodyUriSpec).body(any(MultiValueMap.class));

        when(requestBodyUriSpec.retrieve()).thenReturn(tokenResponseSpec);
        when(tokenResponseSpec.toEntity(JsonNode.class)).thenReturn(tokenResponse);

        // ---------- Execute ----------
        CustomException exception = assertThrows(
                CustomException.class,
                api::generateToken);

        assertEquals(HttpStatus.OK, exception.getStatus());
        assertEquals("Failed to retrieve access token.", exception.getMessage());

        verify(restClient).post();
    }

    // --- Retry Logic & Transport Error Edge Cases ---
    @Test
    void testCallWithRetry_ResourceAccessException_ThrowsServiceUnavailable() throws Exception {

        injectValidToken();
        when(restClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.retrieve()).thenReturn(responseSpec);

        when(responseSpec.toEntity(JsonNode.class)).thenThrow(new ResourceAccessException("Connection timed out"));
        CustomException exception = assertThrows(
                CustomException.class,
                () -> cseApi.getUser("user123"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getStatus());
        assertTrue(exception.getMessage().contains("Network/transport error"));

        verify(restClient).get();
    }

    @Test
    void testCallWithRetry_GenericException_ThrowsInternalServerError() throws Exception {

        injectValidToken();

        when(restClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class)).thenThrow(new RuntimeException("Completely unexpected error"));

        CustomException exception = assertThrows(
                CustomException.class,
                () -> cseApi.getUser("user123"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getStatus());
        assertTrue(exception.getMessage().contains("Unexpected error"));

        verify(restClient).get();
    }

    @Test
    void testCallWithRetry_ExhaustsMaxBackoffRetries_ThrowsCustomException() throws Exception {

        injectValidToken();

        when(restClient.get()).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.uri(anyString())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.headers(any())).thenReturn(requestHeadersUriSpec);
        when(requestHeadersUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersUriSpec);

        when(requestHeadersUriSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class))
                .thenThrow(HttpServerErrorException.create(
                        HttpStatus.SERVICE_UNAVAILABLE,
                        "Service Unavailable",
                        HttpHeaders.EMPTY,
                        null,
                        null));

        CustomException exception = assertThrows(CustomException.class, () -> cseApi.getUser("user123"));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, exception.getStatus());
        assertTrue(exception.getMessage().contains("Server error 503"));

        // Initial call + 3 retries = 4
        verify(responseSpec, times(4))
                .toEntity(JsonNode.class);
    }

    @Test
    void testCreateUser_FailedStatus_ThrowsCustomException() throws Exception {

        injectValidToken();
        JsonNode requestNode = mapper.readTree("{\"userName\":\"jdoe\"}");

        ResponseEntity<JsonNode> response = new ResponseEntity<>(mapper.createObjectNode(), HttpStatus.CONFLICT);
        when(restClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(any(URI.class))).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.contentType(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.headers(any())).thenReturn(requestBodyUriSpec);

        doReturn(requestBodyUriSpec).when(requestBodyUriSpec).body(any(JsonNode.class));

        when(requestBodyUriSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.toEntity(JsonNode.class)).thenReturn(response);

        CustomException exception = assertThrows(CustomException.class, () -> cseApi.createUser(requestNode));

        assertEquals(HttpStatus.CONFLICT, exception.getStatus());
        assertTrue(exception.getMessage().contains("Failed to create user"));
        verify(restClient).post();
    }
}
