package com.dell.webservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest
class RestServerApplicationCoverageTest {

	@Test
	void contextLoads() {
	}

	@Test
	void configureReturnsApplicationSources() {
		RestServerApplication app = new RestServerApplication();
		assertNotNull(app.configure(new SpringApplicationBuilder()));
	}

}
