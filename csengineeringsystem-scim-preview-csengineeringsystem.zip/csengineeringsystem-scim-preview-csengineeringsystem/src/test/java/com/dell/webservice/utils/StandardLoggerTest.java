package com.dell.webservice.utils;

import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

class StandardLoggerTest {

    private final Logger mockLogger = mock(Logger.class);

    // --------------------------------------------------------------------
    // logInfo()
    // --------------------------------------------------------------------
    @Test
    void testLogInfo() {
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);

        StandardLogger.logInfo(mockLogger,
                1000L,
                "Blackline",
                "TestClass",
                "testMethod",
                "Test info");

        verify(mockLogger).info(captor.capture());
        String logged = captor.getValue();

        assertTrue(logged.contains("Connector:Blackline"));
        assertTrue(logged.contains("Class:TestClass"));
        assertTrue(logged.contains("Method:testMethod"));
        assertTrue(logged.contains("info:Test info."));
    }

    // --------------------------------------------------------------------
    // logError()
    // --------------------------------------------------------------------
    @Test
    void testLogError() {
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        Exception ex = new RuntimeException("Boom!");

        StandardLogger.logError(
                mockLogger,
                2000L,
                "ConnectorA",
                "MyClass",
                "myMethod",
                "param=1",
                "Something failed",
                ex);

        verify(mockLogger).error(captor.capture());
        String msg = captor.getValue();

        assertTrue(msg.contains("Connector:ConnectorA"));
        assertTrue(msg.contains("Class:MyClass"));
        assertTrue(msg.contains("Method:myMethod"));
        assertTrue(msg.contains("Description:Something failed"));
        assertTrue(msg.contains("Message:Boom!"));
    }

    // --------------------------------------------------------------------
    // logDebug()
    // --------------------------------------------------------------------
    @Test
    void testLogDebug() {
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        Exception ex = new IllegalArgumentException("Invalid");

        StandardLogger.logDebug(
                mockLogger,
                3000L,
                "C1",
                "ClassX",
                "methodY",
                "paramsXYZ",
                "debug description",
                ex);

        verify(mockLogger).debug(captor.capture());  // logDebug uses logger.error()
        String logged = captor.getValue();

        assertTrue(logged.contains("Connector:C1"));
        assertTrue(logged.contains("Class:ClassX"));
        assertTrue(logged.contains("Method:methodY"));
        assertTrue(logged.contains("Description:debug description"));
        assertTrue(logged.contains("StackTrace:")); // stacktrace must be logged
        assertTrue(logged.contains("IllegalArgumentException"));
    }

    // --------------------------------------------------------------------
    // logErrorWithStackTrace()
    // (calls logError + logBriefDebug internally)
    // --------------------------------------------------------------------
    @Test
    void testLogErrorWithStackTrace() {
        ArgumentCaptor<String> captor = ArgumentCaptor.forClass(String.class);
        Exception ex = new RuntimeException("StackFail!");

        StandardLogger.logErrorWithStackTrace(
                mockLogger,
                4000L,
                "BL",
                "SomeClass",
                "someMethod",
                "p=1",
                "Error occurred",
                ex);

        // logError + logBriefDebug => two calls to logger.error
        verify(mockLogger, times(2)).error(captor.capture());

        // Capture both log messages
        String first = captor.getAllValues().get(0);
        String second = captor.getAllValues().get(1);

        // First log message (from logError)
        assertTrue(first.contains("Description:Error occurred"));
        assertTrue(first.contains("Message:StackFail!"));

        // Second log message (from logBriefDebug)
        assertTrue(second.contains("SomeClass"));
        assertTrue(second.contains("someMethod"));
        assertTrue(second.contains("StackTrace:"));
        assertTrue(second.contains("RuntimeException"));
    }

    // --------------------------------------------------------------------
    // Test when logger=null → System.out.println
    // --------------------------------------------------------------------
    @Test
    void testLogInfo_NoLogger() {
        assertDoesNotThrow(() ->
                StandardLogger.logInfo(null, System.currentTimeMillis(),
                        "C2", "ClassY", "methodZ", "info test")
        );
    }
}
