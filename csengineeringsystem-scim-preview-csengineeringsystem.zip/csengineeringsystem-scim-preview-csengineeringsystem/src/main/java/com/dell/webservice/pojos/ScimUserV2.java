package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScimUserV2 {
	private String id;
	private String userName;
	private Name name;
	private Set<String> schemas;
	private Boolean active;
	private List<Email> emails;
	private List<PhoneNumber> phoneNumbers;
	private List<UserRole> roles;


	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<UserEntitlement> entitlements;

	@JsonProperty("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User")
	private ScimUserV2CustomAttributes scimUserV2CustomAttributes;

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public List<Email> getEmails() {
		return emails;
	}

	public void setEmails(List<Email> emails) {
		this.emails = emails;
	}

	public List<PhoneNumber> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	public List<UserEntitlement> getEntitlements() {
		return entitlements;
	}

	public void setEntitlements(List<UserEntitlement> entitlements) {
		this.entitlements = entitlements;
	}

	public List<UserRole> getRoles() {
		return roles;
	}

	public void setRoles(List<UserRole> roles) {
		this.roles = roles;
	}

	public Set<String> getSchemas() {
		return schemas;
	}

	public void setSchemas(Set<String> schemas) {
		this.schemas = schemas;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public ScimUserV2CustomAttributes getScimUserV2CustomAttributes() {
		return scimUserV2CustomAttributes;
	}

	public void setScimUserV2CustomAttributes(ScimUserV2CustomAttributes scimUserV2CustomAttributes) {
		this.scimUserV2CustomAttributes = scimUserV2CustomAttributes;
	}


	@Override
	public String toString() {
		return "ScimUserV2{" +
				"id='" + id + '\'' +
				", userName='" + userName + '\'' +
				", name=" + name +
				", schemas=" + schemas +
				", active=" + active +
				", emails=" + emails +
				", phoneNumbers=" + phoneNumbers +
				", roles=" + roles +
				", entitlements=" + entitlements +
				", scimUserV2CustomAttributes=" + scimUserV2CustomAttributes +
				'}';
	}
}
