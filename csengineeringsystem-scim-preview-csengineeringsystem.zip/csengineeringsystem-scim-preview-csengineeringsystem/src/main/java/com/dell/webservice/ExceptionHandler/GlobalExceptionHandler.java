package com.dell.webservice.ExceptionHandler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // Handle Custom ApiException
    @ExceptionHandler(CustomException.class)
    public ResponseEntity<Object> handleApiException(CustomException ex) {
        return new ResponseEntity<>(ex.getMessage(), ex.getStatus());
    }


}
