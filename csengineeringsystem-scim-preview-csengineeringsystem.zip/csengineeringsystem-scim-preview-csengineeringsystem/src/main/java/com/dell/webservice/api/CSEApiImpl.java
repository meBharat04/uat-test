package com.dell.webservice.api;

import com.dell.webservice.ExceptionHandler.CustomException;
import com.dell.webservice.pojos.ScimFilter;
import com.dell.webservice.utils.ApplicationConstants;
import com.dell.webservice.utils.HelperUtils;
import com.dell.webservice.utils.StandardLogger;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.*;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.Callable;

public class CSEApiImpl implements CSEApi {
    @Autowired
    private RestClient restClient;

    private static final Logger logger = LogManager.getLogger(CSEApiImpl.class);
    private static final Properties properties = new Properties();
    private static String ACCESS_TOKEN = "";
    private static long TOKEN_EXPIRY_TIME = 0L;
    private static final long TOKEN_REFRESH_BUFFER = 60_000L; // 1 minute

    @Autowired
    private ObjectMapper objectMapper;

    @Value("${cse.token-url}")
    private String tokenUrl;

    @Value("${cse.base-url}")
    private String baseUrl;

    @Value("${cse.grant-type}")
    private String grantType;

    private static final String USERS_PATH = "/GetEmployeeDetails";
    private static final String USER_PATH = "/GetUserDetailsById?userId=";
    private static final String ROLES_PATH = "/GetUserRoles";
    private static final String CREATE_PATH = "/CreateUserDetail";
    private static final String ADD_OR_REMOVE_ROLE_PATH = "/AddORRemoveUserRoles";

    private static final int[] BACKOFF_SECONDS = {5, 10, 15};
    private static final int MAX_BACKOFF_RETRIES = BACKOFF_SECONDS.length;
    private static final int MAX_401_RETRIES = 2;

    public CSEApiImpl() {
    }

    public CSEApiImpl(Properties mockConfigProperties) {
        properties.putAll(mockConfigProperties);
    }

    @Override
    public Properties getProperties() {
        return properties;
    }

    private <T> ResponseEntity<T> callWithRetry(
            String operationName,
            Callable<ResponseEntity<T>> action,
            boolean refreshOn401) {

        int backoffRetries = 0;
        int unauthorizedRetries = 0;

        final Set<Integer> RETRYABLE_STATUSES = Set.of(408, 429, 500, 502, 503, 504);

        while (true) {
            try {
                return action.call();

            } catch (HttpClientErrorException.Unauthorized ex) {
                if (refreshOn401 && unauthorizedRetries < MAX_401_RETRIES) {
                    unauthorizedRetries++;
                    StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                            this.getClass().getSimpleName(), operationName,
                            "401 Unauthorized. Refreshing token and retrying (" + unauthorizedRetries + "/" + MAX_401_RETRIES + ")");
                    generateToken();
                    continue;
                }
                StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                        this.getClass().getSimpleName(), operationName, null,
                        "401 Unauthorized - max retries exceeded or non-refreshable context", ex);
                throw new CustomException("401 Unauthorized during " + operationName, ex, HttpStatus.UNAUTHORIZED);

            } catch (HttpClientErrorException ex) {
                int status = ex.getStatusCode().value();

                if (RETRYABLE_STATUSES.contains(status)) {
                    if (backoffRetries >= MAX_BACKOFF_RETRIES) {
                        StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                                this.getClass().getSimpleName(), operationName, null,
                                status + " - Max retries exceeded", ex);
                        throw new CustomException(status + " after retries for " + operationName, ex, HttpStatus.valueOf(status));
                    }
                    int attempt = backoffRetries + 1;
                    int delay = computeBackoffSeconds(attempt);
                    backoffRetries++;
                    StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                            this.getClass().getSimpleName(), operationName,
                            status + " received. Retrying in " + delay + "s (" + attempt + "/" + MAX_BACKOFF_RETRIES + ")");
                    sleepSeconds(delay);
                    continue;
                }

                StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                        this.getClass().getSimpleName(), operationName, null,
                        "Client error " + status + " (no retry)", ex);
                throw new CustomException("Client error " + status + " for " + operationName + ": " + ex.getResponseBodyAsString(), ex,  HttpStatus.valueOf(status));

            } catch (HttpServerErrorException ex) {
                int status = ex.getStatusCode().value();

                if (RETRYABLE_STATUSES.contains(status)) {
                    if (backoffRetries >= MAX_BACKOFF_RETRIES) {
                        StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                                this.getClass().getSimpleName(), operationName, null,
                                "Server error " + status + " - max retries exceeded", ex);
                        throw new CustomException("Server error " + status + " for " + operationName, ex,  HttpStatus.valueOf(status));
                    }
                    int attempt = backoffRetries + 1;
                    int delay = computeBackoffSeconds(attempt);
                    backoffRetries++;
                    StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                            this.getClass().getSimpleName(), operationName,
                            "Server error " + status + ". Retrying in " + delay + "s (" + attempt + "/" + MAX_BACKOFF_RETRIES + ")");
                    sleepSeconds(delay);
                    continue;
                }

                StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                        this.getClass().getSimpleName(), operationName, null,
                        "Server error " + status + " (no retry)", ex);
                throw new CustomException("Server error " + status + " for " + operationName, ex,  HttpStatus.valueOf(status));

            } catch (ResourceAccessException ex) {
                StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                        this.getClass().getSimpleName(), operationName, null,
                        "Network/transport error (no retry)", ex);
                throw new CustomException("Network/transport error during " + operationName + ": " + ex.getMessage(), ex,  HttpStatus.SERVICE_UNAVAILABLE);

            } catch (RestClientException ex) {
                StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                        this.getClass().getSimpleName(), operationName, null,
                        "RestClientException (no retry)", ex);
                throw new CustomException("Error during " + operationName + ": " + ex.getMessage(), ex, HttpStatus.INTERNAL_SERVER_ERROR);
            } catch (Exception ex) {
                StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                        this.getClass().getSimpleName(), operationName, null,
                        "Unexpected exception (no retry)", ex);
                throw new CustomException("Unexpected error during " + operationName, ex, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
    }

    private int computeBackoffSeconds(int attempt) {
        if (attempt > 0 && attempt <= BACKOFF_SECONDS.length) {
            return BACKOFF_SECONDS[attempt - 1];
        }
        return 5;
    }

    private void sleepSeconds(int sec) {
        try { Thread.sleep(sec * 1000L); }
        catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
    }

    private void ensureToken() {
        if (ACCESS_TOKEN == null || ACCESS_TOKEN.isEmpty() || isTokenExpired()) {
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR,
                    this.getClass().getSimpleName(), HelperUtils.getMethodName(), "ACCESS_TOKEN missing. Generating new token.");
            generateToken();
        }
    }

    private boolean isTokenExpired() {
        return System.currentTimeMillis() >= (TOKEN_EXPIRY_TIME - TOKEN_REFRESH_BUFFER);
    }

    private HttpHeaders defaultJsonHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.setBearerAuth(ACCESS_TOKEN);
        return headers;
    }

    public void generateToken() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Starting token generation.");

        try {
            URI uri = new URI(tokenUrl);

            MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
            params.add("client_id", properties.getProperty(ApplicationConstants.CLIENT_ID));
            params.add("client_secret", properties.getProperty(ApplicationConstants.CLIENT_SECRET));
            params.add("grant_type", grantType);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Requesting OAuth access token from: " + uri);

            ResponseEntity<JsonNode> response = callWithRetry(HelperUtils.getMethodName(),
                    () -> restClient.post()
                            .uri(uri)
                            .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                            .accept(MediaType.APPLICATION_JSON)
                            .body(params)
                            .retrieve()
                            .toEntity(JsonNode.class),
                    false);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Token API responded with status: " + response.getStatusCode());

            JsonNode body = response.getBody();

            if (response.getStatusCode() == HttpStatus.OK && body != null && body.has("access_token")) {

                ACCESS_TOKEN = body.get("access_token").asText();

                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Access token generated successfully.");
            } else {

                StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Token API response does not contain access_token.", null);
                throw new CustomException("Failed to retrieve access token.", HttpStatus.valueOf(response.getStatusCode().value()));
            }

        } catch (URISyntaxException ex) {

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Invalid token endpoint URI.", ex);
            throw new CustomException("Token generation failed: " + ex.getMessage(), ex, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public JsonNode getUser(String id) {
        StandardLogger.logInfo(
                logger,
                System.currentTimeMillis(),
                HelperUtils.CONNECTOR,
                this.getClass().getSimpleName(),
                HelperUtils.getMethodName(),
                "Starting getUser for CSE. User ID: " + id
        );

        ensureToken();

        try {
            String uri = baseUrl + USER_PATH + URLEncoder.encode(id, StandardCharsets.UTF_8);

            logger.debug("Get User API request :- {}", uri);
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Calling CSE Get User API: " + uri);

            ResponseEntity<JsonNode> response = callWithRetry(HelperUtils.getMethodName(),
                    () -> restClient.get()
                            .uri(uri)
                            .accept(MediaType.APPLICATION_JSON)
                            .headers(headers -> headers.setBearerAuth(ACCESS_TOKEN))
                            .retrieve()
                            .toEntity(JsonNode.class),
                    true);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Get User API responded with status: " + response.getStatusCode());

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                JsonNode jsonNode = response.getBody();

                if (jsonNode.has("data")) {
                    jsonNode = jsonNode.get("data");
                }
                logger.debug("Get User with User ID :- {} , Response :- {}", id, objectMapper.writeValueAsString(response.getBody()));
                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "User retrieved successfully.");

                return jsonNode;
            }

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to retrieve user. HTTP Status: " + response.getStatusCode(), null);

            throw new CustomException("Failed to retrieve user. Status: " + response.getStatusCode(), HttpStatus.valueOf(response.getStatusCode().value()));

        } catch (Exception ex) {

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Error retrieving user with ID: " + id, ex);
            throw new CustomException("Error getting user: " + ex.getMessage(), ex, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Retrieve multiple Users
    public JsonNode getUsers(Integer pageNo, Integer pageSize, ScimFilter filter) {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Starting getUsers for CSE API . PageNo: " + pageNo + ", PageSize: " + pageSize);

        ensureToken();
        try {
            URI uri = new URI(baseUrl + USERS_PATH);
            ObjectMapper mapper = new ObjectMapper();
            ObjectNode requestBody = mapper.createObjectNode();
            requestBody.put("pageNo", pageNo);
            requestBody.put("pageSize", pageSize);

            logger.debug("Get Users API request :- {}", mapper.writeValueAsString(requestBody));
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Calling CSE Get Users API: " + uri);

            ResponseEntity<JsonNode> response = callWithRetry(HelperUtils.getMethodName(),
                    () -> restClient.post()
                            .uri(uri)
                            .contentType(MediaType.APPLICATION_JSON)
                            .accept(MediaType.APPLICATION_JSON)
                            .headers(headers -> headers.setBearerAuth(ACCESS_TOKEN))
                            .body(requestBody)
                            .retrieve()
                            .toEntity(JsonNode.class),
                    true);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Get Users API success, responded status: " + response.getStatusCode());

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {

                JsonNode jsonNode = response.getBody();

                if (jsonNode.has("data")) {
                    jsonNode = jsonNode.get("data");
                }
                logger.debug("Get Users API response :- {}", mapper.writeValueAsString(jsonNode));
                return jsonNode;
            }

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to retrieve users. HTTP Status: " + response.getStatusCode(), null);

            throw new CustomException("Failed to retrieve users. Status: " + response.getStatusCode(), HttpStatus.valueOf(response.getStatusCode().value()));

        } catch (URISyntaxException e) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(),null, "Error getting users: " + e.getMessage(), e);
            throw new CustomException("Error getting users: " + e.getMessage(), e, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Create a new user
     */
    @Override
    public JsonNode createUser(JsonNode userNode){

        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Starting createUser for CSE.");
        logger.debug("Create user Request :- {}" , objectMapper.writeValueAsString(userNode));
        ensureToken();

        try {
            URI uri = new URI(baseUrl + CREATE_PATH);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Calling CSE Create User API: " + uri);

            ResponseEntity<JsonNode> response = callWithRetry(HelperUtils.getMethodName(),
                    () -> restClient.post()
                            .uri(uri)
                            .contentType(MediaType.APPLICATION_JSON)
                            .accept(MediaType.APPLICATION_JSON)
                            .headers(headers -> headers.setBearerAuth(ACCESS_TOKEN))
                            .body(userNode)
                            .retrieve()
                            .toEntity(JsonNode.class),
                    true);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Create User API responded with status: " + response.getStatusCode());

            if (response.getStatusCode() == HttpStatus.CREATED || response.getStatusCode() == HttpStatus.OK) {
                logger.debug("User Create Response :- {}", objectMapper.writeValueAsString(response.getBody()));

                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "User created successfully.");
                return response.getBody();
            }

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to create user. HTTP Status: " + response.getStatusCode(), null);
            throw new CustomException("Failed to create user. Status: " + response.getStatusCode(), HttpStatus.valueOf(response.getStatusCode().value()));

        } catch (URISyntaxException ex) {

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Invalid Create User API URI.", ex);
            throw new CustomException("Error creating user: " + ex.getMessage(), ex, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Retrieve Entitlements
     */
    @Override
    public JsonNode getRoles(){

        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Starting getRoles for CSE.");

        ensureToken();

        try {
            URI uri = new URI(baseUrl + ROLES_PATH);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Calling CSE Get Roles API: " + uri);

            ResponseEntity<JsonNode> response = callWithRetry(HelperUtils.getMethodName(),
                    () -> restClient.get()
                            .uri(uri)
                            .accept(MediaType.APPLICATION_JSON)
                            .headers(headers -> headers.setBearerAuth(ACCESS_TOKEN))
                            .retrieve()
                            .toEntity(JsonNode.class),
                    true);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Get Roles API responded with status: " + response.getStatusCode());

            if (response.getStatusCode() == HttpStatus.OK && response.getBody() != null) {
                logger.debug("Get All Roles :- {}", objectMapper.writeValueAsString(response.getBody()));

                JsonNode jsonNode = response.getBody();

                if (jsonNode.has("data")) {
                    jsonNode = jsonNode.get("data");
                }

                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Roles retrieved successfully.");

                return jsonNode;
            }

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to retrieve roles. HTTP Status: " + response.getStatusCode(), null);

            throw new CustomException("Failed to retrieve roles. Status: " + response.getStatusCode(), HttpStatus.valueOf(response.getStatusCode().value()));

        } catch (URISyntaxException ex) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Invalid Get Roles API URI.", ex);
            throw new CustomException("Error fetching roles: " + ex.getMessage(), ex, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Add Entitlement to a User
     */
    @Override
    public JsonNode addRoles(JsonNode userNode, String userId) {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Starting addRoles for CSE. User ID: " + userId);

        logger.debug("Add Roles to Users with UserId :- {} , payload :- {}", userId, objectMapper.writeValueAsString(userNode));
        ensureToken();

        try {
            URI uri = new URI(baseUrl + ADD_OR_REMOVE_ROLE_PATH);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Calling CSE Add Role API: " + uri);

            ResponseEntity<JsonNode> response = callWithRetry(HelperUtils.getMethodName(),
                    () -> restClient.post()
                            .uri(uri)
                            .contentType(MediaType.APPLICATION_JSON)
                            .accept(MediaType.APPLICATION_JSON)
                            .headers(headers -> headers.setBearerAuth(ACCESS_TOKEN))
                            .body(userNode)
                            .retrieve()
                            .toEntity(JsonNode.class),
                    true);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Add Role API responded with status: " + response.getStatusCode());

            if (response.getStatusCode() == HttpStatus.CREATED || response.getStatusCode() == HttpStatus.OK) {
                logger.debug("Add Roles Response :- {}", objectMapper.writeValueAsString(response.getBody()));

                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Role added successfully.");
                return response.getBody();
            }
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to add role. HTTP Status: " + response.getStatusCode(), null);

            throw new CustomException("Failed to add role. Status: " + response.getStatusCode(), HttpStatus.valueOf(response.getStatusCode().value()));

        } catch (URISyntaxException ex) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Invalid Add Role API URI.", ex);
            throw new CustomException("Error adding role: " + ex.getMessage(), ex, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Remove Entitlement from a User
     */
    @Override
    public JsonNode removeRole(JsonNode userNode, String userId){

        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Starting removeRole for CSE. User ID: " + userId);
        logger.debug("Remove Roles to Users with UserId :- {} , payload :- {}", userId, objectMapper.writeValueAsString(userNode));

        ensureToken();

        try {
            URI uri = new URI(baseUrl + ADD_OR_REMOVE_ROLE_PATH);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Calling CSE Remove Role API: " + uri);

            ResponseEntity<JsonNode> response = callWithRetry(HelperUtils.getMethodName(),
                    () -> restClient.post()
                            .uri(uri)
                            .contentType(MediaType.APPLICATION_JSON)
                            .accept(MediaType.APPLICATION_JSON)
                            .headers(headers -> headers.setBearerAuth(ACCESS_TOKEN))
                            .body(userNode)
                            .retrieve()
                            .toEntity(JsonNode.class),
                    true);

            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Remove Role API responded with status: " + response.getStatusCode());

            if (response.getStatusCode() == HttpStatus.CREATED
                    || response.getStatusCode() == HttpStatus.OK) {
                logger.debug("Remove Roles Response :- {}", objectMapper.writeValueAsString(response.getBody()));

                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), "Role removed successfully.");

                return response.getBody();
            }

            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to remove role. HTTP Status: " + response.getStatusCode(), null);

            throw new CustomException("Failed to remove role. Status: " + response.getStatusCode(), HttpStatus.valueOf(response.getStatusCode().value()));

        } catch (URISyntaxException ex) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Invalid Remove Role API URI.", ex);
            throw new CustomException("Error removing role: " + ex.getMessage(), ex, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}