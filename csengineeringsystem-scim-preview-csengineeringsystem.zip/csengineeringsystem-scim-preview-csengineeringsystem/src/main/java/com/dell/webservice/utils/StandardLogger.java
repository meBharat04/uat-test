package com.dell.webservice.utils;

import org.apache.logging.log4j.Logger;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StandardLogger {


    /**
     * Formats and logs an Exception for consistent error logging.
     * Uses exc parameter to get and log the cause and stacktrace.
     *
     * @param logger      Set to logger or null if output is only to console
     * @param millisec    Pass millisec (Use System.currentTimeMillis()), or set to null and millisec will be calculated.
     * @param connector   Connector where exception occurred.
     * @param className   Class Name where exception occurred.
     * @param method      Method where exception occurred.
     * @param params      Params need to reconstruct the exception
     * @param description Description of problem.
     * @param exc         Exception that was caught or null.
     */
    public static void logDebug(
            Logger logger,
            Long millisec,
            String connector,
            String className,
            String method,
            String params,
            String description,
            Exception exc
    ) {
        StringBuilder buffer = new StringBuilder();

        // Timestamp
        long milliSec = (millisec != null) ? millisec : System.currentTimeMillis();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS:z");
        String timeStamp = dateFormat.format(new Date(milliSec));
        buffer.append("Timestamp:");
        buffer.append(timeStamp);
        buffer.append(", ");

        buffer.append("Thread:");
        buffer.append(Thread.currentThread().threadId());
        buffer.append(", ");

        buffer.append("Connector:");
        buffer.append(connector != null ? connector : "");
        buffer.append(", ");

        buffer.append("Class:");
        buffer.append(className != null ? className : "");
        buffer.append(", ");

        buffer.append("Method:");
        buffer.append(method != null ? method : "");
        buffer.append(", ");

        buffer.append("Params:");
        buffer.append(params != null ? params : "");
        buffer.append(", ");

        buffer.append("Description:");
        buffer.append(description != null ? description : "");
        buffer.append(", ");

        buffer.append("Cause:");
        buffer.append(exc != null ? exc.getCause() : "");
        buffer.append(", ");

        if (exc != null) {
            buffer.append("StackTrace:");
            StringWriter stringWriter = new StringWriter();
            PrintWriter printWriter = new PrintWriter(stringWriter);
            exc.printStackTrace(printWriter);
            buffer.append(stringWriter.toString());
        }

        String message = buffer.toString();
        if (logger != null) {
            logger.debug(buffer.toString());
        }
        else {
            System.out.println(message);
        }
    }


    /**
     * Formats and logs an Exception for consistent error logging.
     *
     * @param logger      Set to logger or null if output is only to console
     * @param millisec    Pass millisec (Use System.currentTimeMillis()), or set to null and millisec will be calculated.
     * @param connector   Connector where exception occurred.
     * @param className   Class Name where exception occurred.
     * @param method      Method where exception occurred.
     * @param params      Params need to reconstruct the exception
     * @param description Description of problem.
     * @param exc         Exception that was caught or null.
     */
    public static void logError(
            Logger logger,
            Long millisec,
            String connector,
            String className,
            String method,
            String params,
            String description,
            Exception exc
    ) {
        StringBuilder buffer = new StringBuilder();

        // Timestamp
        long milliSec = (millisec != null) ? millisec : System.currentTimeMillis();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS:z");
        String timeStamp = dateFormat.format(new Date(milliSec));
        buffer.append("Timestamp:");
        buffer.append(timeStamp);
        buffer.append(", ");

        buffer.append("Thread:");
        buffer.append(Thread.currentThread().threadId());
        buffer.append(", ");

        buffer.append("Connector:");
        buffer.append(connector != null ? connector : "");
        buffer.append(", ");

        buffer.append("Class:");
        buffer.append(className != null ? className : "");
        buffer.append(", ");

        buffer.append("Method:");
        buffer.append(method != null ? method : "");
        buffer.append(", ");

        buffer.append("Params:");
        buffer.append(params != null ? params : "");
        buffer.append(", ");

        buffer.append("Description:");
        buffer.append(description != null ? description : "");
        buffer.append(", ");

        buffer.append("Message:");
        buffer.append(exc != null ? exc.getMessage() : "");
        buffer.append(", ");

        buffer.append("Cause:");
        buffer.append(exc != null ? exc.getCause() : ".");

        String message = buffer.toString();

        if (logger != null) {
            logger.error(buffer.toString());
        }
        else {
            System.out.println(message);
        }
    }


    /**
     * Formats and logs an Info message for consistent logging, period added message.
     *
     * @param logger      Set to logger or null if output is only to console
     * @param millisec    Pass millisec (Use System.currentTimeMillis()), or set to null and millisec will be calculated.
     * @param connector   Connector where exception occurred.
     * @param className   Class Name where exception occurred.
     * @param method      Method where exception occurred.
     * @param info        Info or message to log
     */
    public static void logInfo(
            Logger logger,
            Long millisec,
            String connector,
            String className,
            String method,
            String info
    ) {
        StringBuilder buffer = new StringBuilder();

        // Timestamp
        long milliSec = (millisec != null) ? millisec : System.currentTimeMillis();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS:z");
        String timeStamp = dateFormat.format(new Date(milliSec));
        buffer.append("Timestamp:");
        buffer.append(timeStamp);
        buffer.append(", ");

        buffer.append("Thread:");
        buffer.append(Thread.currentThread().threadId());
        buffer.append(", ");

        buffer.append("Connector:");
        buffer.append(connector != null ? connector : "");
        buffer.append(", ");

        buffer.append("Class:");
        buffer.append(className != null ? className : "");
        buffer.append(", ");

        buffer.append("Method:");
        buffer.append(method != null ? method : "");
        buffer.append(", ");

        buffer.append("info:");
        buffer.append(info != null ? info : "");
        buffer.append(".");

        String message = buffer.toString();

        if (logger != null) {
            logger.info(buffer.toString());
        }
        else {
            System.out.println(message);
        }
    }


    /**
     * Formats and logs a Warning message for consistent logging.
     *
     * @param logger    Set to logger or null if output is only to console
     * @param millisec  Pass millisec (Use System.currentTimeMillis()), or set to null and millisec will be calculated.
     * @param connector Connector where warning occurred.
     * @param className Class Name where warning occurred.
     * @param method    Method where warning occurred.
     * @param warning   Warning message to log
     */
    public static void logWarn(
            Logger logger,
            Long millisec,
            String connector,
            String className,
            String method,
            String warning
    ) {
        StringBuilder buffer = new StringBuilder();

        // Timestamp
        long milliSec = (millisec != null) ? millisec : System.currentTimeMillis();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS:z");
        String timeStamp = dateFormat.format(new Date(milliSec));
        buffer.append("Timestamp:");
        buffer.append(timeStamp);
        buffer.append(", ");

        buffer.append("Thread:");
        buffer.append(Thread.currentThread().threadId());
        buffer.append(", ");

        buffer.append("Connector:");
        buffer.append(connector != null ? connector : "");
        buffer.append(", ");

        buffer.append("Class:");
        buffer.append(className != null ? className : "");
        buffer.append(", ");

        buffer.append("Method:");
        buffer.append(method != null ? method : "");
        buffer.append(", ");

        buffer.append("WARNING:");
        buffer.append(warning != null ? warning : "");
        buffer.append(".");

        String message = buffer.toString();

        if (logger != null) {
            logger.warn(buffer.toString());
        } else {
            System.out.println(message);
        }
    }



    /**
     * Logs an Error and includes a Debug level stacktrace.
     *
     * @param logger      Set to logger or null if output is only to console
     * @param millisec    Use System.currentTimeMillis()
     * @param connector   Connector where exception occurred.
     * @param className   Class Name where exception occurred.
     * @param method      Method where exception occurred.
     * @param params      Params need to reconstruct the exception
     * @param description Description of problem.
     * @param exc         Exception that was caught or null.
     */
    public static void logErrorWithStackTrace(
            Logger logger,
            Long millisec,
            String connector,
            String className,
            String method,
            String params,
            String description,
            Exception exc
    ) {
        logError(logger, millisec, connector, className, method, params, description, exc);
        logBriefDebug(logger, millisec, connector, className, method, exc);
    }


    /**
     * Logs an abbreviated debug message with a stacktrace;
     * it is intended to be called by logErrorWithStackTrace(..).
     * This allows the standard error to be logged, but if log level
     * is set to DEBUG a stacktrace can be correlated with the error.
     * No need to repeat all the details in logError and logDebug.
     *
     * @param logger      Set to logger or null if output is only to console
     * @param millisec    Use System.currentTimeMillis()
     * @param connector   Connector where exception occurred.
     * @param className   Class Name where exception occurred.
     * @param method      Method where exception occurred.
     * @param exc         Exception that was caught or null.
     */
    private static void logBriefDebug(
            Logger logger,
            Long millisec,
            String connector,
            String className,
            String method,
            Exception exc
    ) {
        StringBuilder buffer = new StringBuilder();

        // Timestamp
        long milliSec = (millisec != null) ? millisec : System.currentTimeMillis();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS:z");
        String timeStamp = dateFormat.format(new Date(milliSec));
        buffer.append("Timestamp:");
        buffer.append(timeStamp);
        buffer.append(", ");

        buffer.append("Thread:");
        buffer.append(Thread.currentThread().threadId());
        buffer.append(", ");

        buffer.append("Connector:");
        buffer.append(connector != null ? connector : "");
        buffer.append(", ");

        buffer.append("Class:");
        buffer.append(className != null ? className : "");
        buffer.append(", ");

        buffer.append("Method:");
        buffer.append(method != null ? method : "");
        buffer.append(", ");

        if (exc != null) {
            buffer.append("StackTrace:");
            StringWriter stringWriter = new StringWriter();
            PrintWriter printWriter = new PrintWriter(stringWriter);
            exc.printStackTrace(printWriter);
            buffer.append(stringWriter.toString());
        }

        String message = buffer.toString();
        if (logger != null) {
            logger.error(buffer.toString());
        }
        else {
            System.out.println(message);
        }
    }

}
