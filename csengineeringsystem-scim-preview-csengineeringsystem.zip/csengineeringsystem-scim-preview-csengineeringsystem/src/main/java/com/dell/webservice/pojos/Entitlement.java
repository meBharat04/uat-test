package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Entitlement {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private Set<String> schemas;
    private String id;
    private String displayName;
    private String type;
    private boolean primary;

    public Entitlement() {
    }

    public Entitlement(String id, String displayName, String type, boolean primary, Set<String> schemas) {
        this.id = id;
        this.displayName = displayName;
        this.type = type;
        this.primary = primary;
        this.schemas = schemas;
    }

    public Set<String> getSchemas() {
        return schemas;
    }

    public void setSchemas(Set<String> schemas) {
        this.schemas = schemas;
    }

    public String getId() {
        return id;
    }

    public void setId(String value) {
        this.id = value;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String display) {
        this.displayName = display;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    @Override
    public String toString() {
        return "Entitlement{" +
                "schemas=" + schemas +
                ", id='" + id + '\'' +
                ", displayName='" + displayName + '\'' +
                ", type='" + type + '\'' +
                ", primary=" + primary +
                '}';
    }
}
