package com.dell.webservice.ExceptionHandler;

import org.springframework.http.HttpStatus;

public class CustomException extends RuntimeException {
    private final HttpStatus status;

    public CustomException(String message, HttpStatus status) {
        super(message);
        this.status = status;
    }
     public CustomException(String message, Exception ex, HttpStatus status){
        super(message,ex);
        this.status = status;
     }



    public HttpStatus getStatus() {
        return status;
    }
}
