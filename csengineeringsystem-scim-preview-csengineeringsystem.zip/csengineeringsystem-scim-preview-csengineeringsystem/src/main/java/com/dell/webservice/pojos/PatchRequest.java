package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Set;

public class PatchRequest {
    private Set<String> schemas;

    @JsonProperty("Operations")
    private List<PatchOperation> operations;

    public Set<String> getSchemas() {
        return schemas;
    }

    public void setSchemas(Set<String> schemas) {
        this.schemas = schemas;
    }

    public List<PatchOperation> getOperations() {
        return operations;
    }

    public void setOperations(List<PatchOperation> operations) {
        this.operations = operations;
    }

    @Override
    public String toString() {
        return "PatchRequest{" +
                "schemas=" + schemas +
                ", operations=" + operations +
                '}';
    }
}
