package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Set;

public class ScimResourceList<T> {
	private Set<String> schemas;
	private int totalResults;
	private List<T> resources;
	private int startIndex;
	private int itemsPerPage;

	public ScimResourceList() {
		this.resources = List.of();
	}

	public int getTotalResults() {
		return totalResults;
	}

	public void setTotalResults(int totalResults) {
		this.totalResults = totalResults;
	}

	@JsonProperty("Resources")
	public List<T> getResources() {
		return resources;
	}

	public void setResources(List<T> resources) {
		this.resources = resources;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}

	public int getItemsPerPage() {
		return itemsPerPage;
	}

	public void setItemsPerPage(int itemsPerPage) {
		this.itemsPerPage = itemsPerPage;
	}

	public Set<String> getSchemas() {
		return schemas;
	}

	public void setSchemas(Set<String> schemas) {
		this.schemas = schemas;
	}

	@Override
	public String toString() {
		return "ScimResourceList{" +
				"schemas=" + schemas +
				", totalResults=" + totalResults +
				", resources=" + resources +
				", startIndex=" + startIndex +
				", itemsPerPage=" + itemsPerPage +
				'}';
	}
}