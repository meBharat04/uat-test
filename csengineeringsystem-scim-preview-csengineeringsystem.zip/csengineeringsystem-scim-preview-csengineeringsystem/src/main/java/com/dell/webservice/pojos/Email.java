package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Email {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private String value;
    private String type;
    private Boolean primary;

    public Email() {
    }

    public Email(String value, String type, Boolean primary) {
        this.value = value;
        this.type = type;
        this.primary = primary;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Boolean getPrimary() {
        return primary;
    }

    public void setPrimary(Boolean primary) {
        this.primary = primary;
    }

    @Override
    public String toString() {
        return "Email{" +
                "value='" + value + '\'' +
                ", type='" + type + '\'' +
                ", primary=" + primary +
                '}';
    }
}
