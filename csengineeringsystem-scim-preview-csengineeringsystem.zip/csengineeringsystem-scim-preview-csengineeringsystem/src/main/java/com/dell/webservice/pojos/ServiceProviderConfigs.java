package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class ServiceProviderConfigs {
    private Set<String> schemas;
    private Meta meta;
    private String documentationUri;
    private Map<String, Object> patch;
    private Map<String, Object> bulk;
    private Map<String, Object> filter;
    private Map<String, Object> changePassword;
    private Map<String, Object> sort;
    private Map<String, Object> etag;
    private List<Map<String, Object>> authenticationSchemes;

    @JsonProperty("urn:okta:schemas:scim:providerconfig:2.0")
    private Map<String, Object> customPropertiesMap;

    public Set<String> getSchemas() {
        return schemas;
    }

    public void setSchemas(Set<String> schemas) {
        this.schemas = schemas;
    }

    public Meta getMeta() {
        return meta;
    }

    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    public String getDocumentationUri() {
        return documentationUri;
    }

    public void setDocumentationUri(String documentationUri) {
        this.documentationUri = documentationUri;
    }

    public Map<String, Object> getPatch() {
        return patch;
    }

    public void setPatch(Map<String, Object> patch) {
        this.patch = patch;
    }

    public Map<String, Object> getBulk() {
        return bulk;
    }

    public void setBulk(Map<String, Object> bulk) {
        this.bulk = bulk;
    }

    public Map<String, Object> getFilter() {
        return filter;
    }

    public void setFilter(Map<String, Object> filter) {
        this.filter = filter;
    }

    public Map<String, Object> getChangePassword() {
        return changePassword;
    }

    public void setChangePassword(Map<String, Object> changePassword) {
        this.changePassword = changePassword;
    }

    public Map<String, Object> getSort() {
        return sort;
    }

    public void setSort(Map<String, Object> sort) {
        this.sort = sort;
    }

    public Map<String, Object> getEtag() {
        return etag;
    }

    public void setEtag(Map<String, Object> etag) {
        this.etag = etag;
    }

    public List<Map<String, Object>> getAuthenticationSchemes() {
        return authenticationSchemes;
    }

    public void setAuthenticationSchemes(List<Map<String, Object>> authenticationSchemes) {
        this.authenticationSchemes = authenticationSchemes;
    }

    public Map<String, Object> getCustomPropertiesMap() {
        return customPropertiesMap;
    }

    public void setCustomPropertiesMap(Map<String, Object> custom) {
        this.customPropertiesMap = custom;
    }

    @Override
    public String toString() {
        return "ServiceProviderConfigs{" +
                "schemas=" + schemas +
                ", meta=" + meta +
                ", documentationUri='" + documentationUri + '\'' +
                ", patch=" + patch +
                ", bulk=" + bulk +
                ", filter=" + filter +
                ", changePassword=" + changePassword +
                ", sort=" + sort +
                ", etag=" + etag +
                ", authenticationSchemes=" + authenticationSchemes +
                ", custom=" + customPropertiesMap +
                '}';
    }
}
