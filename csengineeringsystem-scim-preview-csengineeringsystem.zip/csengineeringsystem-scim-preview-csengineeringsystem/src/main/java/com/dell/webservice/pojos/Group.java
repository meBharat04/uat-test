package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Group {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private Set<String> schemas;
    private String value;
    private String display;
    private String type;
    private boolean primary;

    public Group() {
    }

    public Group(String value, String display, String type, boolean primary, Set<String> schemas) {
        this.value = value;
        this.display = display;
        this.type = type;
        this.primary = primary;
        this.schemas = schemas;
    }

    public Set<String> getSchemas() {
        return schemas;
    }

    public void setSchemas(Set<String> schemas) {
        this.schemas = schemas;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDisplay() {
        return display;
    }

    public void setDisplay(String display) {
        this.display = display;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    @Override
    public String toString() {
        return "Group{" +
                "schemas=" + schemas +
                ", value='" + value + '\'' +
                ", display='" + display + '\'' +
                ", type='" + type + '\'' +
                ", primary=" + primary +
                '}';
    }
}
