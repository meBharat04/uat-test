package com.dell.webservice;

import com.dell.webservice.api.CSEApi;
import com.dell.webservice.api.CSEApiImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.FileNotFoundException;

@Configuration
public class AppConfig {
    @Bean
    public CSEApi getCSEImpl() throws FileNotFoundException {
        return new CSEApiImpl();
    }
}