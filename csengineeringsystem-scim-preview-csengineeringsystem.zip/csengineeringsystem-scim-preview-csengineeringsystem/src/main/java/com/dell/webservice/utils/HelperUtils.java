package com.dell.webservice.utils;

import com.dell.webservice.ExceptionHandler.CustomException;
import com.dell.webservice.pojos.ClientCredentials;
import tools.jackson.databind.JsonNode;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Properties;

public class HelperUtils {
    public  static final String ROLE_TYPE = "Roles";
    public static final String CONNECTOR = "CSE";

    public static boolean checkStringNodeNotNull(JsonNode node) {
        return node != null && !node.asText().trim().equalsIgnoreCase("null");
    }

    /**
     * CS Engineering API returns numeric IDs (emp_id, RoleId, GroupId, etc.) as floating point
     * values, e.g. "5.0". Strips the trailing ".0" so SCIM ids/values are plain integers.
     */
    public static String normalizeId(String id) {
        if (id != null && id.endsWith(".0")) {
            return id.substring(0, id.length() - 2);
        }
        return id;
    }

    public static String normalizeId(JsonNode node) {
        return (node == null || node.isNull()) ? null : normalizeId(node.asText());
    }

    public static String getMethodName() {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        // Index 0: getStackTrace
        // Index 1: getMethodName (this method)
        // Index 2: The method that called getMethodName
        if (stackTrace.length > 2) {
            return stackTrace[2].getMethodName();
        }
        return "unknown";
    }

    public static void extractAndSetClientCredentials(String authorizationHeader,
                                                      Properties properties,
                                                      Logger logger) {

        ClientCredentials credentials = getClientCredentialsFromBasicAuth(authorizationHeader);

        if (credentials == null) {
            logger.error("Failed to extract client credentials from Authorization header");
            throw new CustomException("Invalid Authorization header", HttpStatus.UNAUTHORIZED);
        }

        logger.debug("Authorization header validated successfully");

        properties.setProperty(ApplicationConstants.CLIENT_ID, credentials.getClientId());
        properties.setProperty(ApplicationConstants.CLIENT_SECRET, credentials.getClientSecret());
    }

    public static ClientCredentials getClientCredentialsFromBasicAuth(String authorizationHeader) {

        if (authorizationHeader == null || !authorizationHeader.startsWith("Basic ")) {
            return null;
        }

        try {
            String base64Credentials = authorizationHeader.substring("Basic ".length());
            byte[] decodedBytes = Base64.getDecoder().decode(base64Credentials);

            String credentials = new String(decodedBytes, StandardCharsets.UTF_8);
            String[] values = credentials.split(":", 2);

            if (values.length != 2 || values[0].isBlank() || values[1].isBlank()) {
                return null;
            }

            return new ClientCredentials(values[0], values[1]);

        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
