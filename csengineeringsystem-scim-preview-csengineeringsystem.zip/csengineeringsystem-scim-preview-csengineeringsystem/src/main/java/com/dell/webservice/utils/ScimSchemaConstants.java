package com.dell.webservice.utils;

import java.util.Set;

public final class ScimSchemaConstants {


    // SCIM Core Schemas
    public static final String SCIM_USER = "urn:ietf:params:scim:schemas:core:2.0:User";

    public static final String SCIM_GROUP = "urn:ietf:params:scim:schemas:core:2.0:Group";
    public static final String SCIM_GROUP_LIST = "urn:ietf:params:scim:api:messages:2.0:ListResponse";

    public static final String ENTERPRISE_USER = "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User";


    // OKTA Extension Schemas
    public static final String OKTA_ROLE = "urn:okta:scim:schemas:core:1.0:Role";

    public static final String OKTA_ENTITLEMENT = "urn:okta:scim:schemas:core:1.0:Entitlement";

    // Common Schema Sets
    public static final Set<String> USER_SCHEMAS = Set.of(SCIM_USER, ENTERPRISE_USER);

    public static final Set<String> ROLE_SCHEMA = Set.of(OKTA_ROLE);

    public static final Set<String> ENTITLEMENT_SCHEMA = Set.of(OKTA_ENTITLEMENT);
}