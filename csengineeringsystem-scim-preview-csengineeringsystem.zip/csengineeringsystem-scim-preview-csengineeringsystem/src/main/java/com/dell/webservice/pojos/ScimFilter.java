package com.dell.webservice.pojos;

public class ScimFilter {
    private String filterAttribute;
    private String filterCondition;
    private String filterValue;

    public ScimFilter(String filterStr) {
        if(filterStr != null && filterStr.split(" ").length == 3) {
            setFilterAttribute(filterStr.split(" ")[0]);
            setFilterCondition(filterStr.split(" ")[1]);
            setFilterValue(filterStr.split(" ")[2].replace("\"", "").replace("'", ""));
        } else {
            setFilterAttribute(null);
            setFilterCondition(null);
            setFilterValue(null);
        }
    }

    public String getFilterAttribute() {
        return filterAttribute;
    }

    public void setFilterAttribute(String filterAttribute) {
        this.filterAttribute = filterAttribute;
    }

    public String getFilterCondition() {
        return filterCondition;
    }

    public void setFilterCondition(String filterCondition) {
        this.filterCondition = filterCondition;
    }

    public String getFilterValue() {
        return filterValue;
    }

    public void setFilterValue(String filterValue) {
        this.filterValue = filterValue;
    }

    @Override
    public String toString() {
        return "ScimFilter{" +
                "filterAttribute='" + filterAttribute + '\'' +
                ", filterCondition='" + filterCondition + '\'' +
                ", filterValue='" + filterValue + '\'' +
                '}';
    }
}
