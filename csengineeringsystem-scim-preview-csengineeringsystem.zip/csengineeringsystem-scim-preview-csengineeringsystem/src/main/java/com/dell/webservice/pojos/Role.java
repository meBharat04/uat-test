package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Role {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private Set<String> schemas;
    private String id;
    private String displayName;
    private String description;

    public Role() {
    }

    public Role(String value) {
        this.id = id;
    }

    public Role(String id, String displayName, String description,Set<String> schemas) {
        this.id = id;
        this.displayName = displayName;
        this.description = description;
        this.schemas=schemas;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Set<String> getSchemas() {
        return schemas;
    }


    public void setSchemas(Set<String> schemas) {
        this.schemas = schemas;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String display) {
        this.displayName = display;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Role{" +
                "id='" + id + '\'' +
                ", displayName='" + displayName + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
