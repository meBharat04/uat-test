package com.dell.webservice.pojos;


import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserRole {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private Set<String> schemas;
    private String value;
    @JsonAlias("display")
    private String displayName;

    public UserRole() {
    }

    public UserRole(String value) {
        this.value = value;
    }

    public UserRole(String value, String displayName, Set<String> schemas) {
        this.value = value;
        this.displayName = displayName;
        this.schemas=schemas;
    }

    public String getValue() {
        return value;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setDisplayName(String display) {
        this.displayName = display;
    }

    public Set<String> getSchemas() {
        return schemas;
    }

    public void setSchemas(Set<String> schemas) {
        this.schemas = schemas;
    }

    @Override
    public String toString() {
        return "UserRole{" +
                "value='" + value + '\'' +
                ", displayName='" + displayName + '\'' +
                '}';
    }
}

