package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Meta {
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String resourceType;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String created;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String lastModified;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String location;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private String version;

    public Meta() {}

    public Meta(String resourceType, String created, String lastModified, String location, String version) {
        this.resourceType = resourceType;
        this.created = created;
        this.lastModified = lastModified;
        this.location = location;
        this.version = version;
    }

    public String getResourceType() {
        return resourceType;
    }

    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    public String getLastModified() {
        return lastModified;
    }

    public void setLastModified(String lastModified) {
        this.lastModified = lastModified;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return "Meta{" +
                "resourceType='" + resourceType + '\'' +
                ", created='" + created + '\'' +
                ", lastModified='" + lastModified + '\'' +
                ", location='" + location + '\'' +
                ", version='" + version + '\'' +
                '}';
    }
}