package com.dell.webservice.controllers;

import com.dell.webservice.pojos.Meta;
import com.dell.webservice.pojos.ScimResource;
import com.dell.webservice.pojos.ScimResourceList;
import com.dell.webservice.utils.HelperUtils;
import com.dell.webservice.utils.StandardLogger;
import tools.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Set;


@RestController
@RequestMapping(path = {"/v2/ResourceTypes", "/scim/v2/ResourceTypes"})
public class ResourcesController {
	private static final Logger logger = LogManager.getLogger(ResourcesController.class);

	//TODO Identify user, entitlements resources that will be referenced
	// Probably need a group endpoint added here - check with Jonathan
	// see this:
	// https://developer.okta.com/docs/api/openapi/okta-scim/guides/scim-20/#scim-user-operations


	@GetMapping
	public ScimResourceList<ScimResource> listAllResources() {
		//TODO may need to add group resources - check with Jonathan
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ResourcesController", "listAllResources", "Starting method");
		ScimResourceList<ScimResource> response = new ScimResourceList<>();
		response.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
		response.setTotalResults(2);
		response.setStartIndex(1);
		response.setItemsPerPage(2);
		response.setResources(List.of(getUserResource(), getRoleResource()));
		logger.debug("listAllResources SCIM response payload :- {}", new ObjectMapper().writeValueAsString(response));
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ResourcesController", "listAllResources", "Ending listAllResources returning Total results: " + response.getTotalResults() + " Resources Count: ");
		return response;
	}

	private ScimResource getUserResource() {
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ResourcesController", "getUserResource", "Starting method");
		ScimResource userResource = new ScimResource();
		userResource.setId("User");
		userResource.setMeta(new Meta("ResourceType", "2023-07-17T15:25:04", "2023-07-17T15:25:04", "https://example.com/v2/ResourceTypes/User", null));
		userResource.setSchemas(Set.of("urn:ietf:params:scim:schemas:core:2.0:ResourceType"));
		userResource.setName("User");
		userResource.setDescription("User Accounts");
		userResource.setSchema("urn:ietf:params:scim:schemas:core:2.0:User");
		userResource.setSchemaExtensions(List.of(Map.of("schema", "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User", "required", true)));
		userResource.setEndpoint("/Users");
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ResourcesController", "getUserResource", "Ending getUserResource returning: " + userResource);
		return userResource;
	}

	private ScimResource getRoleResource() {
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ResourcesController", "getRoleResource", "Starting method");
		ScimResource entitlementResource = new ScimResource();
		entitlementResource.setId(HelperUtils.ROLE_TYPE);
		entitlementResource.setMeta(new Meta("ResourceType", "2023-07-17T15:25:04", "2023-07-17T15:25:04", "https://example.com/v2/ResourceTypes/Roles", null));
		entitlementResource.setSchemas(Set.of("urn:ietf:params:scim:schemas:core:2.0:ResourceType"));
		entitlementResource.setName(HelperUtils.ROLE_TYPE);
		entitlementResource.setDescription("Roles resource");
		entitlementResource.setSchema("urn:okta:scim:schemas:core:1.0:Role");
		entitlementResource.setEndpoint("/Roles");
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ResourcesController", "getRoleResource", "Ending getRoleResource returning: " + entitlementResource);
		return entitlementResource;
	}

}
