package com.dell.webservice.utils;

public final class ApplicationConstants {

    private ApplicationConstants() {
    }

    public static final String CLIENT_ID = "CLIENT_ID";
    public static final String CLIENT_SECRET = "CLIENT_SECRET";
}