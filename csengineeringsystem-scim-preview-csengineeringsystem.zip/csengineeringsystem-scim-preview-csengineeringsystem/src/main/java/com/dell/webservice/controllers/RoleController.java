package com.dell.webservice.controllers;

import com.dell.webservice.ExceptionHandler.CustomException;
import com.dell.webservice.api.CSEApi;
import com.dell.webservice.pojos.Role;
import com.dell.webservice.pojos.ScimResourceList;
import com.dell.webservice.utils.HelperUtils;
import com.dell.webservice.utils.ScimSchemaConstants;
import com.dell.webservice.utils.StandardLogger;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.*;

import java.util.*;
@RestController
@RequestMapping(path = {"/v2/Roles", "/scim/v2/Roles"})
public class RoleController {

    private static final Logger logger = LogManager.getLogger(RoleController.class);
    private static Properties properties = new Properties();
    private static CSEApi api;

    public RoleController(CSEApi CSEApI) {
        api = CSEApI;
        properties = api.getProperties();
    }

    @GetMapping
    public ScimResourceList<Role> getRoles(@RequestParam(required = false) String filter,
                                           @RequestParam(required = false) Integer count,
                                           @RequestParam(required = false) Integer startIndex,@RequestHeader("Authorization") String authorizationHeader) {
        // ToDo implement Filters
        // Check if filters are needed
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "RoleController", "getRoles", "Starting method");
        logger.debug("getRoles SCIM request payload :- filter={}, count={}, startIndex={}", filter, count, startIndex);
        //Extract ClientId and ClientSecret
        HelperUtils.extractAndSetClientCredentials(authorizationHeader, properties, logger);
        try {
            Map<String, Role> roleMap = new HashMap<>();

            JsonNode jsonNode = api.getRoles();

            ScimResourceList<Role> response = new ScimResourceList<>();
            resetRoleMap(roleMap, jsonNode);


            List<Role> roles = new ArrayList<>();
            SortedSet<String> keys = new TreeSet<>(roleMap.keySet());
            for (String key : keys) {
                roles.add(roleMap.get(key));
            }

            response.setStartIndex(startIndex != null ? startIndex : 1);
            response.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
            response.setTotalResults(roles.size());
            response.setItemsPerPage(roles.size());
            response.setResources(roles);
            logger.debug("getRoles SCIM response payload :- {}", new ObjectMapper().writeValueAsString(response));
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "RoleController", "getRoles", "Ending getRoles Total results:" + response.getTotalResults() + "  Roles Count:" + roles.size());
            return response;
        }catch (CustomException e) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to get roles", e);
            throw new CustomException(e.getMessage(),e.getStatus());
        }
    }

    private void resetRoleMap(Map<String, Role> groupMap, JsonNode jsonNode) {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "RoleController", "resetRoleMap", "Starting method");
        if(jsonNode != null && jsonNode.isArray()) {
            for(int i=0; i<jsonNode.size(); i++) {
                groupMap.put(HelperUtils.normalizeId(jsonNode.get(i).get("RoleId")), convertRoleToScimRole(jsonNode.get(i)));
            }
        } else if(jsonNode != null && jsonNode.isObject()) {
            groupMap.put(HelperUtils.normalizeId(jsonNode.get("RoleId")), convertRoleToScimRole(jsonNode));
        }
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "RoleController", "resetRoleMap", "Ending resetRoleMap");
    }

    private Role convertRoleToScimRole(JsonNode jsonNode) {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "RoleController", "convertRoleToScimRole", "Starting method");
        Role role = new Role();
        role.setId(HelperUtils.normalizeId(jsonNode.get("RoleId")));
        role.setDisplayName(jsonNode.get("RoleName").asText());
        role.setDescription(jsonNode.get("RoleDescription").asText());
        role.setSchemas(ScimSchemaConstants.ROLE_SCHEMA);
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "RoleController", "convertRoleToScimRole", "Ending convertRoleToScimRole");
        return role;
    }
}
