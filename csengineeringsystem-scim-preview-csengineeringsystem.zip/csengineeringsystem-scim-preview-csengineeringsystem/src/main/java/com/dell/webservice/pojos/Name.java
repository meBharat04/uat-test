package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Name {
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String givenName;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String familyName;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String formatted;

    public Name() {
    }

    public Name(String givenName, String familyName, String formatted) {
        this.givenName = givenName;
        this.familyName = familyName;
        this.formatted = formatted;
    }

    public String getGivenName() {
        return givenName;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public String getFormatted() {
        return formatted;
    }

    public void setFormatted(String formatted) {
        this.formatted = formatted;
    }

    @Override
    public String toString() {
        return "Name{" +
                "givenName='" + givenName + '\'' +
                ", familyName='" + familyName + '\'' +
                ", formatted='" + formatted + '\'' +
                '}';
    }
}
