package com.dell.webservice.pojos;

import tools.jackson.databind.JsonNode;

public class PatchOperation {
    private String op;
    private String path;
    private JsonNode value;

    public String getOp() {
        return op;
    }

    public void setOp(String op) {
        this.op = op;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public JsonNode getValue() {
        return value;
    }

    public void setValue(JsonNode value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "PatchOperation{" +
                "op='" + op + '\'' +
                ", path='" + path + '\'' +
                ", value=" + value +
                '}';
    }
}
