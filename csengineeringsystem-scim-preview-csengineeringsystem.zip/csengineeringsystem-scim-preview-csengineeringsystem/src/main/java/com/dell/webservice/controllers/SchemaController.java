package com.dell.webservice.controllers;

import com.dell.webservice.pojos.Meta;
import com.dell.webservice.pojos.SchemaAttribute;
import com.dell.webservice.pojos.ScimResourceList;
import com.dell.webservice.pojos.ScimSchema;
import com.dell.webservice.utils.HelperUtils;
import com.dell.webservice.utils.StandardLogger;
import tools.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@RestController
@RequestMapping(path = {"/v2/Schemas", "/scim/v2/Schemas"})
public class SchemaController {
    private static final Logger logger = LogManager.getLogger(RoleController.class);

    @GetMapping
    public ScimResourceList<ScimSchema> defaultGet() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "defaultGet", "Starting method");
        ScimResourceList<ScimSchema> schemaResponse = new ScimResourceList<>();
        schemaResponse.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
        schemaResponse.setTotalResults(3);
        schemaResponse.setStartIndex(1);
        schemaResponse.setItemsPerPage(3);

        List<ScimSchema> scimSchemas = new ArrayList<>();
        scimSchemas.add(getEntitlement());
        scimSchemas.add(getCoreUserSchema());
        scimSchemas.add(getExtendedUserSchema());
        schemaResponse.setResources(scimSchemas);
        logger.debug("defaultGet SCIM response payload :- {}", new ObjectMapper().writeValueAsString(schemaResponse));
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "defaultGet", "Ending defaultGet");
        return schemaResponse;
    }

    private ScimSchema getEntitlement(){
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getEntitlementSchema", "Starting method");
        ScimSchema scimSchema = new ScimSchema();
        scimSchema.setId("urn:okta:scim:schemas:core:1.0:Entitlement");
        scimSchema.setName("Entitlement");
        scimSchema.setDescription("Entitlement schema");
        scimSchema.setAttributes(getEntitlementAttributes());

        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getCoreUserSchema", "Ending getCoreUserSchema");
        return scimSchema;
    }

    private List<SchemaAttribute> getEntitlementAttributes() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getEntitlementAttributes", "Starting method");
        List<SchemaAttribute> attributes = new ArrayList<>();
        attributes.add(new SchemaAttribute("displayName", "string", false, "The name of the Entitlement, suitable for display to end-users.", false, false, "readWrite","default", "none", null));
        attributes.add(new SchemaAttribute("type", "string", false, "A label indicating the Entitlement's function.", false, false, "readWrite","default", "none", null));
        attributes.add(new SchemaAttribute("description", "string", false, "A label indicating the Entitlement's function.", false, false, "readWrite","default", "none", null));

        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getEntitlementAttributes", "Ending getEntitlementAttributes");
        return attributes;
    }



    private ScimSchema getCoreUserSchema() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getCoreUserSchema", "Starting method");
        ScimSchema scimSchema = new ScimSchema();
        scimSchema.setId("urn:ietf:params:scim:schemas:core:2.0:User");
        scimSchema.setMeta(new Meta("Schema", "2023-12-13T20:36:42", "2023-07-17T19:36:55", "/v2/Schemas/urn:ietf:params:scim:schemas:core:2.0:User", null));
        scimSchema.setName("User");
        scimSchema.setDescription("User Account");
        scimSchema.setAttributes(getUserCoreAttributes());
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getCoreUserSchema", "Ending getCoreUserSchema");
        return scimSchema;
    }

    //TODO This needs to change we would get it from the document
    private ScimSchema getExtendedUserSchema() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getExtendedUserSchema", "Starting method");
        ScimSchema scimSchema = new ScimSchema();
        scimSchema.setId("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User");
        scimSchema.setMeta(new Meta("Schema", "2023-12-13T20:36:42", "2023-07-17T19:36:55", "/v2/Schemas/urn:ietf:params:scim:schemas:extension:enterprise:2.0:User", null));
        scimSchema.setName("EnterpriseUser");
        scimSchema.setDescription("Enterprise User");
        scimSchema.setAttributes(getUserExtendedAttributes());
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getExtendedUserSchema", "Ending getExtendedUserSchema");
        return scimSchema;
    }

    private List<SchemaAttribute> getUserCoreAttributes() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getUserCoreAttributes", "Starting method");
        List<SchemaAttribute> attributes = new ArrayList<>();
//		attributes.add(new SchemaAttribute("id", "string", false, "Unique identifier for the User. REQUIRED.", true, false, "readWrite","default", "server", null));
        attributes.add(new SchemaAttribute("userName", "string", false, "Unique identifier for the User. REQUIRED.", true, false, "readWrite","default", "server", null));
//		attributes.add(new SchemaAttribute("displayName", "string", false, "DisplayName for the user", false, false, "readWrite","default", "none", null));
        attributes.add(new SchemaAttribute("active", "boolean", false, "A Boolean value indicating the Users administrative status.", false, false, "readWrite","default", null, null));
        attributes.add(new SchemaAttribute("emails", "complex", true, "Email addresses for the user", false, false, "readWrite","default", "none",
                List.of(new SchemaAttribute("value", "string", false, "Email addresses for the user", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("display", "string", false, "A human-readable name, primarily used for display purposes. READ-ONLY.", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("type", "string", false, "A label indicating the attributes function, e.g., work or home.", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("primary", "boolean", false, "A Boolean value indicating the primary or preferred attribute value for this attribute, e.g., the preferred mailing address or primary email address.", false, false, "readWrite","default", null, null))));


        attributes.add(new SchemaAttribute("name", "complex", false, "User's name attribute", true, false, "readWrite","default", "none",
                List.of(new SchemaAttribute("givenName", "string", false, "User's first name", true, false, "readWrite","default", "none", null),
                        new SchemaAttribute("familyName", "string", false, "User's last name", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("formattedName", "string", false, "User's full name", false, false, "readWrite","default", "none", null))));

        attributes.add(new SchemaAttribute("entitlements", "complex", true, "A list of responsibilities for the User that collectively represent who the User.", false, false, "readWrite","default", null,
                List.of(new SchemaAttribute("value", "string", false, "The value of a responsibility.", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("display", "string", false, "A human-readable name, primarily used for display purposes. READ-ONLY.", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("type", "string", false, "A label indicating the attributes function.", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("description", "string", false, "A label indicating the attributes description.", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("primary", "boolean", false, "description for entitlement.", false, false, "readWrite","default", "none", null))));

        attributes.add(new SchemaAttribute("roles", "complex", true, "A list of responsibilities for the User that collectively represent who the User.", false, false, "readWrite","default", null,
                List.of(new SchemaAttribute("value", "string", false, "The value of a responsibility.", false, false, "readWrite","default", "none", null),
                        new SchemaAttribute("display", "string", false, "A human-readable name, primarily used for display purposes. READ-ONLY.", false, false, "readWrite","default", "none", null))));
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getUserCoreAttributes", "Ending getUserCoreAttributes");
        return attributes;
    }

    private List<SchemaAttribute> getUserExtendedAttributes() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getUserExtendedAttributes", "Starting method");
        List<SchemaAttribute> attributes = new ArrayList<>();
        attributes.add(new SchemaAttribute("employeeNumber", "string", false, "employee's id", false, false, "readWrite","default", "none", null));
        attributes.add(new SchemaAttribute("csId", "string", false, "cs engineering id", false, false, "readWrite","default", "none", null));
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "SchemaController", "getUserExtendedAttributes", "Ending getUserExtendedAttributes");

        return attributes;
    }
}
