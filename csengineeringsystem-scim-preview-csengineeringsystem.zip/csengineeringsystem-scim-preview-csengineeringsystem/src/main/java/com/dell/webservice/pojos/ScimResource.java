package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;
import java.util.Map;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScimResource {
	private String id;
	private String name;
	private String description;
	private Meta meta;
	private Set<String> schemas;
	private String schema;
	private String endpoint;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<Map<String, Object>> schemaExtensions;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Meta getMeta() {
		return meta;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}

	public Set<String> getSchemas() {
		return schemas;
	}

	public void setSchemas(Set<String> schemas) {
		this.schemas = schemas;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public List<Map<String, Object>> getSchemaExtensions() {
		return schemaExtensions;
	}

	public void setSchemaExtensions(List<Map<String, Object>> schemaExtensions) {
		this.schemaExtensions = schemaExtensions;
	}

	@Override
	public String toString() {
		return "ScimResource{" +
				"id='" + id + '\'' +
				", name='" + name + '\'' +
				", description='" + description + '\'' +
				", meta=" + meta +
				", schemas=" + schemas +
				", schema='" + schema + '\'' +
				", endpoint='" + endpoint + '\'' +
				", schemaExtensions=" + schemaExtensions +
				'}';
	}
}
