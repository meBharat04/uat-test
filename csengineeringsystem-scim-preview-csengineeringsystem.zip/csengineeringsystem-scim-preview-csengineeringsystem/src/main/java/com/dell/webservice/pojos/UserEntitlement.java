package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserEntitlement {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private Set<String> schemas;
    private String value;
    private String displayName;
    private String type;
    private boolean primary;

    public UserEntitlement() {
    }

    public UserEntitlement(String value, String displayName, String type, boolean primary, Set<String> schemas) {
        this.value = value;
        this.displayName = displayName;
        this.type = type;
        this.primary = primary;
        this.schemas = schemas;
    }

    public Set<String> getSchemas() {
        return schemas;
    }

    public void setSchemas(Set<String> schemas) {
        this.schemas = schemas;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isPrimary() {
        return primary;
    }

    public void setPrimary(boolean primary) {
        this.primary = primary;
    }

    @Override
    public String toString() {
        return "Entitlement{" +
                "schemas=" + schemas +
                ", value='" + value + '\'' +
                ", display='" + displayName + '\'' +
                ", type='" + type + '\'' +
                ", primary=" + primary +
                '}';
    }
}
