package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SchemaAttribute {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private String name;
    private String type;
    private String description;
    private boolean multiValued;
    private boolean required;
    private boolean caseExact;
    private String mutability;
    private String returned;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String uniqueness;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<SchemaAttribute> subAttributes;

    public SchemaAttribute() {
    }

    public SchemaAttribute(String name, String type, boolean multiValued, String description, boolean required, boolean caseExact, String mutability, String returned, String uniqueness, List<SchemaAttribute> subAttributes) {
        this.name = name;
        this.type = type;
        this.multiValued = multiValued;
        this.description = description;
        this.required = required;
        this.caseExact = caseExact;
        this.mutability = mutability;
        this.returned = returned;
        this.uniqueness = uniqueness;
        this.subAttributes = subAttributes;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isMultiValued() {
        return multiValued;
    }

    public void setMultiValued(boolean multiValued) {
        this.multiValued = multiValued;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isCaseExact() {
        return caseExact;
    }

    public void setCaseExact(boolean caseExact) {
        this.caseExact = caseExact;
    }

    public String getMutability() {
        return mutability;
    }

    public void setMutability(String mutability) {
        this.mutability = mutability;
    }

    public String getReturned() {
        return returned;
    }

    public void setReturned(String returned) {
        this.returned = returned;
    }

    public String getUniqueness() {
        return uniqueness;
    }

    public void setUniqueness(String uniqueness) {
        this.uniqueness = uniqueness;
    }

    public List<SchemaAttribute> getSubAttributes() {
        return subAttributes;
    }

    public void setSubAttributes(List<SchemaAttribute> subAttributes) {
        this.subAttributes = subAttributes;
    }

    @Override
    public String toString() {
        return "Attribute{" +
                "name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", description='" + description + '\'' +
                ", multiValued=" + multiValued +
                ", required=" + required +
                ", caseExact=" + caseExact +
                ", mutability='" + mutability + '\'' +
                ", returned='" + returned + '\'' +
                ", uniqueness='" + uniqueness + '\'' +
                ", subAttributes=" + subAttributes +
                '}';
    }
}