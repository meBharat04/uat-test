package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScimSchema {
	private String id;
	private String name;
	private String description;
	private Meta meta;
	private List<SchemaAttribute> attributes;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Meta getMeta() {
		return meta;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}

	public List<SchemaAttribute> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<SchemaAttribute> attributes) {
		this.attributes = attributes;
	}

	@Override
	public String toString() {
		return "ScimSchema{" +
				"id='" + id + '\'' +
				", name='" + name + '\'' +
				", description='" + description + '\'' +
				", meta=" + meta +
				", attributes=" + attributes +
				'}';
	}
}
