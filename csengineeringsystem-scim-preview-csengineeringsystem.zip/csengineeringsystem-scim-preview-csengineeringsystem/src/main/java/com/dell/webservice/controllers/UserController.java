package com.dell.webservice.controllers;

import com.dell.webservice.ExceptionHandler.CustomException;
import com.dell.webservice.api.CSEApi;
import com.dell.webservice.pojos.*;
import com.dell.webservice.utils.HelperUtils;
import com.dell.webservice.utils.ScimSchemaConstants;
import com.dell.webservice.utils.StandardLogger;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@RestController
@RequestMapping(path = {"/v2/Users", "/scim/v2/Users"})
public class UserController {
    private static final Logger logger = LogManager.getLogger(UserController.class);
    private static Properties properties = new Properties();
    private final CSEApi api;

    @Autowired
    private ObjectMapper objectMapper;

    @Value("${cse.import.user-limit:0}")
    private int importUserLimit;

    @Autowired
    public UserController(CSEApi cseApI) {
        api = cseApI;
        properties = api.getProperties();
    }

    @GetMapping
    public ScimResourceList<ScimUserV2> getUsers(@RequestParam(required = false) String filter,
                                                 @RequestParam(required = false) Integer count,
                                                 @RequestParam(required = false) Integer startIndex,
                                                 @RequestHeader("Authorization") String authorizationHeader) {

        long startTime = System.currentTimeMillis();
        logger.debug("getUsers SCIM request payload :- filter={}, count={}, startIndex={}", filter, count, startIndex);
        StandardLogger.logInfo(logger, startTime, HelperUtils.CONNECTOR, "UserController", "getUsers", "Starting getUsers method");

        HelperUtils.extractAndSetClientCredentials(authorizationHeader, properties, logger);
        try {
            ScimFilter scimFilter = new ScimFilter(filter);
            ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
            resourceList.setSchemas(Set.of(
                    "urn:ietf:params:scim:api:messages:2.0:ListResponse"
            ));
            resourceList.setStartIndex(startIndex != null ? startIndex : 1);

            if (scimFilter.getFilterAttribute() != null && scimFilter.getFilterValue() != null && !scimFilter.getFilterValue().isEmpty()) {
                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUsers", "Filter present, resolving single user via GetUserDetailsById. Filter: " + filter);

                List<ScimUserV2> users = new ArrayList<>();
                long downstreamStart = System.currentTimeMillis();
                try {
                    ScimUserV2 user = getUser(scimFilter.getFilterValue(), authorizationHeader);
                    if (user != null) {
                        users.add(user);
                    }
                } catch (CustomException e) {
                    StandardLogger.logWarn(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUsers", "No user found via GetUserDetailsById for filter value: " + scimFilter.getFilterValue());
                }
                long downstreamTimeMs = System.currentTimeMillis() - downstreamStart;
                resourceList.setTotalResults(users.size());
                resourceList.setItemsPerPage(users.size());
                resourceList.setResources(users);

                logger.debug("getUsers SCIM response payload :- {}", new ObjectMapper().writeValueAsString(resourceList));
                long totalTimeMs = System.currentTimeMillis() - startTime;
                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUsers",
                        "Ending getUsers method via filter. Returning users count: " + users.size()
                                + ", downstreamApiTimeMs=" + downstreamTimeMs + ", totalProcessTimeMs=" + totalTimeMs);
                return resourceList;
            }

            Map<String, ScimUserV2> userMap = new HashMap<>();
            int pageSize = count != null ? count : 20;
            int pageNo = (startIndex != null ? ((startIndex - 1) / pageSize) + 1 : 1);

            long downstreamStart = System.currentTimeMillis();
            JsonNode response = api.getUsers(pageNo, pageSize, scimFilter);
            long downstreamTimeMs = System.currentTimeMillis() - downstreamStart;
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUsers",
                    "Downstream api.getUsers call completed. pageNo=" + pageNo + ", pageSize=" + pageSize + ", downstreamApiTimeMs=" + downstreamTimeMs);

            int totalRecords = response.has("totalEmployees") ? response.get("totalEmployees").asInt() : importUserLimit;
            JsonNode allUsers = response.get("employeeDetails");

            if (importUserLimit > 0) {
                if (importUserLimit < totalRecords) {
                    totalRecords = importUserLimit;
                }
                allUsers = truncateToLimit(allUsers, resourceList.getStartIndex(), totalRecords);
            }

            resetUserMap(userMap, allUsers);

            List<ScimUserV2> users = new ArrayList<>();
            SortedSet<String> keys = new TreeSet<>(userMap.keySet());
            for (String key : keys) {
                users.add(userMap.get(key));
            }
            resourceList.setTotalResults(totalRecords);
            resourceList.setItemsPerPage(users.size());
            resourceList.setResources(users);

            logger.debug("getUsers SCIM response payload :- {}", new ObjectMapper().writeValueAsString(resourceList));
            long totalTimeMs = System.currentTimeMillis() - startTime;
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUsers",
                    "Ending getUsers method. Returning users count: " + users.size()
                            + ", downstreamApiTimeMs=" + downstreamTimeMs + ", totalProcessTimeMs=" + totalTimeMs);
            return resourceList;
        }catch (CustomException e) {
            long totalTimeMs = System.currentTimeMillis() - startTime;
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to get Users. totalProcessTimeMs=" + totalTimeMs, e);
            throw new CustomException(e.getMessage(),e.getStatus());
        }
    }

    private JsonNode truncateToLimit(JsonNode employeeDetails, int startIndex, int totalRecords) {
        if (employeeDetails == null || !employeeDetails.isArray()) {
            return employeeDetails;
        }
        int remaining = totalRecords - (startIndex - 1);
        if (remaining <= 0) {
            return new ObjectMapper().createArrayNode();
        }
        if (employeeDetails.size() <= remaining) {
            return employeeDetails;
        }
        ArrayNode trimmed = new ObjectMapper().createArrayNode();
        for (int i = 0; i < remaining; i++) {
            trimmed.add(employeeDetails.get(i));
        }
        return trimmed;
    }

    @GetMapping("/{id}")
    public ScimUserV2 getUser(@PathVariable("id") String userId, @RequestHeader("Authorization") String authorizationHeader){
        userId = HelperUtils.normalizeId(userId);
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUser", "Starting getUser method to get user by userId:" + userId);
        logger.debug("getUser SCIM request payload :- userId={}", userId);
        HelperUtils.extractAndSetClientCredentials(authorizationHeader, properties, logger);
        try {
            Map<String, ScimUserV2> userMap = new HashMap<>();
            JsonNode allUsers = api.getUser(userId);
            resetUserMap(userMap, allUsers);
            ScimUserV2 user = userMap.get(userId);
            if (user != null) {
                logger.debug("getUser SCIM response payload :- {}", new ObjectMapper().writeValueAsString(user));
                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUser", "Ending getUser method returning user:" + user.getId());

                return user;
            } else {
                StandardLogger.logWarn(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUser", "User with userId:" + userId + " not found in response.");

                return null;
            }
        } catch (CustomException e) {
            StandardLogger.logWarn(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "getUser", "User with userId: " + userId + " not found or error occurred: " + e.getMessage());
            throw new CustomException(e.getMessage(),e.getStatus());
        }

    }
    @PutMapping("/{id}")
    public ScimUserV2 updateUser(@RequestBody ScimUserV2 user, @PathVariable("id") String userId, @RequestHeader("Authorization") String authorizationHeader) {
        userId = HelperUtils.normalizeId(userId);
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "updateUser", "Starting updateUser for userId: "+userId +" with user: " + user);
        logger.debug("updateUser SCIM request payload :- {}", new ObjectMapper().writeValueAsString(user));
        HelperUtils.extractAndSetClientCredentials(authorizationHeader, properties, logger);
        try {
            ScimUserV2 existingUser = getUser(userId, authorizationHeader);
            if (existingUser == null) {
                throw new CustomException("User not found: " + userId, HttpStatus.NOT_FOUND);
            }

            ScimUserV2 target = new ObjectMapper().convertValue(existingUser, ScimUserV2.class);
            target.setId(userId);

            boolean active = !Boolean.FALSE.equals(user.getActive());

            if (!active) {
                // Only remove the roles/entitlements listed in the request payload, not every
                // role the downstream app currently has for this user.
                Set<String> payloadRoleValues = user.getRoles() != null
                        ? user.getRoles().stream().map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet())
                        : Collections.emptySet();
                removeRoles(target, payloadRoleValues, userId);
                target.setActive(false);
            } else {
                // No add-roles API call here: roles the downstream app already has (from getUser
                // by Id) that aren't in the Okta payload are simply appended to the response.
                List<UserRole> payloadRoles = user.getRoles() != null ? new ArrayList<>(user.getRoles()) : new ArrayList<>();
                Set<String> payloadValues = payloadRoles.stream().map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet());

                List<UserRole> existingOnlyRoles = target.getRoles() != null
                        ? target.getRoles().stream().filter(r -> r.getValue() != null && !payloadValues.contains(r.getValue())).collect(Collectors.toList())
                        : Collections.emptyList();

                List<UserRole> mergedRoles = new ArrayList<>(payloadRoles);
                mergedRoles.addAll(existingOnlyRoles);
                target.setRoles(mergedRoles);
                target.setActive(true);
            }

            logger.debug("updateUser SCIM response payload :- {}", new ObjectMapper().writeValueAsString(target));
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "updateUser", "Ending updateUser for user: " + target);
            return target;
        } catch (CustomException e) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to Update User", e);
            throw new CustomException(e.getMessage(), e.getStatus());
        }
    }

    @PostMapping
    public ScimUserV2 createUser(@RequestBody ScimUserV2 user, @RequestHeader("Authorization") String authorizationHeader) {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "createUser", "Starting createUser method to Create CSE Member: " + user);
        logger.debug("createUser SCIM request payload :- {}", new ObjectMapper().writeValueAsString(user));
        try {
            JsonNode responseBody = null;
            if (user.getScimUserV2CustomAttributes() != null) {
                ScimUserV2CustomAttributes attrs = user.getScimUserV2CustomAttributes();
                user.setScimUserV2CustomAttributes(attrs);
            }

            if (user.getSchemas() != null) {
                Set<String> sanitizedSchemas = user.getSchemas().stream()
                        .filter(Objects::nonNull)
                        .map(schema -> StringEscapeUtils.escapeHtml4(schema.trim()))
                        .collect(Collectors.toSet());
                user.setSchemas(sanitizedSchemas);
            }

            if (user.getRoles() != null) {
                for (UserRole role : user.getRoles()) {
                    if (role.getValue() != null) {
                        role.setValue(StringEscapeUtils.escapeHtml4(role.getValue()));
                    }
                }
            }

            if (user.getRoles() != null)
                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "createUser", "creating user with roles: " + user.getRoles());

            String roleId = null;
            if (user.getRoles() != null && !user.getRoles().isEmpty()) {
                UserRole role = user.getRoles().get(0);
                if (role.getValue() != null) {
                    roleId = StringEscapeUtils.escapeHtml4(role.getValue());
                }
            }
            responseBody = api.createUser(convertScimUserToJsonNode(user));
            user = getUser(HelperUtils.normalizeId(responseBody.get("empId")), authorizationHeader);

            logger.debug("createUser SCIM response payload :- {}", new ObjectMapper().writeValueAsString(user));
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "createUser", "Ending createUser method returning User: " + user);
            return user;
        }catch (CustomException e) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to Create User", e);
            throw new CustomException(e.getMessage(),e.getStatus());
        }
    }

    @PatchMapping("/{id}")
    public ScimUserV2 patchUser(@RequestBody PatchRequest patchRequest, @PathVariable("id") String userId,
                                @RequestHeader("Authorization") String authorizationHeader) {
        userId = HelperUtils.normalizeId(userId);
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "patchUser", "Starting patchUser for userId: " + userId + " with operations: " + (patchRequest != null ? patchRequest.getOperations() : null));
        logger.debug("patchUser SCIM request payload :- {}", new ObjectMapper().writeValueAsString(patchRequest));
        HelperUtils.extractAndSetClientCredentials(authorizationHeader, properties, logger);
        try {
            ScimUserV2 existingUser = getUser(userId, authorizationHeader);
            if (existingUser == null) {
                throw new CustomException("User not found: " + userId, HttpStatus.NOT_FOUND);
            }

            ScimUserV2 target = new ObjectMapper().convertValue(existingUser, ScimUserV2.class);
            target.setId(userId);

            if (patchRequest != null && patchRequest.getOperations() != null) {
                for (PatchOperation operation : patchRequest.getOperations()) {
                    applyPatchOperation(target, operation, userId);
                }
            }

            ScimUserV2 user = getUser(userId, authorizationHeader);
            logger.debug("patchUser SCIM response payload :- {}", new ObjectMapper().writeValueAsString(user));
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "patchUser", "Ending patchUser for user: " + user);
            return user;
        } catch (CustomException e) {
            StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, this.getClass().getSimpleName(), HelperUtils.getMethodName(), null, "Failed to Patch User", e);
            throw new CustomException(e.getMessage(), e.getStatus());
        }
    }

    private void applyPatchOperation(ScimUserV2 target, PatchOperation operation, String userId) {
        if (operation == null || operation.getOp() == null) {
            return;
        }
        String op = operation.getOp().trim().toLowerCase();
        String path = operation.getPath();
        JsonNode value = operation.getValue();

        if (path == null || path.isEmpty()) {
            if (value != null && value.isObject()) {
                for (Map.Entry<String, JsonNode> entry : value.properties()) {
                    applyAttributePatch(target, entry.getKey(), op, entry.getValue(), userId);
                }
            }
            return;
        }

        String attribute = path.split("\\[")[0].trim();

        if ("roles".equalsIgnoreCase(attribute) && path.contains("[") && "remove".equals(op)) {
            String filterValue = extractFilterValue(path);
            if (filterValue != null) {
                removeRoles(target, Set.of(filterValue), userId);
                return;
            }
        }

        applyAttributePatch(target, attribute, op, value, userId);
    }

    private void applyAttributePatch(ScimUserV2 target, String attribute, String op, JsonNode value, String userId) {
        if ("active".equalsIgnoreCase(attribute)) {
            if (value != null && !value.isNull() && !value.asBoolean()) {
                Set<String> currentRoles = target.getRoles() != null
                        ? target.getRoles().stream().map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet())
                        : Collections.emptySet();
                removeRoles(target, currentRoles, userId);
                target.setActive(false);
            } else if (value != null && !value.isNull()) {
                target.setActive(true);
            }
            return;
        }

        if ("roles".equalsIgnoreCase(attribute)) {
            switch (op) {
                case "add":
                    addRoles(target, toRoleList(value), userId);
                    break;
                case "remove":
                    if (value == null || value.isNull()) {
                        Set<String> currentRoles = target.getRoles() != null
                                ? target.getRoles().stream().map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet())
                                : Collections.emptySet();
                        removeRoles(target, currentRoles, userId);
                    } else {
                        removeRoles(target, toRoleList(value).stream()
                                .map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet()), userId);
                    }
                    break;
                default:
                    List<UserRole> newRoles = toRoleList(value);
                    Set<String> newValues = newRoles.stream().map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet());
                    Set<String> existingValues = target.getRoles() != null
                            ? target.getRoles().stream().map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet())
                            : Collections.emptySet();
                    Set<String> valuesToAdd = new HashSet<>(newValues);
                    valuesToAdd.removeAll(existingValues);
                    Set<String> valuesToRemove = new HashSet<>(existingValues);
                    valuesToRemove.removeAll(newValues);
                    addRoles(target, newRoles.stream().filter(r -> valuesToAdd.contains(r.getValue())).collect(Collectors.toList()), userId);
                    removeRoles(target, valuesToRemove, userId);
                    break;
            }
        }
    }

    private List<UserRole> toRoleList(JsonNode value) {
        if (value == null || value.isNull()) {
            return Collections.emptyList();
        }
        ObjectMapper mapper = new ObjectMapper();
        JsonNode roleArray = value.isArray() ? value : mapper.createArrayNode().add(value);
        return mapper.convertValue(roleArray, new TypeReference<List<UserRole>>() {});
    }

    private void addRoles(ScimUserV2 target, List<UserRole> rolesToAdd, String userId) {
        List<UserRole> current = target.getRoles() != null ? new ArrayList<>(target.getRoles()) : new ArrayList<>();
        Set<String> existingValues = current.stream().map(UserRole::getValue).filter(Objects::nonNull).collect(Collectors.toSet());
        ObjectMapper mapper = new ObjectMapper();
        for (UserRole role : rolesToAdd) {
            if (role.getValue() != null && !existingValues.contains(role.getValue())) {
                ObjectNode requestObj = mapper.createObjectNode();
                ArrayNode arrayNode = mapper.createArrayNode();
                convertScimUserToRolePayLoad(requestObj, target, role, 1); // 1 = add
                arrayNode.add(requestObj);
                api.addRoles(arrayNode, userId);
                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "patchUser", "Added role " + role.getValue() + " to user " + userId);
                current.add(role);
                existingValues.add(role.getValue());
            }
        }
        target.setRoles(current);
    }

    private void removeRoles(ScimUserV2 target, Set<String> valuesToRemove, String userId) {
        if (target.getRoles() == null || valuesToRemove.isEmpty()) {
            return;
        }
        ObjectMapper mapper = new ObjectMapper();
        List<UserRole> remaining = new ArrayList<>();
        for (UserRole role : target.getRoles()) {
            if (role.getValue() != null && valuesToRemove.contains(role.getValue())) {
                ObjectNode requestObj = mapper.createObjectNode();
                ArrayNode arrayNode = mapper.createArrayNode();
                convertScimUserToRolePayLoad(requestObj, target, role, 0); // 0 = remove
                arrayNode.add(requestObj);
                api.removeRole(arrayNode, userId);
                StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "patchUser", "Removed role " + role.getValue() + " from user " + userId);
            } else {
                remaining.add(role);
            }
        }
        target.setRoles(remaining);
    }

    private static final Pattern VALUE_EQ_FILTER_PATTERN = Pattern.compile("value\\s+eq\\s+[\"']([^\"']+)[\"']", Pattern.CASE_INSENSITIVE);

    private String extractFilterValue(String path) {
        int start = path.indexOf('[');
        int end = path.lastIndexOf(']');
        if (start < 0 || end < 0 || end < start) {
            return null;
        }
        String filterExpression = path.substring(start + 1, end).trim();
        Matcher matcher = VALUE_EQ_FILTER_PATTERN.matcher(filterExpression);
        return matcher.find() ? HelperUtils.normalizeId(matcher.group(1)) : null;
    }

    private void resetUserMap(Map<String, ScimUserV2> userMap, JsonNode jsonNode) {
        logger.debug("UserController", "resetUserMap", "Starting method");
        if (jsonNode == null) return;

        if (jsonNode.isArray()) {
            logger.debug("UserController", "convertUserToScimUser", "Starting method");
            for (JsonNode userNode : jsonNode) {
                try {
                    String userId = HelperUtils.normalizeId(userNode.get("emp_id"));
                    ScimUserV2 user = convertUserToScimUser(userNode);
                    userMap.put(userId, user);
                } catch (Exception e) {
                    StandardLogger.logError(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "resetUserMap", null, "Error fetching entitlements for member", e);
                    throw new CustomException(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        } else if (jsonNode.isObject()) {
            String userId = HelperUtils.normalizeId(jsonNode.get("emp_id"));
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "convertUserToScimUser", "Starting method");
            userMap.put(userId, convertUserToScimUser(jsonNode));
            StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "convertUserToScimUser", "Ending method");
        }
        logger.debug("UserController", "resetUserMap", "Ending method");

    }

    private JsonNode convertScimUserToJsonNode(ScimUserV2 user) {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "convertScimUserToJsonNode", "Starting method");
        //Build JSON request payload
        List<Email> emailList = user.getEmails();
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode userNode = mapper.createObjectNode();
        userNode.put("emp_id",0.0);
        if(user.getUserName() != null) userNode.put("emp_login_name", user.getUserName());
        if(user.getEmails() != null) userNode.put("emp_email", emailList.stream().findFirst().orElse(new Email()).getValue());
        if (user.getName() != null){
            userNode.put("emp_first_name", user.getName().getGivenName());
            userNode.put("emp_last_name", user.getName().getFamilyName());
        }
        ArrayNode rolesArray = mapper.createArrayNode();
        if (user.getRoles() != null && !user.getRoles().isEmpty()) {
            for (UserRole role : user.getRoles()) {
                ObjectNode roleNode = mapper.createObjectNode();
                roleNode.put("EmployeeID", 0.0);
                roleNode.put("RoleId", role.getValue());
                rolesArray.add(roleNode);
            }
        }

        userNode.set("EmployeeRoles", rolesArray);
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "UserController", "convertScimUserToJsonNode", "Ending method");
        return userNode;
    }
    private void convertScimUserToRolePayLoad(ObjectNode userNode,ScimUserV2 user,UserRole role,int isAdd){

        userNode.put("employeeID", user.getId());
        userNode.put("roleId", role.getValue());
        userNode.put("isAdd", isAdd);
        userNode.put("createdBy", "IdentityNow");

    }

    private ScimUserV2 convertUserToScimUser(JsonNode jsonNode) {
        logger.debug("UserController", "convertUserToScimUser", "Starting convertUserToScimUser method");

        ScimUserV2 scimUser = new ScimUserV2();

        //Schemas
        scimUser.setSchemas(ScimSchemaConstants.USER_SCHEMAS);

        //Basic Attributes
        scimUser.setId(HelperUtils.normalizeId(jsonNode.get("emp_id")));
        scimUser.setUserName(jsonNode.get("emp_login_name").asText());
        scimUser.setName(new Name());
        scimUser.getName().setGivenName(jsonNode.get("emp_first_name").asText());
        scimUser.getName().setFamilyName(jsonNode.get("emp_last_name").asText());
        scimUser.setActive(jsonNode.path("emp_status").asBoolean());
        List<Email> emails = new ArrayList<>();
        if(jsonNode.has("emp_email")){
            Email email = new Email();
            email.setValue(jsonNode.get("emp_email").asText());
            emails.add(email);
            scimUser.setEmails(emails);
        }

        List<UserRole> roles = new ArrayList<>();
        JsonNode employeeRoles = jsonNode.has("EmployeeRoles") ? jsonNode.get("EmployeeRoles") : null;
        if (employeeRoles.isArray()) {
            for (JsonNode role: employeeRoles) {
                UserRole role1 = new UserRole();

                role1.setValue(HelperUtils.normalizeId(role.get("RoleId")));
                role1.setDisplayName(role.get("RoleName").asText());
                role1.setSchemas(ScimSchemaConstants.ROLE_SCHEMA);
                roles.add(role1);

            }
            scimUser.setRoles(roles);
        }

        List<UserEntitlement> entitlements = new ArrayList<>();
        JsonNode userGroups = jsonNode.has("UserGroups")&& jsonNode.get("UserGroups")!=null ? jsonNode.get("UserGroups") : null;
        if (userGroups.isArray() && !userGroups.isEmpty()) {
            for (JsonNode entitlement: userGroups) {
                UserEntitlement entitlement1 = new UserEntitlement();

                entitlement1.setValue(HelperUtils.normalizeId(entitlement.get("GroupId")));
                entitlement1.setDisplayName(entitlement.get("GroupName").asText());
                entitlement1.setSchemas(ScimSchemaConstants.ENTITLEMENT_SCHEMA);
                entitlements.add(entitlement1);

            }
            scimUser.setEntitlements(entitlements);
        }

//        custom Attributes
        scimUser.setScimUserV2CustomAttributes(new ScimUserV2CustomAttributes());
        scimUser.getScimUserV2CustomAttributes().setEmployeeNumber(HelperUtils.normalizeId(jsonNode.get("emp_id")));
        scimUser.getScimUserV2CustomAttributes().setCsId(scimUser.getId());
        logger.debug("UserController", "convertUserToScimUser", "Ending method for user {}", scimUser.getUserName() );

        return scimUser;
    }

}