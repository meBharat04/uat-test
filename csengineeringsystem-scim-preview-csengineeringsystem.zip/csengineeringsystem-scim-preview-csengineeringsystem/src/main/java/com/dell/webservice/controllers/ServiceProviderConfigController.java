package com.dell.webservice.controllers;

import com.dell.webservice.pojos.Meta;
import com.dell.webservice.pojos.ServiceProviderConfigs;
import com.dell.webservice.utils.HelperUtils;
import com.dell.webservice.utils.StandardLogger;
import tools.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RestController
@RequestMapping(path = {"/v2/ServiceProviderConfig", "/scim/v2/ServiceProviderConfig"})
public class ServiceProviderConfigController {

	private static final Logger logger = LogManager.getLogger(ServiceProviderConfigController.class);

	@GetMapping
	public ServiceProviderConfigs getServiceProviderConfigs() {
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ServiceProviderConfigController", "getServiceProviderConfigs", "Starting method");
		ServiceProviderConfigs serviceProviderConfigs = new ServiceProviderConfigs();
		serviceProviderConfigs.setSchemas(Set.of("urn:okta:schemas:scim:providerconfig:2.0", "urn:ietf:params:scim:schemas:core:2.0:ServiceProviderConfig"));
		serviceProviderConfigs.setMeta(new Meta(null, "2025-02-06T13:46:20.140576", "2025-02-06T13:46:20.140614", null, "v1.0"));
		serviceProviderConfigs.setDocumentationUri("https://support.okta.com/scim-fake-page.html");
		serviceProviderConfigs.setPatch(Map.of("supported", true, "maxOperations", 100));
		serviceProviderConfigs.setBulk(Map.of("supported", true));
		serviceProviderConfigs.setFilter(Map.of("supported", true, "maxResults", 100));
		serviceProviderConfigs.setChangePassword(Map.of("supported", true));
		serviceProviderConfigs.setSort(Map.of("supported", false));
		serviceProviderConfigs.setEtag(Map.of("supported", false));

		serviceProviderConfigs.setAuthenticationSchemes(List.of(Map.of("type", "oauthbearertoken",
				"name", "OAuth Bearer Token", "description", "Authentication scheme using the OAuth Bearer Token Standard",
				"specUri", "http://www.rfc-editor.org/info/rfc6750", "documentationUri", "http://example.com/help/oauth.html")));

		serviceProviderConfigs.setCustomPropertiesMap(Map.of("userManagementCapabilities",
				List.of("IMPORT_NEW_USERS",
						"IMPORT_PROFILE_UPDATES",
						"PUSH_NEW_USERS",
						"PUSH_PASSWORD_UPDATES",
						"PUSH_PENDING_USERS",
						"PUSH_PROFILE_UPDATES",
						"PUSH_USER_DEACTIVATION",
						"REACTIVATE_USERS",
						"IMPORT_USER_SCHEMA",
						"OPP_SCIM_INCREMENTAL_IMPORTS",
						"PUSH_NEW_USERS_WITHOUT_PASSWORD")));

		logger.debug("getServiceProviderConfigs SCIM response payload :- {}", new ObjectMapper().writeValueAsString(serviceProviderConfigs));
		StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "ServiceProviderConfigController", "getServiceProviderConfigs", "Ending method");
		return serviceProviderConfigs;
	}
}