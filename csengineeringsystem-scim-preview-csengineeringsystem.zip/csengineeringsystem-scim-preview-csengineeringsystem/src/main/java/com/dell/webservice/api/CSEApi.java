package com.dell.webservice.api;

import com.dell.webservice.pojos.ScimFilter;
import tools.jackson.databind.JsonNode;

import java.util.Properties;

public interface CSEApi {
    //Config
    public Properties getProperties();
    //token
    public void generateToken();



    //Members & Sales
    public JsonNode getUsers(Integer pageNo, Integer pageSize, ScimFilter filter);
    public JsonNode getUser(String Id);
    public JsonNode getRoles();
    public JsonNode createUser(JsonNode userNode);
    public JsonNode addRoles(JsonNode userNode, String userId);
    public JsonNode removeRole(JsonNode userNode,String userId);
}