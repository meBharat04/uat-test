package com.dell.webservice.controllers;

import com.dell.webservice.utils.HelperUtils;
import com.dell.webservice.utils.ScimSchemaConstants;
import com.dell.webservice.utils.StandardLogger;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ArrayNode;
import tools.jackson.databind.node.ObjectNode;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path = {"/v2/Groups", "/scim/v2/Groups"})
public class GroupController {

    private static final Logger logger = LogManager.getLogger(GroupController.class);

    @GetMapping
    public ResponseEntity<JsonNode> getGroups() {
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "GroupController", "getGroups", "Starting getGroups method");
        JsonNode response = getGroupsResponse();
        logger.debug("getGroups SCIM response payload :- {}", new ObjectMapper().writeValueAsString(response));
        StandardLogger.logInfo(logger, System.currentTimeMillis(), HelperUtils.CONNECTOR, "GroupController", "getGroups", "Ending getGroups method");
        return ResponseEntity.ok(response);
    }

    public static JsonNode getGroupsResponse() {

        ObjectMapper mapper = new ObjectMapper();

        ObjectNode response = mapper.createObjectNode();

        ArrayNode schemas = mapper.createArrayNode();
        schemas.add(ScimSchemaConstants.SCIM_GROUP_LIST);

        response.set("schemas", schemas);
        response.put("totalResults", 0);
        response.put("startIndex", 1);
        response.put("itemsPerPage", 0);
        response.set("Resources", mapper.createArrayNode());

        return response;
    }
}
