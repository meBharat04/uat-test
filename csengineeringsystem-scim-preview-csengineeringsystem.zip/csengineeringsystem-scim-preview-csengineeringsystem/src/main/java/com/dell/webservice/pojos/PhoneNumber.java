package com.dell.webservice.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PhoneNumber {
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private String phoneNumber;

    private String phoneType;

    public PhoneNumber() {
    }

    public PhoneNumber(String phoneNumber, String phoneType) {
        this.phoneNumber = phoneNumber;
        this.phoneType = phoneType;
    }

    @JsonProperty("value")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("type")
    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    @Override
    public String toString() {
        return "PhoneNumber{" +
                "phoneNumber='" + phoneNumber + '\'' +
                ", phoneType='" + phoneType + '\'' +
                '}';
    }
}
