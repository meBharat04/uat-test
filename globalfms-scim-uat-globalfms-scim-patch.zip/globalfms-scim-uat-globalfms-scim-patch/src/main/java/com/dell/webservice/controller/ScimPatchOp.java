package com.dell.webservice.controller;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import tools.jackson.databind.JsonNode;

import java.util.List;

/**
 * Minimal model for a SCIM 2.0 PatchOp request body (RFC 7644 §3.5.2).
 * {@code value} is a {@link JsonNode} to handle any shape (array, string, object)
 * without deserialization errors — the path check runs first to reject
 * non-entitlement operations before the value is ever inspected.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScimPatchOp {

	private List<String> schemas;

	@JsonProperty("Operations")
	private List<PatchOperation> operations;

	public List<String> getSchemas() { return schemas; }
	public void setSchemas(List<String> schemas) { this.schemas = schemas; }

	public List<PatchOperation> getOperations() { return operations; }
	public void setOperations(List<PatchOperation> operations) { this.operations = operations; }

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class PatchOperation {
		private String op;
		private String path;
		private JsonNode value;

		public String getOp() { return op; }
		public void setOp(String op) { this.op = op; }
		public String getPath() { return path; }
		public void setPath(String path) { this.path = path; }
		public JsonNode getValue() { return value; }
		public void setValue(JsonNode value) { this.value = value; }
	}
}
