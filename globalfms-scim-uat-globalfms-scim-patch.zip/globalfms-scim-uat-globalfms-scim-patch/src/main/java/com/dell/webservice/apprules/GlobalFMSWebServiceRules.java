package com.dell.webservice.apprules;

import com.dell.webservice.exception.RateLimitException;
import com.dell.webservice.exception.UpstreamServiceException;
import com.dell.webservice.controller.ScimUserV2;
import com.dell.webservice.controller.ScimUserV2.Name;
import com.dell.webservice.pojos.GlobalFMSUtility;
import com.dell.webservice.controller.ScimUserV2.Email;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.net.http.HttpClient;
import java.time.Duration;

import java.net.URI;

import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;

public class GlobalFMSWebServiceRules {

	private static final Logger logger = LogManager.getLogger(GlobalFMSWebServiceRules.class);
	private String LoggerAppend = "Dell Webservice GlobalFMSWebServiceRules Class --- ";
	private final ObjectMapper objectMapper;
	private final HttpClient httpClient;
	private GlobalFMSUtility gfmsutility;

	public GlobalFMSWebServiceRules() {
		this(HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(60))
				.followRedirects(HttpClient.Redirect.NEVER).build());
	}

	/** Injectable HTTP client, so the upstream calls can be exercised without a network. */
	GlobalFMSWebServiceRules(HttpClient httpClient) {
		this.objectMapper = new ObjectMapper();
		this.httpClient = httpClient;
		this.gfmsutility = new GlobalFMSUtility();
	}

	public ScimUserV2 globalFMSCreateUserRule(ScimUserV2 user, String appName, String baseURL, String addUserRoleURL,
			String token) throws Exception {

		logger.info("{} globalFMSCreateUserRule() started for user={}", LoggerAppend, user.getUserName());

		gfmsutility.validateUrl(baseURL);
		gfmsutility.validateUrl(addUserRoleURL);
		validateInputs(user, appName, baseURL);

		HttpRequest request = null;
		HttpResponse<String> response = null;
		String objectId = null;
		String createUserBody = null;
		List<ScimUserV2.Entitlement> entitlements = null;
		StringBuilder entitlementBuilder = new StringBuilder();

		try {
			if (token == null || token.isBlank())
				throw new IllegalArgumentException(LoggerAppend
						+ "globalFMSCreateUserRule() Error occured while generating Access Token. Token is null or blank.");

			if (user.getEmails() == null || user.getEmails().getFirst() == null
					|| user.getEmails().getFirst().getEmailAddress() == null
					|| user.getEmails().getFirst().getEmailAddress().isBlank()) {
				throw new IllegalArgumentException(LoggerAppend + "User email address is required");
			}

			ObjectNode createUserJson = objectMapper.createObjectNode();
			createUserJson.put("createdBy", user.getUserName());
			createUserJson.put("email", user.getEmails().getFirst().getEmailAddress());
			createUserJson.putNull("region");
			createUserJson.put("userName", user.getUserName());
			createUserJson.put("isActive", true);

			createUserBody = objectMapper.writeValueAsString(createUserJson);
			logger.debug("{} globalFMSCreateUserRule() request body={}", LoggerAppend, createUserBody);

			request = HttpRequest.newBuilder().uri(URI.create(baseURL)).timeout(Duration.ofSeconds(60))
					.header("Content-Type", "application/json").header("Authorization", "Bearer " + token)
					.POST(HttpRequest.BodyPublishers.ofString(createUserBody)).build();
			response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

			logger.info("{} globalFMSCreateUserRule() response code={}", LoggerAppend, response.statusCode());

			if (response.statusCode() == 429) {
				String retryAfter = response.headers().firstValue("Retry-After").orElse("60");
				throw new RateLimitException(retryAfter);
			}
			if (response.statusCode() < 200 || response.statusCode() >= 300) {
				throw new UpstreamServiceException("Create user request failed: " + response.statusCode(), response.statusCode());
			}

			JsonNode jsonResponse = objectMapper.readTree(response.body());
			logger.debug("{} globalFMSCreateUserRule() response={}", LoggerAppend, jsonResponse.toPrettyString());

			// Process entitlements
			entitlements = user.getEntitlements() != null ? user.getEntitlements() : new ArrayList<>();

			entitlementBuilder = new StringBuilder();
			for (ScimUserV2.Entitlement ent : entitlements) {
				logger.debug("{} globalFMSCreateUserRule() entitlement value={}, type={}", LoggerAppend, ent.getValue(),
						ent.getType());

				if (!entitlementBuilder.isEmpty()) {
					entitlementBuilder.append(",");
				}
				entitlementBuilder.append("\"").append(sanitizeString(ent.getValue())).append("\"");
			}

			if (!entitlementBuilder.isEmpty()) {
				globalFMSAddUserRole(token, addUserRoleURL, user.getUserName(), entitlementBuilder.toString());
			}

			objectId = jsonResponse.has("userId") ? jsonResponse.get("userId").asText() : null;
			user.setId(objectId != null ? objectId : user.getUserName());
			if (user.getEnterpriseInfo() != null) {
				user.getEnterpriseInfo().setUserId(objectId);
			}

			if (user.getEnterpriseInfo() != null) {
				user.getEnterpriseInfo().setUserRoles(entitlementBuilder.toString().replace("\"", ""));
			}

			logger.info("{} globalFMSCreateUserRule() completed successfully, userId={}", LoggerAppend, objectId);

		} catch (Exception e) {
			logger.error("{} globalFMSCreateUserRule() error creating user {}: {}", LoggerAppend, user.getUserName(),
					e.getMessage(), e);
			throw e;
		} finally {
			logger.info("{} globalFMSCreateUserRule() ended for user={}", LoggerAppend, user.getUserName());
		}

		return user;
	}

	public void globalFMSAddUserRole(String accessToken, String addUserRoleURL, String userName,
			String entitlementArray) throws Exception {
		String _addUserRoleBody = null;
		HttpRequest request = null;
		HttpResponse<String> response = null;

		logger.info("{} ============ globalFMSAddUserRole() started ======== adding roles for user={}", LoggerAppend,
				userName);
		gfmsutility.validateUrl(addUserRoleURL);

		_addUserRoleBody = String.format("""
				 {
				    "UserName": "%s",
				    "RoleNames": [%s],
				    "ModifiedBy": "%s"
				}""", userName, entitlementArray, userName);

		logger.debug("{}globalFMSAddUserRoleRule() - add user role json object = {}", LoggerAppend, _addUserRoleBody);

		request = HttpRequest.newBuilder().uri(URI.create(addUserRoleURL)).timeout(Duration.ofSeconds(60))
				.header("Content-Type", "application/json").header("Authorization", "Bearer " + accessToken)
				.POST(HttpRequest.BodyPublishers.ofString(_addUserRoleBody)).build();

		response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

		logger.info("{}globalFMSAddUserRoleRule() add user role response code = {}", LoggerAppend,
				response.statusCode());

		logger.info("{} =========== globalFMSAddUserRole() ended ========= adding roles for user={}", LoggerAppend,
				userName);

		if (response.statusCode() == 429) {
			String retryAfter = response.headers().firstValue("Retry-After").orElse("60");
			throw new RateLimitException(retryAfter);
		}
		if (response.statusCode() < 200 || response.statusCode() >= 300) {
			logger.info(
					"{} =========== globalFMSAddUserRole() ended ========= unsuccessful in adding roles for user={}",
					LoggerAppend, userName);
			throw new UpstreamServiceException("Add user role request failed: " + response.statusCode(), response.statusCode());
		}
	}

	public void globalFMSRemoveUserRole(String accessToken, String removeUserRoleURL, String userName,
			String entitlementArray) throws Exception {

		String _removeUserRoleBody = null;
		HttpRequest request = null;
		HttpResponse<String> response = null;

		logger.info("{} ============ globalFMSRemoveUserRole() started ======== adding roles for user={}", LoggerAppend,
				userName);
		gfmsutility.validateUrl(removeUserRoleURL);

		_removeUserRoleBody = String.format("""
				 {
				    "UserName": "%s",
				    "RoleNames": [%s],
				    "ModifiedBy": "%s"
				}""", userName, entitlementArray, userName);

		logger.debug("{}globalFMSRemoveUserRole() - remove user role json object = {}", LoggerAppend,
				_removeUserRoleBody);

		request = HttpRequest.newBuilder().uri(URI.create(removeUserRoleURL)).timeout(Duration.ofSeconds(60))
				.header("Content-Type", "application/json").header("Authorization", "Bearer " + accessToken)
				.POST(HttpRequest.BodyPublishers.ofString(_removeUserRoleBody)).build();

		response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

		logger.info("{} globalFMSRemoveUserRole() response code={}", LoggerAppend, response.statusCode());

		logger.info("{} ============ globalFMSRemoveUserRole() ended ======== removing roles for user={}", LoggerAppend,
				userName);

		if (response.statusCode() == 429) {
			String retryAfter = response.headers().firstValue("Retry-After").orElse("60");
			throw new RateLimitException(retryAfter);
		}
		if (response.statusCode() < 200 || response.statusCode() >= 300) {
			logger.info(
					"{} ============ globalFMSRemoveUserRole() ended ======== unsuccessful in removing roles for user={}",
					LoggerAppend, userName);
			throw new UpstreamServiceException("Remove user role request failed: " + response.statusCode(), response.statusCode());
		}

	}

	public ScimUserV2 globalFMSUpdateUserRule(ScimUserV2 user, String id, String appName, String addUserRoleURL,
			String removeUserRoleURL, String existingUserRoles, String token) throws Exception {

		logger.info("{} ============ globalFMSUpdateUserRule() started ============ for user={}, id={}, isActive={}",
				LoggerAppend, user.getUserName(), id, user.getActive());

		List<ScimUserV2.Entitlement> _entitlements = null;
		StringBuilder _userRolesToAdd = new StringBuilder();
		StringBuilder _userRolesToRemove = new StringBuilder();

		validateInputs(user, appName, addUserRoleURL);
		gfmsutility.validateId(id);
		gfmsutility.validateUrl(addUserRoleURL);
		gfmsutility.validateUrl(removeUserRoleURL);

		if (token == null || token.isBlank())
			throw new IllegalArgumentException(LoggerAppend
					+ "globalFMSUpdateUserRule() Error occured while generating Access Token. Token is null or blank.");

		if (token != null) {
			List<String> _existingEntitlementsList = new ArrayList<String>();
			for (String existing : existingUserRoles.split(",")) {
				if (!existing.isBlank()) {
					_existingEntitlementsList.add(existing.trim());
				}
			}

			if (Boolean.FALSE.equals(user.getActive())) { // user deactivated (only an explicit active=false)
				logger.info("{} updateUser() Entitlements received from Okta on deactivation: count={}, values={}",
						LoggerAppend, user.getEntitlements() != null ? user.getEntitlements().size() : "null",
						user.getEntitlements() != null
								? user.getEntitlements().stream().map(e -> e.getValue() + "(" + e.getDisplay() + ")")
										.collect(java.util.stream.Collectors.joining(", "))
								: "null");

				if (user.getEntitlements() != null && !user.getEntitlements().isEmpty()) {
					_entitlements = user.getEntitlements();
					for (ScimUserV2.Entitlement entitlement : _entitlements) {
						if (_userRolesToRemove.isEmpty())
							_userRolesToRemove.append("\"").append(sanitizeString(entitlement.getValue())).append("\"");
						else
							_userRolesToRemove.append(",").append("\"").append(sanitizeString(entitlement.getValue())).append("\"");
					}
				} else {
					for (String element : _existingEntitlementsList) {
						if (_userRolesToRemove.isEmpty())
							_userRolesToRemove.append("\"").append(sanitizeString(element)).append("\"");
						else
							_userRolesToRemove.append(",").append("\"").append(sanitizeString(element)).append("\"");
					}
				}
				if (!_userRolesToRemove.isEmpty()) {
					globalFMSRemoveUserRole(token, removeUserRoleURL, user.getUserName(), _userRolesToRemove.toString());
				} else {
					logger.info("{} globalFMSUpdateUserRule() no roles to remove for deactivated user={}", LoggerAppend,
							user.getUserName());
				}

			} else { // user active
				_entitlements = user.getEntitlements() != null ? user.getEntitlements()
						: new ArrayList<ScimUserV2.Entitlement>();
				for (ScimUserV2.Entitlement ent : _entitlements) {
					logger.debug("{} globalFMSUpdateUserRule() - Entitlement value ={}, Entitlement Type ={}",
							LoggerAppend, ent.getValue(), ent.getType());
					if (_userRolesToAdd.isEmpty())
						_userRolesToAdd.append("\"").append(sanitizeString(ent.getValue())).append("\"");
					else
						_userRolesToAdd.append(",").append("\"").append(sanitizeString(ent.getValue())).append("\"");
				}

				for (String element : _existingEntitlementsList) {
					if (!_userRolesToAdd.toString().replaceAll("\"", "").contains(element)) {
						if (_userRolesToRemove.isEmpty())
							_userRolesToRemove.append("\"").append(element).append("\"");
						else
							_userRolesToRemove.append(",").append("\"").append(element).append("\"");
					}

				}

				if (!_userRolesToRemove.isEmpty()) {
					globalFMSRemoveUserRole(token, removeUserRoleURL, user.getUserName(), _userRolesToRemove.toString());
				}
				if (!_userRolesToAdd.isEmpty()) {
					globalFMSAddUserRole(token, addUserRoleURL, user.getUserName(), _userRolesToAdd.toString());
				}
			}

			if (user.getEnterpriseInfo() != null) {
				user.getEnterpriseInfo().setUserRoles(_userRolesToAdd.toString().replaceAll("\"", ""));
			}

		}
		logger.info("{} ============ globalFMSUpdateUserRule() ended ============ for user={}, id={}, isActive={}",
				LoggerAppend, user.getUserName(), id, user.getActive());

		return user;
	}

	public List<ScimUserV2> globalFMSListAllUsersRule(String filter, String appName, String baseURL, String token)
			throws Exception {
		logger.info("{} ============ globalFMSListAllUsersRule() started ============ for appName={}", LoggerAppend,
				appName);

		gfmsutility.validateUrl(baseURL);

		List<ScimUserV2> userList = null;
		JSONArray usersArray = null;

		try {
			if (token == null || token.isBlank())
				throw new IllegalArgumentException(LoggerAppend
						+ "globalFMSListAllUsersRule() Error occured while generating Access Token. Token is null or blank.");

			HttpRequest request = HttpRequest.newBuilder().uri(URI.create(baseURL)).timeout(Duration.ofSeconds(60))
					.header("Content-Type", "application/json").header("Authorization", "Bearer " + token).GET()
					.build();

			HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

			logger.info("{} globalFMSListAllUsersRule() response code={}", LoggerAppend, response.statusCode());

			if (response.statusCode() == 429) {
				String retryAfter = response.headers().firstValue("Retry-After").orElse("60");
				throw new RateLimitException(retryAfter);
			}
			if (response.statusCode() < 200 || response.statusCode() >= 300) {
				logger.error(LoggerAppend + "{} globalFMSListAllUsersRule() Error occured while fetching all users. "
						+ "Response is not successful.Response code = {}", LoggerAppend, response.statusCode());
				throw new UpstreamServiceException("List users request failed: " + response.statusCode(), response.statusCode());
			}

			userList = new ArrayList<ScimUserV2>();
			usersArray = new JSONArray(response.body());

			for (int i = 0; i < usersArray.length(); i++) {
				JSONObject _user = usersArray.getJSONObject(i);
				userList.add(getScimUserV2(_user));

			}
		} catch (Exception e) {
			logger.error("{} globalFMSListAllUsersRule() error listing users: {}", LoggerAppend, e.getMessage(), e);
			throw e;
		} finally {
			logger.info("{} ============ globalFMSListAllUsersRule() ended ============ for appName={}", LoggerAppend,
					appName);
		}
		return userList;
	}

	private static ScimUserV2 getScimUserV2(JSONObject jsonObject) throws Exception {
		StringBuilder _buildRoles = new StringBuilder();
		ScimUserV2 user = new ScimUserV2();
		user.setSchemas(Set.of("urn:ietf:params:scim:schemas:core:2.0:User",
				"urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"));

		ScimUserV2.ResourceMeta resourceMeta = new ScimUserV2.ResourceMeta("User");
		user.setMeta(resourceMeta);

		ScimUserV2.ScimEnterpriseUser scimEnterpriseInfo = new ScimUserV2.ScimEnterpriseUser();

		String userName = jsonObject.has("userName") && jsonObject.get("userName") != null
				? jsonObject.get("userName").toString()
				: "";
		String userId = jsonObject.has("userId") && jsonObject.get("userId") != null
				? jsonObject.get("userId").toString()
				: "";

		user.setActive(true);
		user.setId(!userId.isBlank() ? userId : userName);
		user.setUserName(userName);
		user.setExternalId(userName);
		user.setDisplayName(userName);
		user.setDetailedName(new Name(userName, userName));
		user.setEmails(List.of(new Email(
				jsonObject.has("email") && jsonObject.get("email") != null ? jsonObject.get("email").toString() : "",
				true)));

		scimEnterpriseInfo.setUserId(userId);
		scimEnterpriseInfo.setCreatedBy(jsonObject.has("createdBy") && jsonObject.get("createdBy") != null
				? jsonObject.get("createdBy").toString()
				: "");
		scimEnterpriseInfo.setModifiedBy(jsonObject.has("modifiedBy") && jsonObject.get("modifiedBy") != null
				? jsonObject.get("modifiedBy").toString()
				: "");
		scimEnterpriseInfo.setIsActive(
				jsonObject.has("isActive") && jsonObject.get("isActive") != null ? jsonObject.get("isActive").toString()
						: "");
		scimEnterpriseInfo.setRegion(
				jsonObject.has("region") && jsonObject.get("region") != null ? jsonObject.get("region").toString()
						: "");
		scimEnterpriseInfo.setManager(
				jsonObject.has("manager") && jsonObject.get("manager") != null ? jsonObject.get("manager").toString()
						: "");

		user.setEnterpriseInfo(scimEnterpriseInfo);

		if (jsonObject.has("userRoles") && jsonObject.get("userRoles") != null) {

			JSONArray _userRoles = jsonObject.getJSONArray("userRoles");

			List<ScimUserV2.Entitlement> entitlementsList = new ArrayList<ScimUserV2.Entitlement>();

			for (Object userRole : _userRoles) {
				ScimUserV2.Entitlement entitlement = new ScimUserV2.Entitlement();
				entitlement.setDisplay(userRole.toString());
				entitlement.setValue(userRole.toString());
				entitlement.setType("Entitlement");
				entitlement.setPrimary(true);

				entitlementsList.add(entitlement);

				if (_buildRoles.isEmpty())
					_buildRoles.append(userRole.toString());
				else
					_buildRoles.append(",").append(userRole.toString());
			}
			user.setEntitlements(entitlementsList);
			scimEnterpriseInfo.setUserRoles(_buildRoles.toString());

		}

		return user;
	}

	private String sanitizeString(String input) {
		if (input == null) {
			return "";
		}
		// Remove characters that could break JSON
		return input.replaceAll("[\"\\\\]", "");
	}

	private void validateInputs(ScimUserV2 user, String appName, String... urls) {
		if (user == null) {
			throw new IllegalArgumentException("User cannot be null");
		}
		if (user.getUserName() == null || user.getUserName().isBlank()) {
			throw new IllegalArgumentException("Username cannot be null or empty");
		}
		if (appName == null || appName.isBlank()) {
			throw new IllegalArgumentException("AppName cannot be null or empty");
		}
		/*
		 * for (String url : urls) { if (url == null || url.isBlank()) { throw new
		 * IllegalArgumentException("URL cannot be null or empty"); } }
		 */
	}

}