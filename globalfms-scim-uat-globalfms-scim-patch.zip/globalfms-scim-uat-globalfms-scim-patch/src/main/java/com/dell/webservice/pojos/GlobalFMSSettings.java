package com.dell.webservice.pojos;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Binds all {@code globalfms.*} configuration.
 *
 * <p>The base URL comes from the active Spring profile
 * ({@code application-dev.properties} or {@code application-prod.properties}).
 * Endpoint paths are shared across environments and committed in
 * {@code application.properties}. Full URLs are computed as
 * {@code baseUrl + path} so no full URL is hardcoded anywhere.
 */
@ConfigurationProperties(prefix = "globalfms")
@Configuration("globalfmssettings")
public class GlobalFMSSettings {

	// ---- Base URL (profile-specific) ----
	private String baseUrl;

	// ---- Relative endpoint paths (shared, committed) ----
	private String createUserPath;
	private String updateUserPath;
	private String entitlementsPath;
	private String listAllUsersPath;
	private String addUserRolePath;
	private String removeUserRolePath;

	// ---- Token URL (profile-specific — auth server differs per env) ----
	private String accessTokenURL;

	// ---- Shared non-URL settings ----
	private String totalUsers;
	private String credURL;
	private String allowedHosts;
	private String cachecttlValue;

	// ---- Outbound proxy (all optional) ----
	// If proxyHost is blank/absent, no proxy is used.
	// If proxyUsername/proxyPassword are blank/absent, the proxy is used without auth.
	private String proxyHost;
	private int proxyPort;
	private String proxyUsername;
	private String proxyPassword;

	// ---- baseUrl ----
	public String getBaseUrl() { return baseUrl; }
	public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }

	// ---- Path setters/getters ----
	public String getCreateUserPath() { return createUserPath; }
	public void setCreateUserPath(String createUserPath) { this.createUserPath = createUserPath; }

	public String getUpdateUserPath() { return updateUserPath; }
	public void setUpdateUserPath(String updateUserPath) { this.updateUserPath = updateUserPath; }

	public String getEntitlementsPath() { return entitlementsPath; }
	public void setEntitlementsPath(String entitlementsPath) { this.entitlementsPath = entitlementsPath; }

	public String getListAllUsersPath() { return listAllUsersPath; }
	public void setListAllUsersPath(String listAllUsersPath) { this.listAllUsersPath = listAllUsersPath; }

	public String getAddUserRolePath() { return addUserRolePath; }
	public void setAddUserRolePath(String addUserRolePath) { this.addUserRolePath = addUserRolePath; }

	public String getRemoveUserRolePath() { return removeUserRolePath; }
	public void setRemoveUserRolePath(String removeUserRolePath) { this.removeUserRolePath = removeUserRolePath; }

	// ---- Computed full URL getters (baseUrl + path) ----
	// These keep the existing API used by controllers and rules unchanged.

	public String getCreateUserURL() { return build(createUserPath); }
	public String getUpdateUserURL() { return build(updateUserPath); }
	public String getEntitlementsURL() { return build(entitlementsPath); }
	public String getListAllUsersURL() { return build(listAllUsersPath); }
	public String getAddUserRole() { return build(addUserRolePath); }
	public String getRemoveUserRole() { return build(removeUserRolePath); }

	// ---- Token URL (profile-specific, not baseUrl-relative) ----
	public String getAccessTokenURL() { return accessTokenURL; }
	public void setAccessTokenURL(String accessTokenURL) { this.accessTokenURL = accessTokenURL; }

	// ---- Other settings ----
	public String getTotalUsers() { return totalUsers; }
	public void setTotalUsers(String totalUsers) { this.totalUsers = totalUsers; }

	public String getCredURL() { return credURL; }
	public void setCredURL(String credURL) { this.credURL = credURL; }

	public String getAllowedHosts() { return allowedHosts; }
	public void setAllowedHosts(String allowedHosts) { this.allowedHosts = allowedHosts; }

	public String getCachecttlValue() { return cachecttlValue; }
	public void setCachecttlValue(String cachecttlValue) { this.cachecttlValue = cachecttlValue; }

	public String getProxyHost() { return proxyHost; }
	public void setProxyHost(String proxyHost) { this.proxyHost = proxyHost; }

	public int getProxyPort() { return proxyPort; }
	public void setProxyPort(int proxyPort) { this.proxyPort = proxyPort; }

	public String getProxyUsername() { return proxyUsername; }
	public void setProxyUsername(String proxyUsername) { this.proxyUsername = proxyUsername; }

	public String getProxyPassword() { return proxyPassword; }
	public void setProxyPassword(String proxyPassword) { this.proxyPassword = proxyPassword; }

	/**
	 * Combines baseUrl and a relative path, normalising the slash between them.
	 * Returns an empty string if either part is blank (caller's null-check handles it).
	 */
	private String build(String path) {
		if (baseUrl == null || baseUrl.isBlank() || path == null || path.isBlank()) {
			return "";
		}
		String base = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
		String p = path.startsWith("/") ? path : "/" + path;
		return base + p;
	}
}
