package com.dell.webservice.api;

import jakarta.annotation.PostConstruct;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AppInitializer {
    
	private static final Logger logger = LogManager.getLogger(AppInitializer.class);
	private static String LoggerAppend = "Dell Webservice Global FMS AppInitializer Class --- ";
	
    private String clientID;
    private String clientSecret;

    @Value("${globalfms.credURL}")
    private String credURL;

   
    @PostConstruct
    public void initializeApplicationAttributes() {
        try {
        	logger.info("{} initializeApplicationAttributes() method called",LoggerAppend);		
        } catch (Exception e) {
        	logger.error(LoggerAppend+"initializeApplicationAttributes() Initialization error Message = "+e.getMessage());
        }finally {
        }
    }

	public String getClientID() {
		return clientID;
	}

	public String getClientSecret() {
		return clientSecret;
	}

	public String getCredURL() {
		return credURL;
	}


}
