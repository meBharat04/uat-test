package com.dell.webservice.api;


  import java.net.Authenticator;
  import java.net.InetSocketAddress;
  import java.net.PasswordAuthentication;
  import java.net.ProxySelector;
  import java.net.URI;
  import java.net.http.HttpClient;
  import java.net.http.HttpRequest;
  import java.net.http.HttpResponse;

  import java.time.Duration;
  import java.time.LocalDateTime;

  import java.util.HashMap;
  import java.util.Map;

  import org.apache.logging.log4j.LogManager;
  import org.apache.logging.log4j.Logger;
  import org.springframework.stereotype.Component;

  import com.dell.webservice.exception.RateLimitException;
  import com.dell.webservice.exception.UnauthorizedException;
  import com.dell.webservice.exception.UpstreamServiceException;
  import com.dell.webservice.pojos.GlobalFMSSettings;
  import com.dell.webservice.pojos.GlobalFMSUtility;
  import tools.jackson.databind.ObjectMapper;

  @Component
  public class BuildConnection {

      private final Logger logger = LogManager.getLogger(BuildConnection.class);
      private final String loggerAppend = "Dell Webservice Global FMS BuildConnection Class --- ";
      private final Object lock = new Object();

      private volatile String globalAccessToken;
      private volatile LocalDateTime tokenExpiry;

      private final ObjectMapper objectMapper;
      private final HttpClient httpClient;
      private GlobalFMSUtility isUrlValid = new GlobalFMSUtility();

      public BuildConnection(GlobalFMSSettings settings) {
          this.objectMapper = new ObjectMapper();
          this.httpClient = buildHttpClient(settings);
      }

      /**
       * Builds the shared HttpClient with optional proxy support.
       * Proxy is only applied when proxyHost and proxyPort are configured.
       * Proxy authentication is only applied when both username and password are set.
       * If proxy settings are absent the client connects directly.
       */
      private HttpClient buildHttpClient(GlobalFMSSettings settings) {
          HttpClient.Builder builder = HttpClient.newBuilder()
                  .connectTimeout(Duration.ofSeconds(60))
                  .followRedirects(HttpClient.Redirect.NEVER);

          configureProxy(builder, settings);
          return builder.build();
      }

      private void configureProxy(HttpClient.Builder builder, GlobalFMSSettings settings) {
          String proxyHost = settings != null ? settings.getProxyHost() : null;
          int proxyPort = settings != null ? settings.getProxyPort() : 0;

          if (proxyHost == null || proxyHost.isBlank() || proxyPort <= 0) {
              logger.debug("{} No outbound proxy configured; using direct connection", loggerAppend);
              return;
          }

          builder.proxy(ProxySelector.of(new InetSocketAddress(proxyHost, proxyPort)));
          logger.info("{} Outbound proxy enabled: {}:{}", loggerAppend, proxyHost, proxyPort);

          String proxyUser = settings.getProxyUsername();
          String proxyPass = settings.getProxyPassword();
          if (proxyUser == null || proxyUser.isBlank() || proxyPass == null || proxyPass.isBlank()) {
              logger.debug("{} Proxy configured without authentication", loggerAppend);
              return;
          }

          // Basic auth over HTTPS CONNECT tunnels is disabled in the JDK by default.
          System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
          builder.authenticator(new Authenticator() {
              @Override
              protected PasswordAuthentication getPasswordAuthentication() {
                  if (getRequestorType() == RequestorType.PROXY) {
                      return new PasswordAuthentication(proxyUser, proxyPass.toCharArray());
                  }
                  return null;
              }
          });
          logger.info("{} Proxy authentication enabled (user: {})", loggerAppend, proxyUser);
      }

      public String getAccessToken(String tokenURL, String credentials) throws Exception {
    	
          synchronized (lock) {
              if (tokenExpiry == null || LocalDateTime.now().isAfter(tokenExpiry)) {
                  refreshToken(tokenURL, credentials);
              }
              return globalAccessToken;
          }
      }

      @SuppressWarnings("unchecked")
      private void refreshToken(String accessTokenURL, String credentials) throws Exception {
          // SSRF validation
    	  isUrlValid.validateUrl(accessTokenURL);
    	  logger.info("{} ========= refreshToken() start =========",loggerAppend);
          try {
              // Build Basic Auth header
            //  String credentials = Base64.getEncoder()
                   //   .encodeToString((clientID + ":" + clientSecret).getBytes(StandardCharsets.UTF_8));

              // Build JSON body safely
              String jsonBody = objectMapper.writeValueAsString(Map.of("grant_type", "client_credentials"));

              HttpRequest request = HttpRequest.newBuilder()
                      .uri(URI.create(accessTokenURL))
                      .timeout(Duration.ofSeconds(60))
                      .header("Content-Type", "application/json")
                      .header("Accept", "application/json")
                      .header("Authorization", credentials)
                      .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                      .build();

              HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

              logger.info("{} Token response code: {}", loggerAppend, response.statusCode());

              if (response.statusCode() == 429) {
                  throw new RateLimitException(response.headers().firstValue("Retry-After").orElse("60"));
              }
              if (response.statusCode() == 401) {
                  throw new UnauthorizedException("Token endpoint rejected the client credentials");
              }
              if (response.statusCode() < 200 || response.statusCode() >= 300) {
                  throw new UpstreamServiceException("Token request failed: " + response.statusCode(),
                          response.statusCode());
              }

              Map<String, Object> responseMap = objectMapper.readValue(response.body(), HashMap.class);

              String newAccessToken = (String) responseMap.get("access_token");
              if (newAccessToken == null || newAccessToken.isBlank()) {
                  throw new UpstreamServiceException("No valid access_token in token response");
              }
              globalAccessToken = newAccessToken;
              Integer expiresIn = (Integer) responseMap.get("expires_in");

              // Refresh 5 minutes before expiry, default to 55 min if not provided
              int bufferSeconds = (expiresIn != null ? expiresIn : 3600) - 300;
              tokenExpiry = LocalDateTime.now().plusSeconds(bufferSeconds);

              logger.info("{} Token refreshed, expires at: {}", loggerAppend, tokenExpiry);

          } catch (RateLimitException | UnauthorizedException | UpstreamServiceException e) {
              throw e;
          } catch (Exception e) {
              logger.error("{} Error generating token: {}", loggerAppend, e.getMessage());
              throw new UpstreamServiceException("Error generating token", e);
          }
      }
  }
