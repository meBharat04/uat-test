package com.dell.webservice.controller;

  import com.dell.webservice.api.AppInitializer;
  import com.dell.webservice.api.BuildConnection;
  import com.dell.webservice.exception.RateLimitException;
  import com.dell.webservice.exception.UnauthorizedException;
  import com.dell.webservice.exception.UpstreamServiceException;
  import com.dell.webservice.pojos.GlobalFMSSettings;
  import com.dell.webservice.pojos.GlobalFMSUtility;

  import tools.jackson.databind.ObjectMapper;
  import tools.jackson.databind.node.ArrayNode;
  import tools.jackson.databind.node.ObjectNode;

  import org.apache.logging.log4j.LogManager;
  import org.apache.logging.log4j.Logger;
  import org.springframework.beans.factory.annotation.Autowired;
  import org.springframework.web.bind.annotation.GetMapping;
  import org.springframework.web.bind.annotation.PathVariable;
  import org.springframework.web.bind.annotation.RequestHeader;
  import org.springframework.web.bind.annotation.RequestMapping;
  import org.springframework.web.bind.annotation.RequestParam;
  import org.springframework.web.bind.annotation.RestController;
  import org.springframework.http.MediaType;

  import java.net.URI;
  import java.net.http.HttpClient;
  import java.net.http.HttpRequest;
  import java.net.http.HttpResponse;
  import java.time.Duration;

  import org.json.JSONArray;
  import org.json.JSONObject;

  @RestController
  @RequestMapping({"/{appName}/scim/v2/Entitlements"})
  public class EntitlementsController {

      private static final Logger logger = LogManager.getLogger(EntitlementsController.class);
      private static final String LOGGER_APPEND = "Dell Webservice Global FMS EntitlementsController Class --- ";

      private static final HttpClient httpClient = HttpClient.newBuilder()
              .connectTimeout(Duration.ofMinutes(1))
              .build();

      private final ObjectMapper objectMapper = new ObjectMapper();

      @Autowired
      private GlobalFMSSettings globalfmssettings;

      @SuppressWarnings("unused")
	  private final AppInitializer appInitializer;
      
      private final BuildConnection buildConnection;
      private final GlobalFMSUtility gfmsutility;

      public EntitlementsController(BuildConnection buildConnection, AppInitializer appInitializer) {
          this.appInitializer = appInitializer;
          this.buildConnection = buildConnection;
          this.gfmsutility = new GlobalFMSUtility();
      }

      @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
      public String listAllEntitlements(
              @RequestParam(required = false) String filter,
              @RequestParam(required = false) Integer count,
              @RequestParam(required = false) Integer startIndex,
              @PathVariable String appName,
              @RequestHeader(value = "Authorization", required = false) String customHeader) throws Exception{

          logger.info("{}listAllEntitlements() filter = {}", LOGGER_APPEND, filter);
          
          String accessToken = null;

          String baseURL = globalfmssettings != null ? globalfmssettings.getEntitlementsURL() : "";
          String tokenURL = globalfmssettings != null ? globalfmssettings.getAccessTokenURL() : "";

          gfmsutility.validateUrl(baseURL);
          gfmsutility.validateUrl(tokenURL);

          if (filter != null) {
              throw new IllegalArgumentException(LOGGER_APPEND + "List all Entitlements with filter is not implemented");
          }

         
          try {
              accessToken = buildConnection.getAccessToken(tokenURL, customHeader);
          } catch (RateLimitException | UnauthorizedException | UpstreamServiceException | IllegalArgumentException e) {
              throw e;
          } catch (Exception e) {
              logger.error("{}Error generating access token", LOGGER_APPEND, e);
              throw new UpstreamServiceException("Error generating access token", e);
          }

          if (accessToken == null) {
              throw new UpstreamServiceException("Access token to invoke API Endpoint is null.");
          }

          try {
              HttpRequest request = HttpRequest.newBuilder()
                      .uri(URI.create(baseURL))
                      .timeout(Duration.ofMinutes(1))
                      .header("Content-Type", "application/json")
                      .header("Authorization", "Bearer " + accessToken)
                      .GET()
                      .build();

              HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
              String responseBody = response.body();

              if (response.statusCode() == 429) {
                  throw new RateLimitException(response.headers().firstValue("Retry-After").orElse("60"));
              }

              if (response.statusCode() >= 200 && response.statusCode() < 300) {
                  logger.info("{}Entitlements fetched successfully. Status = {}", LOGGER_APPEND, response.statusCode());

                  JSONArray dataArray = new JSONArray(responseBody);
                  ArrayNode resourcesArray = objectMapper.createArrayNode();

                  for (int i = 0; i < dataArray.length(); i++) {
                      resourcesArray.add(convertGroupToScimGroup(dataArray.getJSONObject(i)));
                  }

                  ObjectNode result = objectMapper.createObjectNode();
                  result.putArray("schemas").add("urn:ietf:params:scim:api:messages:2.0:ListResponse");
                  result.put("totalResults", dataArray.length());
                  result.put("itemsPerPage", dataArray.length());
                  result.put("startIndex", 1);
                  result.set("Resources", resourcesArray);

                  String entitlementsFinalList = objectMapper.writeValueAsString(result);
                  logger.debug("{}Final Entitlements list: {}", LOGGER_APPEND, entitlementsFinalList);

                  return entitlementsFinalList;

              } else {
                  logger.error("{}Entitlements fetch failed. Status = {}, Body = {}", LOGGER_APPEND, response.statusCode(), responseBody);
                  throw new UpstreamServiceException("Failed to fetch entitlements. Status: " + response.statusCode(), response.statusCode());
              }

          } catch (InterruptedException e) {
              Thread.currentThread().interrupt();
              throw new UpstreamServiceException("Request interrupted", e);
          } catch (RateLimitException | UnauthorizedException | UpstreamServiceException e) {
              throw e;
          } catch (Exception e) {
              logger.error("{}Error fetching entitlements", LOGGER_APPEND, e);
              throw new UpstreamServiceException("Error fetching entitlements", e);
          }
      }

      private ObjectNode convertGroupToScimGroup(JSONObject jsonObj) {
          ObjectNode node = objectMapper.createObjectNode();
          node.putArray("schemas").add("urn:okta:scim:schemas:core:1.0:Entitlement");
          node.put("id", jsonObj.getString("roleName"));
          node.put("displayName", jsonObj.getString("roleName"));
          node.put("description", jsonObj.getString("description"));
          node.put("type", "Entitlement");
          return node;
      }
  }
