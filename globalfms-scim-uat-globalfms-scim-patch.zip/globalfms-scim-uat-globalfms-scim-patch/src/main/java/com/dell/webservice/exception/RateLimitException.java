package com.dell.webservice.exception;

public class RateLimitException extends RuntimeException {

    private static final long serialVersionUID = 1L;
	private final String retryAfter;

    public RateLimitException(String retryAfter) {
        super("Rate limit exceeded. Retry-After: " + retryAfter);
        this.retryAfter = retryAfter;
    }

    public String getRetryAfter() {
        return retryAfter;
    }
}
