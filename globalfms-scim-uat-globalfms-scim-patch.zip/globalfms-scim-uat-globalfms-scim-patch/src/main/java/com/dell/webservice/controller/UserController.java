package com.dell.webservice.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;

import com.dell.webservice.api.AppInitializer;
import com.dell.webservice.api.BuildConnection;
import com.dell.webservice.apprules.GlobalFMSWebServiceRules;
import com.dell.webservice.cache.UserCacheService;
import com.dell.webservice.exception.RateLimitException;
import com.dell.webservice.exception.UnauthorizedException;
import com.dell.webservice.exception.UpstreamServiceException;
import com.dell.webservice.cache.UserCacheService.PaginatedResult;
import com.dell.webservice.pojos.GlobalFMSSettings;
import com.dell.webservice.pojos.GlobalFMSUtility;
import com.dell.webservice.pojos.ValidationPatterns;


@RestController
@RequestMapping("/{appName}/scim/v2")
public class UserController {

	@Autowired
	private GlobalFMSSettings globalfmssettings;

	@Autowired
	private UserCacheService userCacheService;

	private static final Logger logger = LogManager.getLogger(UserController.class);
	private static final String LoggerAppend = "Dell Webservice Global FMS UserController Class --- ";


    @SuppressWarnings("unused")
	private final AppInitializer appInitializer;

    private final BuildConnection buildConnection;
    private GlobalFMSUtility gfmsutility;


    public UserController(BuildConnection buildConnection, AppInitializer appInitializer, UserCacheService userCacheService) {
        this.buildConnection = buildConnection;
        this.appInitializer = appInitializer;
        this.userCacheService = userCacheService;
        this.gfmsutility = new GlobalFMSUtility();
    }
	
	@GetMapping(value = "/Users/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
	public ScimUserV2 getUserById(@PathVariable String id, @PathVariable String appName, 
			@RequestHeader(value = "Authorization", required = false) String customHeader) {
		logger.info("{} ========= getUserById() start ========= ",LoggerAppend);
		
		gfmsutility.validateAppName(appName);
        gfmsutility.validateId(id);
        gfmsutility.validateAuthHeader(customHeader);
        id = sanitizePathSegment(id);

        logger.info("{} getUserById() id={}, appName={}", LoggerAppend, id, appName);

		ScimUserV2 _user = new ScimUserV2();
		_user.setId(id);
		
		logger.info("{} ========= getUserById() end =========}",LoggerAppend);
		
		return _user;
	}

	@PutMapping(value = "/Users/{id}", produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
	public ResponseEntity<ScimUserV2> updateUser (@RequestBody ScimUserV2 user, @PathVariable String id, @PathVariable String appName,
			@RequestHeader(value = "Authorization", required = false) String customHeader) {
		logger.info("{} ========= updateUser() start =========}",LoggerAppend);
		 
		 gfmsutility.validateAuthHeader(customHeader);
	     gfmsutility.validateAppName(appName);
         gfmsutility.validateId(id);
         gfmsutility.validateUser(user);
         id = sanitizePathSegment(id);
      
         
         logger.info("{} updateUser() userName={}, id={}, appName={}",
        		 LoggerAppend, user.getUserName(), id, appName);
		
        GlobalFMSWebServiceRules _webservRules = null;
		String _addUserRoleURL = null;
		String _removeUserRoleURL = null;
		String _existingUserRoles = "";
		String _tokenURL = null;
	
		
		try {
			_webservRules = new GlobalFMSWebServiceRules();
			_addUserRoleURL = getSettingOrEmpty(globalfmssettings::getAddUserRole);
			_removeUserRoleURL = getSettingOrEmpty(globalfmssettings::getRemoveUserRole);
			_tokenURL = getSettingOrEmpty(globalfmssettings::getAccessTokenURL);
			
			   gfmsutility.validateUrl(_addUserRoleURL);
			   gfmsutility.validateUrl(_removeUserRoleURL);
			   gfmsutility.validateUrl(_tokenURL);
			
			   if (user.getEnterpriseInfo() != null && user.getEnterpriseInfo().getUserRoles() != null) {
	                  _existingUserRoles = user.getEnterpriseInfo().getUserRoles();
	              }
			   
			 String token = buildConnection.getAccessToken(_tokenURL, customHeader);  
			//String[] creds = GlobalFMSUtility.extractCredentials(customHeader);
			user = _webservRules.globalFMSUpdateUserRule(user, id, appName, _addUserRoleURL,_removeUserRoleURL,_existingUserRoles, token);
		
		}catch (IllegalArgumentException | UpstreamServiceException | RateLimitException | UnauthorizedException e) {
			logger.error("{} updateUser() Error updating user {} in {}: {}",
					LoggerAppend, user.getUserName(), appName, e.getMessage());
			throw e;
		}catch(Exception e){
			logger.error("{} updateUser() Error updating user {} in {}: {}",
					LoggerAppend, user.getUserName(), appName, e.getMessage(), e);
			throw new UpstreamServiceException("Error updating user", e);
		}finally {
			_webservRules = null;
		}
		
		logger.info("{} ========= updateUser() end =========}",LoggerAppend);
		return ResponseEntity.ok(user);
	}
	
	@PostMapping(value = "/Users", produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
	public ResponseEntity<ScimUserV2> createUser(@RequestBody ScimUserV2 user, @PathVariable String appName,
			@RequestHeader(value = "Authorization", required = false) String customHeader) {
		
		logger.info("{} ========= createUser() start =========}",LoggerAppend);
		 gfmsutility.validateAuthHeader(customHeader);
	     gfmsutility.validateAppName(appName);
         gfmsutility.validateUser(user);
         
        logger.info("{} createUser() userName={}, appName={}", LoggerAppend, user.getUserName(), appName);
		
		GlobalFMSWebServiceRules _webservRules = null;
		String _baseURL = null;
		String _addUserRoleURL = null;
		String _tokenURL = null;
	
		try {
			
			    _webservRules = new GlobalFMSWebServiceRules();
			
		        _baseURL = getSettingOrEmpty(globalfmssettings::getCreateUserURL);
	            _addUserRoleURL = getSettingOrEmpty(globalfmssettings::getAddUserRole);
	            _tokenURL = getSettingOrEmpty(globalfmssettings::getAccessTokenURL);
	            
	     	   gfmsutility.validateUrl(_addUserRoleURL);
			   gfmsutility.validateUrl(_baseURL);
			   gfmsutility.validateUrl(_tokenURL);
	        
	       // String[] creds = GlobalFMSUtility.extractCredentials(customHeader);
	        String token = buildConnection.getAccessToken(_tokenURL, customHeader);  
			user =_webservRules.globalFMSCreateUserRule(user, appName, _baseURL, _addUserRoleURL, token); 
			
			logger.info("{} createUser() userId={}", LoggerAppend, user.getId());
			
			user.setSchemas(Set.of("urn:ietf:params:scim:schemas:core:2.0:User",
			        "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"));
			 
			return ResponseEntity.status(HttpStatus.CREATED).body(user);
			
		}catch (IllegalArgumentException | UpstreamServiceException | RateLimitException | UnauthorizedException e) {
			logger.error("{} createUser() Error creating user {} in {}: {}",
					LoggerAppend, user.getUserName(), appName, e.getMessage());
			throw e;
		}catch(Exception e) {
			logger.error("{} createUser() Error creating user {} in {}: {}",
					LoggerAppend, user.getUserName(), appName, e.getMessage(), e);
			throw new UpstreamServiceException("Error creating user", e);
		}finally {
			 logger.info("{} ========= createUser() end =========}",LoggerAppend);
			 _webservRules = null;
		}
	}

	@GetMapping(value = "/Users", produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
	public ResponseEntity<ScimResourceList<ScimUserV2>> listAllUsers(@RequestParam(required = false) String filter,
								 @RequestParam(required = false) Integer count,
								 @RequestParam(required = false) Integer startIndex, @PathVariable String appName,
								 @RequestHeader(value = "Authorization", required = false) String customHeader) {

		logger.info("{} ========= listAllUsers() start =========", LoggerAppend);
		gfmsutility.validateAppName(appName);
		gfmsutility.validateAuthHeader(customHeader);

		logger.info("{} listAllUsers() appName={}, filter={}, count={}, startIndex={}",
				LoggerAppend, appName, filter, count, startIndex);

		ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
		resourceList.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));

		try {
			// Check if filter is for getUserByName
			if (filter != null && filter.contains("userName eq")) {
				String username = parseUsernameFromFilter(filter);
				logger.info("{} listAllUsers() looking up user by username: {}", LoggerAppend, username);

				ScimUserV2 user = userCacheService.getUserByUserName(customHeader, username);
				if (user != null) {
					resourceList.setResources(List.of(user));
					resourceList.setTotalResults(1);
					resourceList.setItemsPerPage(1);
					resourceList.setStartIndex(1);
				} else {
					resourceList.setResources(List.of());
					resourceList.setTotalResults(0);
					resourceList.setItemsPerPage(0);
					resourceList.setStartIndex(1);
				}
			} else {
				// Full import or incremental import with pagination
				PaginatedResult<ScimUserV2> result = userCacheService.getUsers(customHeader, startIndex, count, filter);

				resourceList.setResources(result.getItems());
				resourceList.setTotalResults(result.getTotalResults());
				resourceList.setItemsPerPage(result.getItemsPerPage());
				resourceList.setStartIndex(result.getStartIndex());
			}

			logger.info("{} listAllUsers() returning {} users, totalResults={}",
					LoggerAppend, resourceList.getResources().size(), resourceList.getTotalResults());

			return ResponseEntity.ok(resourceList);

		} catch (IllegalArgumentException | UpstreamServiceException | RateLimitException | UnauthorizedException e) {
			logger.error("{} listAllUsers() Error listing users for {}: {}",
					LoggerAppend, appName, e.getMessage());
			throw e;
		} catch (Exception e) {
			logger.error("{} listAllUsers() Error listing users for {}: {}",
					LoggerAppend, appName, e.getMessage(), e);
			throw new UpstreamServiceException("Error fetching users", e);

		} finally {
			logger.info("{} ========= listAllUsers() end =========", LoggerAppend);
		}
	}

	private static final String PATCH_OP_SCHEMA = "urn:ietf:params:scim:api:messages:2.0:PatchOp";
	private static final java.util.regex.Pattern REMOVE_VALUE_PATTERN = ValidationPatterns.PATCH_VALUE_PATTERN;
	@SuppressWarnings("unused")
	private static final java.util.regex.Pattern REMOVE_TYPE_PATTERN = ValidationPatterns.PATCH_TYPE_PATTERN;
	private final ObjectMapper patchMapper = new ObjectMapper();

	/**
	 * SCIM PATCH /Users/{id} — handles entitlement add/remove only.
	 * Profile attribute updates via PATCH are not supported and return 501.
	 *
	 * <p>Global FMS add/remove API expects an array of role names in a single call,
	 * so all add-ops are batched into one request and all remove-ops into one request.
	 * Returns 204 on success.
	 */
	@PatchMapping(value = "/Users/{id}",
			consumes = {"application/scim+json", MediaType.APPLICATION_JSON_VALUE},
			produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
	public ResponseEntity<Void> patchUser(@PathVariable String id,
			@RequestBody String patchOpBody,
			@PathVariable String appName,
			@RequestHeader(value = "Authorization", required = false) String customHeader) {

		logger.info("{} ========= patchUser() start =========", LoggerAppend);
		gfmsutility.validateAuthHeader(customHeader);
		gfmsutility.validateAppName(appName);
		gfmsutility.validateId(id);
		id = sanitizePathSegment(id);

		try {
			ScimPatchOp patchOp = patchMapper.readValue(patchOpBody, ScimPatchOp.class);

			if (patchOp.getSchemas() == null || !patchOp.getSchemas().contains(PATCH_OP_SCHEMA)) {
				throw new IllegalArgumentException("Invalid PATCH schema. Expected: " + PATCH_OP_SCHEMA);
			}
			if (patchOp.getOperations() == null || patchOp.getOperations().isEmpty()) {
				throw new IllegalArgumentException("PATCH request must contain at least one operation");
			}

			// Validate all operations target entitlements only — return 501 for anything else.
			for (ScimPatchOp.PatchOperation op : patchOp.getOperations()) {
				String path = op.getPath() != null ? op.getPath().toLowerCase() : "";
				if (!path.startsWith("entitlements")) {
					logger.warn("{} patchUser() PATCH on non-entitlement path '{}' not supported — 501",
							LoggerAppend, op.getPath());
					return ResponseEntity.status(501).build();
				}
			}

			String tokenURL = getSettingOrEmpty(globalfmssettings::getAccessTokenURL);
			String addUserRoleURL = getSettingOrEmpty(globalfmssettings::getAddUserRole);
			String removeUserRoleURL = getSettingOrEmpty(globalfmssettings::getRemoveUserRole);

			gfmsutility.validateUrl(tokenURL);
			gfmsutility.validateUrl(addUserRoleURL);
			gfmsutility.validateUrl(removeUserRoleURL);

			String token = buildConnection.getAccessToken(tokenURL, customHeader);

			// id is the numeric userId — resolve to userName via cache lookup.
			ScimUserV2 cachedUser = userCacheService.getUserByUserId(customHeader, id);
			if (cachedUser == null) {
				logger.warn("{} patchUser() userId={} not found", LoggerAppend, id);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
			}
			String userName = cachedUser.getUserName();
			logger.info("{} patchUser() resolved userId={} to userName={}", LoggerAppend, id, userName);

			patchUserEntitlements(userName, patchOp, addUserRoleURL, removeUserRoleURL, token);

			logger.info("{} patchUser() Completed for user: {}", LoggerAppend, id);
			return ResponseEntity.noContent().build(); // 204

		} catch (IllegalArgumentException | UpstreamServiceException | RateLimitException | UnauthorizedException e) {
			logger.error("{} patchUser() Error patching user {}: {}", LoggerAppend, id, e.getMessage());
			throw e;
		} catch (Exception e) {
			logger.error("{} patchUser() Error patching user {}: {}", LoggerAppend, id, e.getMessage(), e);
			throw new UpstreamServiceException("Error patching user", e);
		} finally {
			logger.info("{} ========= patchUser() end =========", LoggerAppend);
		}
	}

	/**
	 * Processes PATCH operations against entitlements.
	 *
	 * <p>All {@code op:add} role names are collected into a single batch and sent
	 * to the Global FMS AddUserRole endpoint in one call. All {@code op:remove}
	 * role names are similarly batched into one RemoveUserRole call. This matches
	 * the Global FMS API which accepts an array of role names per request.
	 */
	private void patchUserEntitlements(String userName, ScimPatchOp patchOp,
			String addUrl, String removeUrl, String token) throws Exception {

		List<String> rolesToAdd = new ArrayList<>();
		List<String> rolesToRemove = new ArrayList<>();

		for (ScimPatchOp.PatchOperation op : patchOp.getOperations()) {
			if ("add".equalsIgnoreCase(op.getOp())) {
				JsonNode valueNode = op.getValue();
				if (valueNode == null || !valueNode.isArray() || valueNode.isEmpty()) {
					logger.warn("{} patchUserEntitlements() PATCH add has no values — skipping", LoggerAppend);
					continue;
				}
				for (JsonNode ent : valueNode) {
					String role = ent.hasNonNull("value") ? ent.get("value").asText() : null;
					if (role != null && !role.isBlank()) {
						rolesToAdd.add("\"" + role + "\"");
					}
				}
			} else if ("remove".equalsIgnoreCase(op.getOp())) {
				String role = extractFromPath(op.getPath(), REMOVE_VALUE_PATTERN);
				if (role == null || role.isBlank()) {
					logger.warn("{} patchUserEntitlements() PATCH remove: could not extract role from path '{}' — skipping",
							LoggerAppend, op.getPath());
					continue;
				}
				rolesToRemove.add("\"" + role + "\"");
			} else {
				logger.warn("{} patchUserEntitlements() Unsupported PATCH op '{}' — skipping",
						LoggerAppend, op.getOp());
			}
		}

		// Batch all adds into a single API call.
		if (!rolesToAdd.isEmpty()) {
			String addArray = String.join(",", rolesToAdd);
			logger.info("{} patchUserEntitlements() Adding roles to user {}: [{}]",
					LoggerAppend, userName, addArray);
			GlobalFMSWebServiceRules rules = new GlobalFMSWebServiceRules();
			rules.globalFMSAddUserRole(token, addUrl, userName, addArray);
		}

		// Batch all removes into a single API call.
		if (!rolesToRemove.isEmpty()) {
			String removeArray = String.join(",", rolesToRemove);
			logger.info("{} patchUserEntitlements() Removing roles from user {}: [{}]",
					LoggerAppend, userName, removeArray);
			GlobalFMSWebServiceRules rules = new GlobalFMSWebServiceRules();
			rules.globalFMSRemoveUserRole(token, removeUrl, userName, removeArray);
		}
	}

	/** Extracts the first captured group from the SCIM remove path using the given pattern. */
	private static String extractFromPath(String path, java.util.regex.Pattern pattern) {
		if (path == null || path.isBlank()) return null;
		java.util.regex.Matcher m = pattern.matcher(path);
		return m.find() ? m.group(1) : null;
	}

     private String parseUsernameFromFilter(String filter) {
         if (filter == null || filter.isBlank()) {
             return "";
         }
         // Sanitize: only allow expected filter format for userName
         if (!ValidationPatterns.FILTER_USERNAME_PATTERN.matcher(filter).matches()) {
             throw new IllegalArgumentException("Invalid filter format");
         }
         return filter.replaceAll("^userName\\s+eq\\s+\"", "").replace("\"", "");
     }
     private String getSettingOrEmpty(java.util.function.Supplier<String> supplier) {
         if (globalfmssettings == null) {
             return "";
         }
         String value = supplier.get();
         return value != null ? value : "";
     }
/**
 	 * URL-encodes a user-supplied path segment to break SSRF taint flow.
 	 * Called before passing id values into rules methods that construct URLs.
 	 */
 	private static String sanitizePathSegment(String value) {
 		if (value == null) return "";
 		return URLEncoder.encode(value, StandardCharsets.UTF_8);
 	}
}