package com.dell.webservice.exception;

/**
 * Thrown when a call to the upstream Global FMS (or its token endpoint) fails: a
 * non-2xx response, a network error, or a malformed response. Mapped to HTTP 502
 * by {@link GlobalExceptionHandler} so server-side failures are not reported to
 * the SCIM client as client (4xx) errors.
 */
public class UpstreamServiceException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final int status;

    public UpstreamServiceException(String message) {
        super(message);
        this.status = -1;
    }

    public UpstreamServiceException(String message, Throwable cause) {
        super(message, cause);
        this.status = -1;
    }

    public UpstreamServiceException(String message, int status) {
        super(message);
        this.status = status;
    }

    /** Upstream HTTP status code, or -1 if not applicable/unknown. */
    public int getStatus() {
        return status;
    }
}
