package com.dell.webservice.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ScimUserV2 {

	private String id;

	private String userName;

	private String externalId;

	private Name detailedName;

	private ResourceMeta meta;

	private Set<String> schemas;

	@JsonProperty("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User")
	private ScimEnterpriseUser enterpriseInfo;

	private String displayName;

	private Boolean active;

	private String password;

	private List<Email> emails;

	private List<PhoneNumber> phoneNumbers;

	private List<Role> roles;

	private List<Entitlement> entitlements;
	

	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getExternalId() {
		return externalId;
	}

	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	@JsonProperty("name")
	public Name getDetailedName() {
		return detailedName;
	}

	public void setDetailedName(Name detailedName) {
		this.detailedName = detailedName;
	}

	
	public ScimEnterpriseUser getEnterpriseInfo() {
		return enterpriseInfo;
	}

	public void setEnterpriseInfo(ScimEnterpriseUser enterpriseInfo) {
		this.enterpriseInfo = enterpriseInfo;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Email> getEmails() {
		return emails;
	}

	public void setEmails(List<Email> emails) {
		this.emails = emails;
	}

	public List<PhoneNumber> getPhoneNumbers() {
		return phoneNumbers;
	}

	public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}

	public List<Entitlement> getEntitlements() {
		return entitlements;
	}

	public void setEntitlements(List<Entitlement> entitlements) {
		this.entitlements = entitlements;
	}

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public ResourceMeta getMeta() {
		return meta;
	}

	public void setMeta(ResourceMeta meta) {
		this.meta = meta;
	}

	public Set<String> getSchemas() {
		return schemas;
	}

	public void setSchemas(Set<String> schemas) {
		this.schemas = schemas;
	}

	// SCIM Complex Types
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Name {
		private String lastName;

		private String firstName;

		public Name() {
		}

		public Name(String lastName, String firstName) {
			this.lastName = lastName;
			this.firstName = firstName;
		}

		@JsonProperty("familyName")
		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		@JsonProperty("givenName")
		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Email {
		@JsonInclude(JsonInclude.Include.ALWAYS)
		private String emailAddress;

		private Boolean primary;

		public Email() {
		}

		public Email(String emailAddress, Boolean primary) {
			this.emailAddress = emailAddress;
			this.primary = primary;
		}

		@JsonProperty("value")
		public String getEmailAddress() {
			return emailAddress;
		}

		@JsonProperty("primary")
		public Boolean getPrimary() {
			return primary;
		}

		public void setEmailAddress(String emailAddress) {
			this.emailAddress = emailAddress;
		}

		public void setPrimary(Boolean primary) {
			this.primary = primary;
		}
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class PhoneNumber {
		@JsonInclude(JsonInclude.Include.ALWAYS)
		private String phoneNumber;

		private String phoneType;

		public PhoneNumber() {
		}

		public PhoneNumber(String phoneNumber, String phoneType) {
			this.phoneNumber = phoneNumber;
			this.phoneType = phoneType;
		}

		@JsonProperty("value")
		public String getPhoneNumber() {
			return phoneNumber;
		}

		@JsonProperty("type")
		public String getPhoneType() {
			return phoneType;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		public void setPhoneType(String phoneType) {
			this.phoneType = phoneType;
		}
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Role {
		@JsonInclude(JsonInclude.Include.ALWAYS)
		private String value;

		private String display;

		public Role() {
		}

		public Role(String value) {
			this.value = value;
		}

		public Role(String value, String display) {
			this.value = value;
			this.display = display;
		}

		public String getValue() {
			return value;
		}

		public String getDisplay() {
			return display;
		}

		public void setValue(String value) {
			this.value = value;
		}

		public void setDisplay(String display) {
			this.display = display;
		}
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class Entitlement {
		@JsonInclude(JsonInclude.Include.ALWAYS)
		private String value;

		private String display;

		private String type;

		private Boolean primary;
		
		private String description;

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public Entitlement() {
		}

		public Entitlement(String value) {
			this.value = value;
		}

		public Entitlement(String value, String display, String type, Boolean primary) {
			this.value = value;
			this.display = display;
			this.type = type;
			this.primary = primary;
		}

		public String getValue() {
			return value;
		}

		public String getDisplay() {
			return display;
		}

		public String getType() {
			return type;
		}

		public Boolean getPrimary() {
			return primary;
		}

		public void setValue(String value) {
			this.value = value;
		}

		public void setDisplay(String display) {
			this.display = display;
		}

		public void setType(String type) {
			this.type = type;
		}

		public void setPrimary(Boolean primary) {
			this.primary = primary;
		}
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ScimEnterpriseUser {

		private String instance;
		private String region ;
		private String createdBy ;
		private String modifiedBy ;
		private String isActive ;
		private String manager ;
		private String userRoles ;
		// Preserves the numeric userId from GlobalFMS so it is not lost when
		// userName is used as the SCIM id.
		private String userId ;
		
		public String getUserId() {
			return userId;
		}

		public void setUserId(String userId) {
			this.userId = userId;
		}

		public String getRegion() {
			return region;
		}

		public void setRegion(String region) {
			this.region = region;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public String getModifiedBy() {
			return modifiedBy;
		}

		public void setModifiedBy(String modifiedBy) {
			this.modifiedBy = modifiedBy;
		}

		public String getIsActive() {
			return isActive;
		}

		public void setIsActive(String isActive) {
			this.isActive = isActive;
		}

		public String getManager() {
			return manager;
		}

		public void setManager(String manager) {
			this.manager = manager;
		}

		public String getUserRoles() {
			return userRoles;
		}

		public void setUserRoles(String userRoles) {
			this.userRoles = userRoles;
		}

		public ScimEnterpriseUser() {
		}

		public ScimEnterpriseUser(String instance) {
			this.instance = instance;
		}

		public String getInstance() {
			return instance;
		}

		public void setInstance(String instance) {
			this.instance = instance;
		}
	}

	@JsonInclude(JsonInclude.Include.NON_NULL)
	public static class ResourceMeta {
		private String resourceType;

		private String location;

		private String version;

		private String created;

		private String lastModified;

		public ResourceMeta() {
		}

		public ResourceMeta(String resourceType) {
			this.resourceType = resourceType;
		}

		public ResourceMeta(String resourceType, String location, String version) {
			this.resourceType = resourceType;
			this.location = location;
			this.version = version;
		}

		public String getResourceType() {
			return resourceType;
		}

		public void setResourceType(String resourceType) {
			this.resourceType = resourceType;
		}

		public String getLocation() {
			return location;
		}

		public void setLocation(String location) {
			this.location = location;
		}

		public String getVersion() {
			return version;
		}

		public void setVersion(String version) {
			this.version = version;
		}

		public String getCreated() {
			return created;
		}

		public void setCreated(String created) {
			this.created = created;
		}

		public String getLastModified() {
			return lastModified;
		}

		public void setLastModified(String lastModified) {
			this.lastModified = lastModified;
		}
	}
}
