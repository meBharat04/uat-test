package com.dell.webservice.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/{appName}/scim/v2/ServiceProviderConfig"})
public class ServiceProviderConfigController {
	
	private static final Logger logger = LogManager.getLogger(ServiceProviderConfigController.class);
	private String LoggerAppend = "Dell Webservice ServiceProviderConfigController Class --- ";

	@GetMapping
	public String defaultGet(@PathVariable String appName) {
		
		logger.info("{}ServiceProviderConfigController class called for appName= {}",LoggerAppend, appName);
		
		return """
					{
						"schemas": [
							"urn:okta:schemas:scim:providerconfig:2.0",
							"urn:ietf:params:scim:schemas:core:2.0:ServiceProviderConfig"
						],
						"meta": {
							"created": "2025-02-06T13:46:20.140576",
							"lastModified": "2025-02-06T13:46:20.140614",
							"version": "v1.0"
						},
						"documentationUri": "https://support.okta.com/scim-fake-page.html",
						"patch": {
							"supported": true,
							"maxOperations": 100
						},
						"bulk": {
							"supported": false
						},
						"filter": {
							"supported": true,
							"maxResults": 100
						},
						"changePassword": {
							"supported": true
						},
						"sort": {
							"supported": false
						},
						"etag": {
							"supported": false
						},
						"authenticationSchemes": [
							{
								"type": "oauthbearertoken",
								"name": "OAuth Bearer Token",
								"description": "Authentication scheme using the OAuth Bearer Token Standard",
								"specUri": "http://www.rfc-editor.org/info/rfc6750",
								"documentationUri": "http://example.com/help/oauth.html"
							}
						],
						"urn:okta:schemas:scim:providerconfig:2.0": {
							"userManagementCapabilities": [
								"IMPORT_NEW_USERS",
								"IMPORT_PROFILE_UPDATES",
								"PUSH_NEW_USERS",
								"PUSH_PASSWORD_UPDATES",
								"PUSH_PENDING_USERS",
								"PUSH_PROFILE_UPDATES",
								"PUSH_USER_DEACTIVATION",
								"REACTIVATE_USERS",
								"IMPORT_USER_SCHEMA",
								"PUSH_NEW_USERS_WITHOUT_PASSWORD"
							]
						}
					}
				""";
	}
}
