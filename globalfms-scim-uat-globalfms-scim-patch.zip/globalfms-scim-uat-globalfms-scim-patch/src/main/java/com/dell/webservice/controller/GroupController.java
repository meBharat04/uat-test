package com.dell.webservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/{appName}/scim/v2/Groups"})
public class GroupController {

	@GetMapping
	public String defaultGet(@PathVariable String appName) {
		
String groupResourceReturn = """
					{
					  "schemas": [
						"urn:ietf:params:scim:api:messages:2.0:ListResponse"
					  ],
					  "totalResults": 0,
					  "startIndex": 0,
					  "itemsPerPage": 0,
					  "Resources": []
					}
				""";

		return groupResourceReturn;
}
}
