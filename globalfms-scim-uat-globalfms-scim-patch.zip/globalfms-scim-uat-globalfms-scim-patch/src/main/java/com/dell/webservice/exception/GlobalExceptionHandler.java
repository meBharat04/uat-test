package com.dell.webservice.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;
import java.util.Set;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LogManager.getLogger(GlobalExceptionHandler.class);
    private static final Set<String> SCIM_ERROR_SCHEMAS =
            Set.of("urn:ietf:params:scim:api:messages:2.0:Error");

    @ExceptionHandler(RateLimitException.class)
    public ResponseEntity<Map<String, Object>> handleRateLimit(RateLimitException ex) {
        logger.warn("GlobalExceptionHandler rate limit exceeded, Retry-After={}", ex.getRetryAfter());
        HttpHeaders headers = new HttpHeaders();
        headers.set("Retry-After", ex.getRetryAfter());
        return ResponseEntity.status(HttpStatus.TOO_MANY_REQUESTS)
                .headers(headers)
                .body(scimError(429, "Too many requests. Please retry after " + ex.getRetryAfter() + " seconds."));
    }

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<Map<String, Object>> handleUnauthorized(UnauthorizedException ex) {
        logger.warn("GlobalExceptionHandler unauthorized: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body(scimError(401, "Invalid client credentials"));
    }

    @ExceptionHandler(UpstreamServiceException.class)
    public ResponseEntity<Map<String, Object>> handleUpstream(UpstreamServiceException ex) {
        // Full detail is logged server-side only; do not leak upstream internals to the client.
        logger.error("GlobalExceptionHandler upstream service error: {}", ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(scimError(502, "Upstream Global FMS service error"));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleBadRequest(IllegalArgumentException ex) {
        logger.warn("GlobalExceptionHandler bad request: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(scimError(400, ex.getMessage()));
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, Object>> handleInternalError(IllegalStateException ex) {
        logger.error("GlobalExceptionHandler internal error: {}", ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(scimError(500, "An internal error occurred. Please contact support."));
    }

    private Map<String, Object> scimError(int status, String detail) {
        return Map.of(
                "schemas", SCIM_ERROR_SCHEMAS,
                "status", status,
                "detail", detail
        );
    }
}
