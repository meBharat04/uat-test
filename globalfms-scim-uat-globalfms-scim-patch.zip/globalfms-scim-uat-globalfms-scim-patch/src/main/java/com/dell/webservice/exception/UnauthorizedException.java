package com.dell.webservice.exception;

/**
 * Thrown when the token endpoint rejects the client credentials supplied by the
 * IdP (HTTP 401). Mapped to HTTP 401 by {@link GlobalExceptionHandler} so the
 * SCIM client sees a credentials problem rather than an upstream outage.
 */
public class UnauthorizedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public UnauthorizedException(String message) {
        super(message);
    }

    public UnauthorizedException(String message, Throwable cause) {
        super(message, cause);
    }
}
