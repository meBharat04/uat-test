package com.dell.webservice.pojos;


import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.dell.webservice.controller.ScimUserV2;


 public class GlobalFMSUtility {

    private final Logger logger = LogManager.getLogger(GlobalFMSUtility.class);
    private final String loggerAppend = "Dell Webservice Global FMS GlobalFMSUtility Class --- ";

    GlobalFMSSettings settings = new GlobalFMSSettings();

    public void validateAppName(String appName) {
        if (appName == null || !ValidationPatterns.APP_NAME_PATTERN.matcher(appName).matches()) {
            throw new IllegalArgumentException("Invalid appName format. Must contain 1-50 alphanumeric characters, underscores, or hyphens");
        }
        logger.debug("{} App name validated: {}", loggerAppend, appName);
    }

    public void validateId(String id) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("ID cannot be null or empty");
        }
        if (!ValidationPatterns.ID_PATTERN.matcher(id).matches()) {
            throw new IllegalArgumentException("Invalid ID format. Must contain 1-100 alphanumeric characters, @, ., _ or -");
        }
        logger.debug("{} ID validated: {}", loggerAppend, id);
    }

    public void validateUser(ScimUserV2 user) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        if (user.getUserName() == null || user.getUserName().isBlank()) {
            throw new IllegalArgumentException("Username cannot be null or empty");
        }
    }

    public void validateAuthHeader(String authHeader) {
        if (authHeader == null || authHeader.isBlank()) {
            throw new IllegalArgumentException("Authorization header is required");
        }
        if (!authHeader.startsWith("Basic ")) {
            throw new IllegalArgumentException("Invalid Authorization header format. Expected 'Basic <credentials>'");
        }
    }
   
    
     public void validateUrl(String urlString) throws URISyntaxException, UnknownHostException {
    	 logger.info("{} ========= validateUrl() start ========= Allowed Hosts = {}",loggerAppend,settings.getAllowedHosts());
    	 
         if (urlString == null || urlString.isBlank()) {
             throw new IllegalArgumentException("URL cannot be null or empty");
         }

         URI uri = new URI(urlString);

         // 1. HTTPS only
         String scheme = uri.getScheme();
         if (scheme == null || !scheme.equals("https")) {
        	 throw new IllegalArgumentException("HTTPS required, got: " + scheme);
         }

         // 2. Validate host exists
         String host = uri.getHost();
         if (host == null || host.isEmpty()) {
             throw new IllegalArgumentException("Invalid host");
         }
       //  Set<String> ALLOWED_HOSTS = Set.of(allowedHosts.split(","));
         // 3. Allowlist check
     //    if (!ALLOWED_HOSTS.contains(host)) {
            // throw new IllegalArgumentException("Host not allowed: " + host);
       //  }

         // 4. Resolve and check IP — block internal/loopback/cloud-metadata (SSRF protection).
         InetAddress address = InetAddress.getByName(host);
         if (isInternalIp(address)) {
             logger.warn("{} InternalIp detected for IP: {}", loggerAppend, address.getHostAddress());
            // throw new IllegalArgumentException("Blocked IP address: " + address.getHostAddress());
         }
     }

     private boolean isInternalIp(InetAddress address) {
         return address.isLoopbackAddress() ||
                address.isLinkLocalAddress() ||
                address.isSiteLocalAddress() ||
                address.isAnyLocalAddress() ||
                isCloudMetadata(address);
     }

     private boolean isCloudMetadata(InetAddress address) {
         return address.getHostAddress().equals("169.254.169.254");
     }
     public static String decodeBasicAuth(String authHeader) {
         if (authHeader == null || !authHeader.startsWith("Basic ")) {
             throw new IllegalArgumentException("Invalid Basic auth header");
         }

         String base64Credentials = authHeader.substring(6); // "Basic " is 6 chars
         byte[] decodedBytes = Base64.getDecoder().decode(base64Credentials);
         return new String(decodedBytes, StandardCharsets.UTF_8);
     }


     public static String[] extractCredentials(String authHeader) {
         String decoded = decodeBasicAuth(authHeader);

         // Split only on first colon (password may contain colons)
         int colonIndex = decoded.indexOf(':');
         if (colonIndex == -1) {
             throw new IllegalArgumentException("Invalid credentials format");
         }

         String username = decoded.substring(0, colonIndex);
         String password = decoded.substring(colonIndex + 1);

         return new String[] { username, password };
     }


 }
