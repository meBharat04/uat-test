package com.dell.webservice.pojos;

import java.util.regex.Pattern;

public final class ValidationPatterns {

    private ValidationPatterns() {}

    public static final Pattern APP_NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_-]{1,50}$");

    public static final Pattern ID_PATTERN = Pattern.compile("^[a-zA-Z0-9@._-]{1,100}$");

    public static final Pattern FILTER_USERNAME_PATTERN =
            Pattern.compile("^userName\\s+eq\\s+\"[a-zA-Z0-9@._\\-]+\"$");

    public static final Pattern PATCH_VALUE_PATTERN =
            Pattern.compile("value\\s+eq\\s+\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);

    public static final Pattern PATCH_TYPE_PATTERN =
            Pattern.compile("type\\s+eq\\s+\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
}
