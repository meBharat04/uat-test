package com.dell.webservice.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping({"/{appName}/scim/v2/Schemas"})
public class SchemaController {

	@GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
	public String defaultGet() {
		return """
					{
    "schemas": [
        "urn:ietf:params:scim:api:messages:2.0:ListResponse"
    ],
    "totalResults": 2,
    "startIndex": 0,
    "itemsPerPage": 2,
    "Resources": [
        {
            "id": "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User",
            "meta": {
                "resourceType": "Schema",
                "created": "2023-12-13T20:36:42",
                "lastModified": "2023-07-17T19:36:55",
                "location": "/v2/Schemas/urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
            },
            "name": "EnterpriseUser",
            "description": "Enterprise User",
            "attributes": [

                {
                    "name": "region",
                    "type": "string",
                    "multiValued": false,
                    "description": "Indicates the Users region",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none"
                },
                {
                    "name": "createBy",
                    "type": "string",
                    "multiValued": false,
                    "description": "createdBy",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none"
                },
                {
                    "name": "modifiedBy",
                    "type": "string",
                    "multiValued": false,
                    "description": "modifiedBy",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none"
                },
                {
                    "name": "isActive",
                    "type": "string",
                    "multiValued": false,
                    "description": "isActive",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none"
                },
                   {
                    "name": "manager",
                    "type": "string",
                    "multiValued": false,
                    "description": "manager",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none"
                },
                   {
                    "name": "userRoles",
                    "type": "string",
                    "multiValued": false,
                    "description": "userRoles",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none"
                },
 		{
                    "name": "userId",
                    "type": "string",
                    "multiValued": false,
                    "description": "Numeric internal userId from GlobalFMS, preserved for reference",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readOnly",
                    "returned": "default",
                    "uniqueness": "none"
                }
            ]
        },
        {
            "id": "urn:ietf:params:scim:schemas:core:2.0:User",
            "meta": {
                "resourceType": "Schema",
                "created": "2024-01-10T19:39:37",
                "lastModified": "2023-07-17T19:36:55",
                "location": "/v2/Schemas/urn:ietf:params:scim:schemas:core:2.0:User"
            },
            "name": "User",
            "description": "User Account",
            "attributes": [
                {
                    "name": "userName",
                    "type": "string",
                    "multiValued": false,
                    "description": "Unique identifier for the User. REQUIRED.",
                    "required": true,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "server"
                },
                {
                    "name": "displayName",
                    "type": "string",
                    "multiValued": false,
                    "description": "DisplayName for the user",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none"
                },
                {
                    "name": "active",
                    "type": "boolean",
                    "multiValued": false,
                    "description": "A Boolean value indicating the Users administrative status.",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default"
                },
                {
                    "name": "emails",
                    "type": "complex",
                    "multiValued": true,
                    "description": "Email addresses for the user",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "uniqueness": "none",
                    "subAttributes": [
                        {
                            "name": "value",
                            "type": "string",
                            "multiValued": false,
                            "description": "Email addresses for the user",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default",
                            "uniqueness": "none"
                        },
                        {
                            "name": "display",
                            "type": "string",
                            "multiValued": false,
                            "description": "A human-readable name, primarily used for display purposes.  READ-ONLY.",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default",
                            "uniqueness": "none"
                        },
                        {
                            "name": "type",
                            "type": "string",
                            "multiValued": false,
                            "description": "A label indicating the attributes function, e.g., work or home.",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default",
                            "uniqueness": "none"
                        },
                        {
                            "name": "primary",
                            "type": "boolean",
                            "multiValued": false,
                            "description": "A Boolean value indicating the primary or preferred attribute value for this attribute, e.g., the preferred mailing address or primary email address",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default"
                        }
                    ]
                },
                {
                    "name": "entitlements",
                    "type": "complex",
                    "multiValued": true,
                    "description": "A list of entitlements for the User that collectively represent who the User.",
                    "required": false,
                    "caseExact": false,
                    "mutability": "readWrite",
                    "returned": "default",
                    "subAttributes": [
                        {
                            "name": "value",
                            "type": "string",
                            "multiValued": false,
                            "description": "The value of an entitlement.",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default",
                            "uniqueness": "none"
                        },
                        {
                            "name": "display",
                            "type": "string",
                            "multiValued": false,
                            "description": "A human-readable name, primarily used for display purposes.  READ-ONLY.",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default",
                            "uniqueness": "none"
                        },
                        {
                            "name": "type",
                            "type": "string",
                            "multiValued": false,
                            "description": "A label indicating the attributes function.",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default",
                            "uniqueness": "none"
                        },
                        {
                            "name": "description",
                            "type": "string",
                            "multiValued": false,
                            "description": "A label indicating the attributes description.",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default",
                            "uniqueness": "none"
                        },
                        {
                            "name": "primary",
                            "type": "boolean",
                            "multiValued": false,
                            "description": "A Boolean value indicating the primary or preferred attribute value for this attribute.  The primary attribute value true MUST appear no more than once.",
                            "required": false,
                            "caseExact": false,
                            "mutability": "readWrite",
                            "returned": "default"
                        }
                    ]
                }
            ]
        }
    ]
}
				""";
	}
}
