package com.dell.webservice.cache;

import com.dell.webservice.api.BuildConnection;
import com.dell.webservice.controller.ScimUserV2;
import com.dell.webservice.controller.ScimUserV2.Email;
import com.dell.webservice.controller.ScimUserV2.Name;
import com.dell.webservice.exception.RateLimitException;
import com.dell.webservice.exception.UpstreamServiceException;
import com.dell.webservice.pojos.GlobalFMSSettings;
import com.dell.webservice.pojos.GlobalFMSUtility;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class UserCacheService {

    private static final Logger logger = LogManager.getLogger(UserCacheService.class);
    private static final String LOGGER_APPEND = "Dell Webservice GlobalFMS UserCacheService --- ";

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS");
    private static final DateTimeFormatter DATE_FORMATTER_SHORT = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
    private static final DateTimeFormatter DATE_FORMATTER_DOTS = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH.mm.ss.S");

    @Autowired
    private GlobalFMSSettings globalfmssettings;

    @Autowired
    private BuildConnection buildConnection;

    private final HttpClient httpClient;
    private final GlobalFMSUtility gfmsutility;

    public UserCacheService() {
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(60))
                .followRedirects(HttpClient.Redirect.NEVER)
                .build();
        this.gfmsutility = new GlobalFMSUtility();
    }

    public PaginatedResult<ScimUserV2> getUsers(String authHeader, Integer startIndex, Integer count, String filter) throws Exception {
        List<ScimUserV2> users = fetchUsersFromApi(authHeader);

        // Apply filter if present (for incremental import)
        if (filter != null && filter.contains("meta.lastModified")) {
            users = filterByLastModified(users, filter);
        }

        int totalResults = users.size();

        // SCIM startIndex is 1-based, default to 1
        int start = (startIndex != null && startIndex > 0) ? startIndex : 1;
        int pageSize = (count != null && count > 0) ? Math.min(count, 1000) : 100;

        int fromIndex = Math.max(0, start - 1);
        int toIndex = Math.min(fromIndex + pageSize, totalResults);

        List<ScimUserV2> paginatedList;
        if (fromIndex >= totalResults) {
            paginatedList = new ArrayList<>();
        } else {
            paginatedList = new ArrayList<>(users.subList(fromIndex, toIndex));
        }

        return new PaginatedResult<>(paginatedList, totalResults, start, paginatedList.size());
    }

    public ScimUserV2 getUserByUserName(String authHeader, String userName) throws Exception {
        List<ScimUserV2> users = fetchUsersFromApi(authHeader);

        return users.stream()
                .filter(u -> userName.equals(u.getUserName()))
                .findFirst()
                .orElse(null);
    }

    public ScimUserV2 getUserByUserId(String authHeader, String userId) throws Exception {
        List<ScimUserV2> users = fetchUsersFromApi(authHeader);

        ScimUserV2 found = users.stream()
                .filter(u -> u.getEnterpriseInfo() != null && userId.equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        if (found == null) {
            logger.warn("{} getUserByUserId() userId={} not found on first fetch — retrying after refresh", LOGGER_APPEND, userId);
            users = fetchUsersFromApi(authHeader);
            found = users.stream()
                    .filter(u -> u.getEnterpriseInfo() != null && userId.equals(u.getEnterpriseInfo().getUserId()))
                    .findFirst()
                    .orElse(null);
        }

        return found;
    }

    private List<ScimUserV2> fetchUsersFromApi(String authHeader) throws Exception {
        logger.info("{} Fetching users from API...", LOGGER_APPEND);
        long startTime = System.currentTimeMillis();

        String baseURL = globalfmssettings != null ? globalfmssettings.getListAllUsersURL() : "";
        String tokenURL = globalfmssettings != null ? globalfmssettings.getAccessTokenURL() : "";

        gfmsutility.validateUrl(baseURL);
        gfmsutility.validateUrl(tokenURL);

        String token = buildConnection.getAccessToken(tokenURL, authHeader);

        if (token == null || token.isBlank()) {
            throw new IllegalArgumentException(LOGGER_APPEND + "Token is null or blank");
        }

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(baseURL))
                .timeout(Duration.ofMinutes(5))
                .header("Content-Type", "application/json")
                .header("Authorization", "Bearer " + token)
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() == 429) {
            throw new RateLimitException(response.headers().firstValue("Retry-After").orElse("60"));
        }
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new UpstreamServiceException("List users request failed: " + response.statusCode(),
                    response.statusCode());
        }

        JSONArray usersArray = new JSONArray(response.body());
        List<ScimUserV2> userList = new ArrayList<>(usersArray.length());

        for (int i = 0; i < usersArray.length(); i++) {
            JSONObject userJson = usersArray.getJSONObject(i);
            ScimUserV2 user = convertToScimUser(userJson);
            userList.add(user);
        }

        long elapsed = System.currentTimeMillis() - startTime;
        logger.info("{} Fetched {} users from API in {}ms", LOGGER_APPEND, userList.size(), elapsed);

        return userList;
    }

    private List<ScimUserV2> filterByLastModified(List<ScimUserV2> users, String filter) {
        try {
            // Parse filter: meta.lastModified gt "2026-06-19T00:00:00Z" or ge
            String operator = filter.contains(" gt ") ? "gt" : "ge";
            int startIdx = filter.indexOf("\"") + 1;
            int endIdx = filter.lastIndexOf("\"");

            logger.info("{} Received filter: {}", LOGGER_APPEND, filter);

            if (startIdx <= 0 || endIdx <= startIdx) {
                logger.warn("{} Invalid filter format, returning all users", LOGGER_APPEND);
                return users;
            }

            String dateStr = filter.substring(startIdx, endIdx);
            logger.info("{} Extracted date string: {}", LOGGER_APPEND, dateStr);

            // Remove 'Z' suffix if present
            if (dateStr.endsWith("Z")) {
                dateStr = dateStr.substring(0, dateStr.length() - 1);
            }

            // Compare only dates, not timestamps (to avoid server time differences)
            java.time.LocalDate filterDate = parseDateTime(dateStr).toLocalDate();
            logger.info("{} Parsed filter date: {}, operator: {}", LOGGER_APPEND, filterDate, operator);

            List<ScimUserV2> filtered = new ArrayList<>();
            int parseFailures = 0;

            for (ScimUserV2 user : users) {
                if (user.getMeta() != null && user.getMeta().getLastModified() != null) {
                    try {
                        java.time.LocalDate userModifiedDate = parseDateTime(user.getMeta().getLastModified()).toLocalDate();
                        // Always use >= comparison (include same day) since we compare dates only
                        boolean include = !userModifiedDate.isBefore(filterDate);
                        if (include) {
                            logger.debug("{} Including user {} with modifiedDate {}",
                                    LOGGER_APPEND, user.getUserName(), userModifiedDate);
                            filtered.add(user);
                        }
                    } catch (Exception e) {
                        parseFailures++;
                        logger.warn("{} Failed to parse date for user {}: {}",
                                LOGGER_APPEND, user.getUserName(), user.getMeta().getLastModified());
                    }
                }
            }

            logger.info("{} Filter result: {} users matched, {} parse failures, filter: {} {} {}",
                    LOGGER_APPEND, filtered.size(), parseFailures, "date", operator, filterDate);
            return filtered;

        } catch (Exception e) {
            logger.warn("{} Failed to parse lastModified filter: {}", LOGGER_APPEND, e.getMessage());
            return users;
        }
    }

    private LocalDateTime parseDateTime(String dateStr) {
        if (dateStr == null) {
            return LocalDateTime.MIN;
        }
        // Remove 'Z' suffix if present
        if (dateStr.endsWith("Z")) {
            dateStr = dateStr.substring(0, dateStr.length() - 1);
        }
        try {
            return LocalDateTime.parse(dateStr, DATE_FORMATTER);
        } catch (Exception e1) {
        	try {
                return LocalDateTime.parse(dateStr, DATE_FORMATTER_SHORT);
            } catch (Exception e2) {
                // Handle format with dots instead of colons (e.g., 2026-06-22T04.54.54.8)
                return LocalDateTime.parse(dateStr, DATE_FORMATTER_DOTS);
            }
        }
    }

    private ScimUserV2 convertToScimUser(JSONObject json) {
        ScimUserV2 user = new ScimUserV2();

        user.setSchemas(Set.of(
                "urn:ietf:params:scim:schemas:core:2.0:User",
                "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
        ));

        String odId = getStringOrNull(json, "userId");
        String userName = getStringOrNull(json, "userName");

        user.setId(odId != null ? odId : userName);
        user.setUserName(userName);
        user.setExternalId(userName);
        user.setDisplayName(userName);
        user.setDetailedName(new Name(userName, userName));

        boolean isActive = json.has("isActive") && !json.isNull("isActive") && json.getBoolean("isActive");
        user.setActive(isActive);

        String email = getStringOrNull(json, "email");
        if (email != null && !email.isBlank()) {
            user.setEmails(List.of(new Email(email, true)));
        }

        // Set meta with lastModified from modifiedDate
        ScimUserV2.ResourceMeta meta = new ScimUserV2.ResourceMeta("User");
        String modifiedDate = getStringOrNull(json, "modifiedDate");
        if (modifiedDate != null) {
            meta.setLastModified(modifiedDate);
        }
        String createdDate = getStringOrNull(json, "createdDate");
        if (createdDate != null) {
            meta.setCreated(createdDate);
        }
        user.setMeta(meta);

        // Enterprise info
        ScimUserV2.ScimEnterpriseUser enterpriseInfo = new ScimUserV2.ScimEnterpriseUser();
        enterpriseInfo.setUserId(odId);  // numeric userId preserved here
        enterpriseInfo.setRegion(getStringOrNull(json, "region"));
        enterpriseInfo.setCreatedBy(getStringOrNull(json, "createdBy"));
        enterpriseInfo.setModifiedBy(getStringOrNull(json, "modifiedBy"));
        enterpriseInfo.setIsActive(String.valueOf(isActive));
        enterpriseInfo.setManager(getStringOrNull(json, "manager"));

        // User roles / entitlements
        if (json.has("userRoles") && !json.isNull("userRoles")) {
            JSONArray rolesArray = json.getJSONArray("userRoles");
            List<ScimUserV2.Entitlement> entitlements = new ArrayList<>();
            StringBuilder rolesBuilder = new StringBuilder();

            for (int i = 0; i < rolesArray.length(); i++) {
                String role = rolesArray.getString(i);

                ScimUserV2.Entitlement ent = new ScimUserV2.Entitlement();
                ent.setValue(role);
                ent.setDisplay(role);
                ent.setType("Entitlement");
                entitlements.add(ent);

                if (!rolesBuilder.isEmpty()) {
                    rolesBuilder.append(",");
                }
                rolesBuilder.append(role);
            }

            user.setEntitlements(entitlements);
            enterpriseInfo.setUserRoles(rolesBuilder.toString());
        }

        user.setEnterpriseInfo(enterpriseInfo);

        return user;
    }

    private String getStringOrNull(JSONObject json, String key) {
        if (json.has(key) && !json.isNull(key)) {
            return json.get(key).toString();
        }
        return null;
    }

    public static class PaginatedResult<T> {
        private final List<T> items;
        private final int totalResults;
        private final int startIndex;
        private final int itemsPerPage;

        public PaginatedResult(List<T> items, int totalResults, int startIndex, int itemsPerPage) {
            this.items = items;
            this.totalResults = totalResults;
            this.startIndex = startIndex;
            this.itemsPerPage = itemsPerPage;
        }

        public List<T> getItems() { return items; }
        public int getTotalResults() { return totalResults; }
        public int getStartIndex() { return startIndex; }
        public int getItemsPerPage() { return itemsPerPage; }
    }
}