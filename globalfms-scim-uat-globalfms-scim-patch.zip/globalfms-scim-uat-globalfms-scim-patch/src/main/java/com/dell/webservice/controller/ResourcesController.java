package com.dell.webservice.controller;



  import org.apache.logging.log4j.LogManager;
  import org.apache.logging.log4j.Logger;
  import org.springframework.http.MediaType;

  import org.springframework.web.bind.annotation.GetMapping;
  import org.springframework.web.bind.annotation.PathVariable;
  import org.springframework.web.bind.annotation.RequestMapping;
  import org.springframework.web.bind.annotation.RestController;


  @RestController
  @RequestMapping("/{appName}/scim/v2/ResourceTypes")
  public class ResourcesController {

      private static final Logger logger = LogManager.getLogger(ResourcesController.class);
      private static final String LOGGER_PREFIX = "Dell Webservice Global FMS ResourcesController Class --- ";
      
      @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE, "application/scim+json"})
      public String defaultGet(@PathVariable String appName) {

          logger.info("{} appName={}", LOGGER_PREFIX, appName);

          return """
                  {
                      "schemas": [
                          "urn:ietf:params:scim:api:messages:2.0:ListResponse"
                      ],
                      "totalResults": 2,
                      "startIndex": 1,
                      "itemsPerPage": 2,
                      "Resources": [
                          {
                              "id": "User",
                              "meta": {
                                  "resourceType": "ResourceType",
                                  "created": "2025-11-08T15:25:04",
                                  "lastModified": "2025-11-08T15:25:04",
                                  "location": "https://example.com/v2/ResourceTypes/User"
                              },
                              "schemas": [
                                  "urn:ietf:params:scim:schemas:core:2.0:ResourceType"
                              ],
                              "name": "User",
                              "description": "User Account",
                              "endpoint": "/Users",
                              "schemaExtensions": [
                                  {
                                      "schema": "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User",
                                      "required": true
                                  }
                              ],
                              "schema": "urn:ietf:params:scim:schemas:core:2.0:User"
                          },
                          {
                              "id": "Entitlement",
                              "meta": {
                                  "resourceType": "ResourceType",
                                  "created": "2025-11-08T15:26:04",
                                  "lastModified": "2025-11-08T15:26:04",
                                  "location": "https://example.com/v2/ResourceTypes/Entitlement"
                              },
                              "schemas": [
                                  "urn:ietf:params:scim:schemas:core:2.0:ResourceType"
                              ],
                              "name": "Entitlement",
                              "description": "Entitlement resource",
                              "schema": "urn:okta:scim:schemas:core:1.0:Entitlement",
                              "endpoint": "/Entitlements"
                          }
                      ]
                  }
                  """;
      }
  }