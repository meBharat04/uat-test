package com.dell.webservice.apprules;

import com.dell.webservice.controller.ScimUserV2;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class GlobalFMSWebServiceRulesTest {

    // ==================== Input Validation Tests ====================

    @Test
    void validateInputs_NullUser_Invalid() {
        ScimUserV2 user = null;
        assertNull(user);
    }

    @Test
    void validateInputs_NullUserName_Invalid() {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName(null);

        assertTrue(user.getUserName() == null || (user.getUserName() != null && user.getUserName().isBlank()));
    }

    @Test
    void validateInputs_BlankUserName_Invalid() {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName("   ");

        assertTrue(user.getUserName().isBlank());
    }

    @Test
    void validateInputs_ValidUser_Valid() {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName("testuser");

        assertFalse(user.getUserName() == null || user.getUserName().isBlank());
    }

    @Test
    void validateId_NullId_Invalid() {
        String id = null;
        assertTrue(id == null || id.isBlank());
    }

    @Test
    void validateId_BlankId_Invalid() {
        String id = "   ";
        assertTrue(id.isBlank());
    }

    @Test
    void validateId_ValidId_Valid() {
        String id = "123";
        assertTrue(id.matches("^[a-zA-Z0-9_-]{1,100}$"));
    }

    @Test
    void validateId_InvalidFormat_Invalid() {
        String id = "id with spaces";
        assertFalse(id.matches("^[a-zA-Z0-9_-]{1,100}$"));
    }

    // ==================== Entitlement Processing Tests ====================

    @Test
    void entitlements_BuildJsonArray_SingleEntitlement() {
        List<ScimUserV2.Entitlement> entitlements = List.of(
                new ScimUserV2.Entitlement("Admin", "Admin", "Entitlement", null)
        );

        StringBuilder builder = new StringBuilder();
        for (ScimUserV2.Entitlement ent : entitlements) {
            if (!builder.isEmpty()) {
                builder.append(",");
            }
            builder.append("\"").append(ent.getValue()).append("\"");
        }

        assertEquals("\"Admin\"", builder.toString());
    }

    @Test
    void entitlements_BuildJsonArray_MultipleEntitlements() {
        List<ScimUserV2.Entitlement> entitlements = List.of(
                new ScimUserV2.Entitlement("Admin", "Admin", "Entitlement", null),
                new ScimUserV2.Entitlement("User", "User", "Entitlement", null),
                new ScimUserV2.Entitlement("Conus", "Conus", "Entitlement", null)
        );

        StringBuilder builder = new StringBuilder();
        for (ScimUserV2.Entitlement ent : entitlements) {
            if (!builder.isEmpty()) {
                builder.append(",");
            }
            builder.append("\"").append(ent.getValue()).append("\"");
        }

        assertEquals("\"Admin\",\"User\",\"Conus\"", builder.toString());
    }

    @Test
    void entitlements_EmptyList_EmptyString() {
        List<ScimUserV2.Entitlement> entitlements = new ArrayList<>();

        StringBuilder builder = new StringBuilder();
        for (ScimUserV2.Entitlement ent : entitlements) {
            if (!builder.isEmpty()) {
                builder.append(",");
            }
            builder.append("\"").append(ent.getValue()).append("\"");
        }

        assertEquals("", builder.toString());
    }

    // ==================== Role Comparison Tests ====================

    @Test
    void roleComparison_FindRolesToRemove() {
        List<String> existingRoles = Arrays.asList("Admin", "User", "Conus");
        List<String> newRoles = Arrays.asList("Admin", "SuperUser");

        List<String> rolesToRemove = new ArrayList<>();
        for (String existing : existingRoles) {
            if (!newRoles.contains(existing)) {
                rolesToRemove.add(existing);
            }
        }

        assertEquals(2, rolesToRemove.size());
        assertTrue(rolesToRemove.contains("User"));
        assertTrue(rolesToRemove.contains("Conus"));
    }

    @Test
    void roleComparison_FindRolesToAdd() {
        List<String> existingRoles = Arrays.asList("Admin", "User");
        List<String> newRoles = Arrays.asList("Admin", "User", "SuperUser", "Fed");

        List<String> rolesToAdd = new ArrayList<>();
        for (String newRole : newRoles) {
            if (!existingRoles.contains(newRole)) {
                rolesToAdd.add(newRole);
            }
        }

        assertEquals(2, rolesToAdd.size());
        assertTrue(rolesToAdd.contains("SuperUser"));
        assertTrue(rolesToAdd.contains("Fed"));
    }

    @Test
    void roleComparison_NoChanges() {
        List<String> existingRoles = Arrays.asList("Admin", "User");
        List<String> newRoles = Arrays.asList("Admin", "User");

        List<String> rolesToRemove = new ArrayList<>();
        for (String existing : existingRoles) {
            if (!newRoles.contains(existing)) {
                rolesToRemove.add(existing);
            }
        }

        List<String> rolesToAdd = new ArrayList<>();
        for (String newRole : newRoles) {
            if (!existingRoles.contains(newRole)) {
                rolesToAdd.add(newRole);
            }
        }

        assertTrue(rolesToRemove.isEmpty());
        assertTrue(rolesToAdd.isEmpty());
    }

    // ==================== Deactivation Tests ====================

    @Test
    void deactivation_RemoveAllRoles() {
        List<String> existingRoles = Arrays.asList("Admin", "User", "Conus");
        boolean isActive = false;

        List<String> rolesToRemove = new ArrayList<>();
        if (!isActive) {
            rolesToRemove.addAll(existingRoles);
        }

        assertEquals(3, rolesToRemove.size());
    }

    @Test
    void deactivation_ActiveUser_NoAutoRemove() {
        List<String> existingRoles = Arrays.asList("Admin", "User", "Conus");
        boolean isActive = true;

        List<String> rolesToRemove = new ArrayList<>();
        if (!isActive) {
            rolesToRemove.addAll(existingRoles);
        }

        assertTrue(rolesToRemove.isEmpty());
    }

    // ==================== String Sanitization Tests ====================

    @Test
    void sanitizeString_NullInput_ReturnsEmpty() {
        String input = null;
        String result = input == null ? "" : input.replaceAll("[\"\\\\]", "");

        assertEquals("", result);
    }

    @Test
    void sanitizeString_RemovesQuotes() {
        String input = "Admin\"Role";
        String result = input.replaceAll("[\"\\\\]", "");

        assertEquals("AdminRole", result);
    }

    @Test
    void sanitizeString_RemovesBackslashes() {
        String input = "Admin\\Role";
        String result = input.replaceAll("[\"\\\\]", "");

        assertEquals("AdminRole", result);
    }

    @Test
    void sanitizeString_NormalString_Unchanged() {
        String input = "AdminRole";
        String result = input.replaceAll("[\"\\\\]", "");

        assertEquals("AdminRole", result);
    }

    // ==================== HTTP Status Tests ====================

    @Test
    void httpStatus_Success() {
        int statusCode = 200;
        assertTrue(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_Created() {
        int statusCode = 201;
        assertTrue(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_BadRequest() {
        int statusCode = 400;
        assertFalse(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_Unauthorized() {
        int statusCode = 401;
        assertFalse(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_ServerError() {
        int statusCode = 500;
        assertFalse(statusCode >= 200 && statusCode < 300);
    }

    // ==================== JSON Request Body Tests ====================

    @Test
    void requestBody_AddUserRole_Format() {
        String userName = "TestUser";
        String entitlementArray = "\"Admin\",\"User\"";

        String expected = String.format("""
                {
                "UserName": "%s",
                "RoleNames": [%s],
                "ModifiedBy": "%s"
            }""", userName, entitlementArray, userName);

        assertTrue(expected.contains("\"UserName\": \"TestUser\""));
        assertTrue(expected.contains("\"RoleNames\": [\"Admin\",\"User\"]"));
    }

    // ==================== Email Validation Tests ====================

    @Test
    void email_NullEmails_Invalid() {
        ScimUserV2 user = new ScimUserV2();
        user.setEmails(null);

        assertTrue(user.getEmails() == null);
    }

    @Test
    void email_EmptyList_Invalid() {
        ScimUserV2 user = new ScimUserV2();
        user.setEmails(new ArrayList<>());

        assertTrue(user.getEmails().isEmpty());
    }

    @Test
    void email_ValidEmail_Valid() {
        ScimUserV2 user = new ScimUserV2();
        user.setEmails(List.of(new ScimUserV2.Email("test@dell.com", true)));

        assertFalse(user.getEmails().isEmpty());
        assertNotNull(user.getEmails().get(0).getEmailAddress());
    }

    // ==================== Token Validation Tests ====================

    @Test
    void token_NullToken_Invalid() {
        String token = null;
        assertTrue(token == null || token.isBlank());
    }

    @Test
    void token_BlankToken_Invalid() {
        String token = "   ";
        assertTrue(token.isBlank());
    }

    @Test
    void token_ValidToken_Valid() {
        String token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
        assertFalse(token == null || token.isBlank());
    }

    // ==================== globalFMSUpdateUserRule: real behavior ====================

    private static final String ADD_URL = "https://8.8.8.8/AccessManagement/AddUserRole";
    private static final String REMOVE_URL = "https://8.8.8.8/AccessManagement/RemoveUserRole";

    private java.net.http.HttpClient mockClient;
    private GlobalFMSWebServiceRules rules;

    @org.junit.jupiter.api.BeforeEach
    void setUpRules() {
        mockClient = org.mockito.Mockito.mock(java.net.http.HttpClient.class);
        rules = new GlobalFMSWebServiceRules(mockClient);
    }

    private void respondWith(int status) throws Exception {
        org.mockito.Mockito.doReturn(com.dell.webservice.testsupport.TestHttpResponses.stringResponse(status, "{}"))
                .when(mockClient).send(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    private java.util.List<java.net.http.HttpRequest> sentRequests() throws Exception {
        org.mockito.ArgumentCaptor<java.net.http.HttpRequest> captor =
                org.mockito.ArgumentCaptor.forClass(java.net.http.HttpRequest.class);
        org.mockito.Mockito.verify(mockClient, org.mockito.Mockito.atLeast(0))
                .send(captor.capture(), org.mockito.ArgumentMatchers.any());
        return captor.getAllValues();
    }

    private static ScimUserV2 userWithRoles(Boolean active, String... roles) {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName("jdoe");
        user.setActive(active);
        List<ScimUserV2.Entitlement> ents = new ArrayList<>();
        for (String r : roles) {
            ents.add(new ScimUserV2.Entitlement(r, r, "Entitlement", false));
        }
        user.setEntitlements(ents);
        return user;
    }

    @Test
    void updateUser_nullActive_isTreatedAsActive_andDoesNotThrowNpe() throws Exception {
        respondWith(200);

        ScimUserV2 result = rules.globalFMSUpdateUserRule(userWithRoles(null, "Admin"), "7", "app", ADD_URL,
                REMOVE_URL, "", "tok");

        assertNotNull(result);
        // Active path: nothing to remove (no existing roles), Admin is added.
        assertEquals(1, sentRequests().size());
        assertTrue(sentRequests().get(0).uri().toString().endsWith("AddUserRole"));
    }

    @Test
    void updateUser_explicitFalse_removesExistingRolesWhenNoneSent() throws Exception {
        respondWith(200);

        rules.globalFMSUpdateUserRule(userWithRoles(false), "7", "app", ADD_URL, REMOVE_URL, "Admin,Auditor", "tok");

        assertEquals(1, sentRequests().size());
        assertTrue(sentRequests().get(0).uri().toString().endsWith("RemoveUserRole"));
    }

    @Test
    void updateUser_deactivatedWithNothingToRemove_makesNoUpstreamCall() throws Exception {
        rules.globalFMSUpdateUserRule(userWithRoles(false), "7", "app", ADD_URL, REMOVE_URL, "", "tok");

        assertEquals(0, sentRequests().size());
    }

    @Test
    void updateUser_active_removesDroppedRoleAndAddsCurrent() throws Exception {
        respondWith(200);

        rules.globalFMSUpdateUserRule(userWithRoles(true, "Admin"), "7", "app", ADD_URL, REMOVE_URL,
                "Admin,OldRole", "tok");

        List<java.net.http.HttpRequest> sent = sentRequests();
        assertEquals(2, sent.size());
        assertTrue(sent.get(0).uri().toString().endsWith("RemoveUserRole"));
        assertTrue(sent.get(1).uri().toString().endsWith("AddUserRole"));
    }

    @Test
    void updateUser_upstream500_throwsUpstreamServiceException() throws Exception {
        respondWith(500);

        assertThrows(com.dell.webservice.exception.UpstreamServiceException.class,
                () -> rules.globalFMSUpdateUserRule(userWithRoles(true, "Admin"), "7", "app", ADD_URL, REMOVE_URL,
                        "", "tok"));
    }

    @Test
    void updateUser_upstream429_throwsRateLimitExceptionWithRetryAfter() throws Exception {
        org.mockito.Mockito.doReturn(com.dell.webservice.testsupport.TestHttpResponses.stringResponse(429, "",
                java.util.Map.of("Retry-After", List.of("42"))))
                .when(mockClient).send(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());

        com.dell.webservice.exception.RateLimitException ex = assertThrows(
                com.dell.webservice.exception.RateLimitException.class,
                () -> rules.globalFMSUpdateUserRule(userWithRoles(true, "Admin"), "7", "app", ADD_URL, REMOVE_URL,
                        "", "tok"));
        assertEquals("42", ex.getRetryAfter());
    }

    @Test
    void updateUser_blankToken_isRejected() {
        assertThrows(IllegalArgumentException.class,
                () -> rules.globalFMSUpdateUserRule(userWithRoles(true, "Admin"), "7", "app", ADD_URL, REMOVE_URL,
                        "", " "));
    }

    @Test
    void createUser_upstream500_throwsUpstreamServiceException() throws Exception {
        respondWith(500);
        ScimUserV2 user = userWithRoles(true);
        user.setEmails(List.of(new ScimUserV2.Email("j@x.com", true)));

        assertThrows(com.dell.webservice.exception.UpstreamServiceException.class,
                () -> rules.globalFMSCreateUserRule(user, "app", "https://8.8.8.8/AccessManagement/AddUser", ADD_URL,
                        "tok"));
    }
}
