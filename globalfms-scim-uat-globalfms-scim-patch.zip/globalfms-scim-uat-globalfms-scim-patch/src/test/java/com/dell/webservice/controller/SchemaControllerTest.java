package com.dell.webservice.controller;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SchemaControllerTest {

    private final SchemaController schemaController = new SchemaController();

    @Test
    void defaultGet_ReturnsNonNullResponse() {
        String response = schemaController.defaultGet();
        assertNotNull(response);
    }

    @Test
    void defaultGet_ContainsListResponseSchema() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
    }

    @Test
    void defaultGet_ContainsTwoResources() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("\"totalResults\": 2"));
    }

    @Test
    void defaultGet_ContainsEnterpriseUserSchema() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"));
    }

    @Test
    void defaultGet_ContainsCoreUserSchema() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("urn:ietf:params:scim:schemas:core:2.0:User"));
    }

    @Test
    void defaultGet_ContainsUserNameAttribute() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("\"name\": \"userName\""));
    }

    @Test
    void defaultGet_ContainsEntitlementsAttribute() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("\"name\": \"entitlements\""));
    }

    @Test
    void defaultGet_ContainsManagerAttribute() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("\"name\": \"manager\""));
    }

    @Test
    void defaultGet_ContainsUserRolesAttribute() {
        String response = schemaController.defaultGet();
        assertTrue(response.contains("\"name\": \"userRoles\""));
    }

    @Test
    void defaultGet_IsValidJsonStructure() {
        String response = schemaController.defaultGet();
        assertTrue(response.trim().startsWith("{"));
        assertTrue(response.trim().endsWith("}"));
    }

}
