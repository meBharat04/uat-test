package com.dell.webservice.controller;

import com.dell.webservice.exception.UpstreamServiceException;
import com.dell.webservice.exception.UnauthorizedException;
import static org.junit.jupiter.api.Assertions.*;

import com.dell.webservice.exception.GlobalExceptionHandler;
import com.dell.webservice.exception.RateLimitException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void rateLimitException_Returns429WithRetryAfterHeader() {
        ResponseEntity<Map<String, Object>> response = handler.handleRateLimit(new RateLimitException("30"));

        assertEquals(HttpStatus.TOO_MANY_REQUESTS, response.getStatusCode());
        assertEquals("30", response.getHeaders().getFirst("Retry-After"));
        assertEquals(429, response.getBody().get("status"));
    }

    @Test
    void illegalArgumentException_Returns400() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleBadRequest(new IllegalArgumentException("Invalid input"));

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals(400, response.getBody().get("status"));
        assertEquals("Invalid input", response.getBody().get("detail"));
    }

    @Test
    void illegalStateException_Returns500WithGenericMessage() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleInternalError(new IllegalStateException("DB connection failed"));

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals(500, response.getBody().get("status"));
        assertFalse(response.getBody().get("detail").toString().contains("DB connection failed"),
                "Internal error detail should not leak to caller");
    }

    @Test
    void allResponses_ContainScimErrorSchema() {
        ResponseEntity<Map<String, Object>> r1 = handler.handleRateLimit(new RateLimitException("60"));
        ResponseEntity<Map<String, Object>> r2 = handler.handleBadRequest(new IllegalArgumentException("x"));
        ResponseEntity<Map<String, Object>> r3 = handler.handleInternalError(new IllegalStateException("x"));

        for (ResponseEntity<Map<String, Object>> r : java.util.List.of(r1, r2, r3)) {
            assertTrue(r.getBody().containsKey("schemas"), "SCIM error schema missing");
        }
    }

    @Test
    void unauthorizedException_Returns401AndHidesDetail() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleUnauthorized(new UnauthorizedException("secret internal detail"));

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals(401, response.getBody().get("status"));
        assertEquals("Invalid client credentials", response.getBody().get("detail"));
    }

    @Test
    void upstreamServiceException_Returns502AndHidesDetail() {
        ResponseEntity<Map<String, Object>> response =
                handler.handleUpstream(new UpstreamServiceException("token endpoint 500 at https://internal/secret"));

        assertEquals(HttpStatus.BAD_GATEWAY, response.getStatusCode());
        assertEquals(502, response.getBody().get("status"));
        assertEquals("Upstream Global FMS service error", response.getBody().get("detail"));
        assertFalse(response.getBody().get("detail").toString().contains("internal"));
        assertTrue(response.getBody().containsKey("schemas"));
    }
}
