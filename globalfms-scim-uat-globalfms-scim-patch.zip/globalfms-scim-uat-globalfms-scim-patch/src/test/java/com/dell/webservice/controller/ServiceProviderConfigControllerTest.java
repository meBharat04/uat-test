package com.dell.webservice.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@WebMvcTest(ServiceProviderConfigController.class)
@WithMockUser
class ServiceProviderConfigControllerTest {

	@Autowired
    private MockMvc mockMvc;

    // The expected JSON content from the controller, cleaned up for comparison
    private static final String EXPECTED_JSON = """
		{
			"schemas": [
				"urn:okta:schemas:scim:providerconfig:2.0",
				"urn:ietf:params:scim:schemas:core:2.0:ServiceProviderConfig"
			],
			"meta": {
				"created": "2025-02-06T13:46:20.140576",
				"lastModified": "2025-02-06T13:46:20.140614",
				"version": "v1.0"
			},
			"documentationUri": "https://support.okta.com/scim-fake-page.html",
			"patch": {
				"supported": true,
				"maxOperations": 100
			},
			"bulk": {
				"supported": false
			},
			"filter": {
				"supported": true,
				"maxResults": 100
			},
			"changePassword": {
				"supported": true
			},
			"sort": {
				"supported": false
			},
			"etag": {
				"supported": false
			},
			"authenticationSchemes": [
				{
					"type": "oauthbearertoken",
					"name": "OAuth Bearer Token",
					"description": "Authentication scheme using the OAuth Bearer Token Standard",
					"specUri": "http://www.rfc-editor.org/info/rfc6750",
					"documentationUri": "http://example.com/help/oauth.html"
				}
			],
			"urn:okta:schemas:scim:providerconfig:2.0": {
				"userManagementCapabilities": [
					"IMPORT_NEW_USERS",
					"IMPORT_PROFILE_UPDATES",
					"PUSH_NEW_USERS",
					"PUSH_PASSWORD_UPDATES",
					"PUSH_PENDING_USERS",
					"PUSH_PROFILE_UPDATES",
					"PUSH_USER_DEACTIVATION",
					"REACTIVATE_USERS",
					"IMPORT_USER_SCHEMA",
					"PUSH_NEW_USERS_WITHOUT_PASSWORD"
				]
			}
		}
	""";
	
	
	@Test
	final void testDefaultGet() throws Exception {
        MvcResult result = mockMvc.perform(get("/globalfms/scim/v2/ServiceProviderConfig"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("text/plain;charset=UTF-8"))
                .andReturn();

        String actualJson = result.getResponse().getContentAsString().trim();

        assertEquals(EXPECTED_JSON.trim(), actualJson, 
            "The controller method should return the exact, hardcoded Schema JSON string.");
    }

}
