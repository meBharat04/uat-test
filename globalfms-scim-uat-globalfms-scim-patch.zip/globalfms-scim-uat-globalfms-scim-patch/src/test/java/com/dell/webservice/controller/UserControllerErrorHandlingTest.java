package com.dell.webservice.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.dell.webservice.api.AppInitializer;
import com.dell.webservice.api.BuildConnection;
import com.dell.webservice.cache.UserCacheService;
import com.dell.webservice.config.SecurityConfig;
import com.dell.webservice.exception.RateLimitException;
import com.dell.webservice.exception.UnauthorizedException;
import com.dell.webservice.exception.UpstreamServiceException;
import com.dell.webservice.pojos.GlobalFMSSettings;

/**
 * Verifies that failures reach the SCIM client with the right status instead of
 * being swallowed (updateUser used to return 200 on every error). The access token
 * call happens inside each handler's try block, so a mocked {@link BuildConnection}
 * drives every failure path without any network I/O.
 */
@WebMvcTest(UserController.class)
@Import(SecurityConfig.class)
class UserControllerErrorHandlingTest {

    private static final String AUTH = "Basic "
            + Base64.getEncoder().encodeToString("id:secret".getBytes(StandardCharsets.UTF_8));
    private static final String PATCH_ADD = "{\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"],"
            + "\"Operations\":[{\"op\":\"add\",\"path\":\"entitlements\","
            + "\"value\":[{\"value\":\"Admin\",\"type\":\"Entitlement\"}]}]}";

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private BuildConnection buildConnection;

    @MockitoBean
    private AppInitializer appInitializer;

    @MockitoBean
    private UserCacheService userCacheService;

    @MockitoBean
    private GlobalFMSSettings globalfmssettings;

    @BeforeEach
    void setUp() {
        when(globalfmssettings.getAddUserRole()).thenReturn("https://8.8.8.8/AccessManagement/AddUserRole");
        when(globalfmssettings.getRemoveUserRole()).thenReturn("https://8.8.8.8/AccessManagement/RemoveUserRole");
        when(globalfmssettings.getCreateUserURL()).thenReturn("https://8.8.8.8/AccessManagement/AddUser");
        when(globalfmssettings.getAccessTokenURL()).thenReturn("https://8.8.8.8/token");
    }

    private void tokenFails(Throwable failure) throws Exception {
        when(buildConnection.getAccessToken(any(), any())).thenThrow(failure);
    }

    // ---- PUT: previously every failure returned 200 ----

    @Test
    void updateUser_rateLimit_returns429WithRetryAfter() throws Exception {
        tokenFails(new RateLimitException("30"));

        mockMvc.perform(put("/{app}/scim/v2/Users/{id}", "globalfms", "7")
                .header("Authorization", AUTH).contentType(MediaType.APPLICATION_JSON)
                .content("{\"userName\":\"jdoe\",\"active\":true}"))
                .andExpect(status().isTooManyRequests())
                .andExpect(header().string("Retry-After", "30"));
    }

    @Test
    void updateUser_badCredentials_returns401() throws Exception {
        tokenFails(new UnauthorizedException("bad creds"));

        mockMvc.perform(put("/{app}/scim/v2/Users/{id}", "globalfms", "7")
                .header("Authorization", AUTH).contentType(MediaType.APPLICATION_JSON)
                .content("{\"userName\":\"jdoe\",\"active\":true}"))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.status").value(401));
    }

    @Test
    void updateUser_upstreamFailure_returns502_notOk() throws Exception {
        tokenFails(new UpstreamServiceException("Add user role request failed: 500", 500));

        mockMvc.perform(put("/{app}/scim/v2/Users/{id}", "globalfms", "7")
                .header("Authorization", AUTH).contentType(MediaType.APPLICATION_JSON)
                .content("{\"userName\":\"jdoe\",\"active\":true}"))
                .andExpect(status().isBadGateway())
                .andExpect(jsonPath("$.status").value(502));
    }

    @Test
    void updateUser_unexpectedException_returns502_notOk() throws Exception {
        tokenFails(new RuntimeException("boom"));

        mockMvc.perform(put("/{app}/scim/v2/Users/{id}", "globalfms", "7")
                .header("Authorization", AUTH).contentType(MediaType.APPLICATION_JSON)
                .content("{\"userName\":\"jdoe\",\"active\":true}"))
                .andExpect(status().isBadGateway());
    }

    @Test
    void updateUser_invalidInput_stillReturns400() throws Exception {
        mockMvc.perform(put("/{app}/scim/v2/Users/{id}", "globalfms", "7")
                .header("Authorization", AUTH).contentType(MediaType.APPLICATION_JSON)
                .content("{\"active\":true}"))
                .andExpect(status().isBadRequest());
    }

    // ---- POST ----

    @Test
    void createUser_rateLimit_returns429() throws Exception {
        tokenFails(new RateLimitException("5"));

        mockMvc.perform(post("/{app}/scim/v2/Users", "globalfms")
                .header("Authorization", AUTH).contentType(MediaType.APPLICATION_JSON)
                .content("{\"userName\":\"jdoe\"}"))
                .andExpect(status().isTooManyRequests())
                .andExpect(header().string("Retry-After", "5"));
    }

    @Test
    void createUser_upstreamFailure_returns502_notBadRequest() throws Exception {
        tokenFails(new UpstreamServiceException("Create user request failed: 500", 500));

        mockMvc.perform(post("/{app}/scim/v2/Users", "globalfms")
                .header("Authorization", AUTH).contentType(MediaType.APPLICATION_JSON)
                .content("{\"userName\":\"jdoe\"}"))
                .andExpect(status().isBadGateway());
    }

    // ---- GET (list / filter) ----

    @Test
    void listUsers_filterLookupRateLimit_returns429() throws Exception {
        when(userCacheService.getUserByUserName(any(), any())).thenThrow(new RateLimitException("17"));

        mockMvc.perform(get("/{app}/scim/v2/Users", "globalfms")
                .param("filter", "userName eq \"jdoe\"")
                .header("Authorization", AUTH))
                .andExpect(status().isTooManyRequests())
                .andExpect(header().string("Retry-After", "17"));
    }

    @Test
    void listUsers_upstreamFailure_returns502() throws Exception {
        when(userCacheService.getUsers(any(), any(), any(), any()))
                .thenThrow(new UpstreamServiceException("List users request failed: 500", 500));

        mockMvc.perform(get("/{app}/scim/v2/Users", "globalfms").header("Authorization", AUTH))
                .andExpect(status().isBadGateway());
    }

    // ---- PATCH ----

    @Test
    void patchUser_rateLimit_returns429() throws Exception {
        tokenFails(new RateLimitException("11"));

        mockMvc.perform(patch("/{app}/scim/v2/Users/{id}", "globalfms", "7")
                .header("Authorization", AUTH).contentType("application/scim+json").content(PATCH_ADD))
                .andExpect(status().isTooManyRequests())
                .andExpect(header().string("Retry-After", "11"));
    }

    @Test
    void patchUser_badCredentials_returns401() throws Exception {
        tokenFails(new UnauthorizedException("bad creds"));

        mockMvc.perform(patch("/{app}/scim/v2/Users/{id}", "globalfms", "7")
                .header("Authorization", AUTH).contentType("application/scim+json").content(PATCH_ADD))
                .andExpect(status().isUnauthorized());
    }
}
