package com.dell.webservice.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@WebMvcTest(ResourcesController.class)
@WithMockUser
class ResourcesControllerTest {

	@Autowired
    private MockMvc mockMvc;

    // The expected JSON content from the controller, cleaned up for comparison
    private static final String EXPECTED_JSON = """
            {
            "schemas": [
                "urn:ietf:params:scim:api:messages:2.0:ListResponse"
            ],
            "totalResults": 2,
            "startIndex": 1,
            "itemsPerPage": 2,
            "Resources": [
                {
                    "id": "User",
                    "meta": {
                        "resourceType": "ResourceType",
                        "created": "2025-11-08T15:25:04",
                        "lastModified": "2025-11-08T15:25:04",
                        "location": "https://example.com/v2/ResourceTypes/User"
                    },
                    "schemas": [
                        "urn:ietf:params:scim:schemas:core:2.0:ResourceType"
                    ],
                    "name": "User",
                    "description": "User Account",
                    "endpoint": "/Users",
                    "schemaExtensions": [
                        {
                            "schema": "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User",
                            "required": true
                        }
                    ],
                    "schema": "urn:ietf:params:scim:schemas:core:2.0:User"
                },
                {
                    "id": "Entitlement",
                    "meta": {
                        "resourceType": "ResourceType",
                        "created": "2025-11-08T15:26:04",
                        "lastModified": "2025-11-08T15:26:04",
                        "location": "https://example.com/v2/ResourceTypes/Entitlement"
                    },
                    "schemas": [
                        "urn:ietf:params:scim:schemas:core:2.0:ResourceType"
                    ],
                    "name": "Entitlement",
                    "description": "Entitlement resource",
                    "schema": "urn:okta:scim:schemas:core:1.0:Entitlement",
                    "endpoint": "/Entitlements"
                }
            ]
        }
        """;
	
	
	@Test
	final void testDefaultGet() throws Exception {
        MvcResult result = mockMvc.perform(get("/archer/scim/v2/ResourceTypes"))
                .andExpect(status().isOk())
                .andExpect(content().contentType("application/json"))
                .andReturn();
        
        String actualJson = result.getResponse().getContentAsString().trim();

        assertEquals(EXPECTED_JSON.trim(), actualJson, 
            "The controller method should return the exact, hardcoded Schema JSON string.");
    }

}
