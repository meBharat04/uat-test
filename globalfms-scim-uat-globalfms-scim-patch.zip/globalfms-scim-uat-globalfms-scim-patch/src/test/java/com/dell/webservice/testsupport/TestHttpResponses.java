package com.dell.webservice.testsupport;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpHeaders;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.net.ssl.SSLSession;

/**
 * Builds concrete {@link HttpResponse} instances for tests, avoiding Mockito's
 * nested-stubbing trap when a mock-creating helper is used inside {@code when(...)}.
 */
public final class TestHttpResponses {

	private TestHttpResponses() {
	}

	public static HttpResponse<String> stringResponse(int status, String body) {
		return stringResponse(status, body, Map.of());
	}

	public static HttpResponse<String> stringResponse(int status, String body, Map<String, List<String>> headers) {
		return new HttpResponse<>() {
			@Override
			public int statusCode() {
				return status;
			}

			@Override
			public String body() {
				return body;
			}

			@Override
			public HttpRequest request() {
				return null;
			}

			@Override
			public Optional<HttpResponse<String>> previousResponse() {
				return Optional.empty();
			}

			@Override
			public HttpHeaders headers() {
				return HttpHeaders.of(headers, (k, v) -> true);
			}

			@Override
			public Optional<SSLSession> sslSession() {
				return Optional.empty();
			}

			@Override
			public URI uri() {
				return null;
			}

			@Override
			public HttpClient.Version version() {
				return HttpClient.Version.HTTP_1_1;
			}
		};
	}
}
