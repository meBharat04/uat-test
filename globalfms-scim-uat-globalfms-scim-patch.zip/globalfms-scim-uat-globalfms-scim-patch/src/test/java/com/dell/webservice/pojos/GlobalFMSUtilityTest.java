package com.dell.webservice.pojos;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.URISyntaxException;
import java.net.UnknownHostException;

import static org.junit.jupiter.api.Assertions.*;

class GlobalFMSUtilityTest {

    private GlobalFMSUtility utility;

    @BeforeEach
    void setUp() {
        utility = new GlobalFMSUtility();
    }

    // ==================== URL Validation Tests ====================

    @Test
    void validateUrl_NullUrl_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> utility.validateUrl(null));
    }

    @Test
    void validateUrl_EmptyUrl_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> utility.validateUrl(""));
    }

    @Test
    void validateUrl_BlankUrl_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> utility.validateUrl("   "));
    }

    @Test
    void validateUrl_HttpUrl_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> utility.validateUrl("http://api.example.com"));
    }

    @Test
    void validateUrl_NoScheme_ThrowsException() {
        assertThrows(Exception.class, () -> utility.validateUrl("api.example.com"));
    }

    // ==================== Basic Auth Decoding Tests ====================

    @Test
    void decodeBasicAuth_NullHeader_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> GlobalFMSUtility.decodeBasicAuth(null));
    }

    @Test
    void decodeBasicAuth_WrongPrefix_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> GlobalFMSUtility.decodeBasicAuth("Bearer token"));
    }

    @Test
    void decodeBasicAuth_ValidHeader_Decodes() {
        // "user:pass" encoded in Base64 is "dXNlcjpwYXNz"
        String decoded = GlobalFMSUtility.decodeBasicAuth("Basic dXNlcjpwYXNz");
        assertEquals("user:pass", decoded);
    }

    @Test
    void decodeBasicAuth_EmptyCredentials_Decodes() {
        // ":" encoded in Base64 is "Og=="
        String decoded = GlobalFMSUtility.decodeBasicAuth("Basic Og==");
        assertEquals(":", decoded);
    }

    // ==================== Extract Credentials Tests ====================

    @Test
    void extractCredentials_ValidHeader_ReturnsArray() {
        // "user:pass" encoded in Base64 is "dXNlcjpwYXNz"
        String[] creds = GlobalFMSUtility.extractCredentials("Basic dXNlcjpwYXNz");

        assertEquals(2, creds.length);
        assertEquals("user", creds[0]);
        assertEquals("pass", creds[1]);
    }

    @Test
    void extractCredentials_PasswordWithColon_HandlesCorrectly() {
        // "user:pass:word" encoded in Base64 is "dXNlcjpwYXNzOndvcmQ="
        String[] creds = GlobalFMSUtility.extractCredentials("Basic dXNlcjpwYXNzOndvcmQ=");

        assertEquals(2, creds.length);
        assertEquals("user", creds[0]);
        assertEquals("pass:word", creds[1]);
    }

    @Test
    void extractCredentials_NoColon_ThrowsException() {
        // "userpass" (no colon) encoded in Base64 is "dXNlcnBhc3M="
        assertThrows(IllegalArgumentException.class, () -> GlobalFMSUtility.extractCredentials("Basic dXNlcnBhc3M="));
    }

    @Test
    void extractCredentials_NullHeader_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> GlobalFMSUtility.extractCredentials(null));
    }

    // ==================== URL Scheme Tests ====================

    @Test
    void urlScheme_Https_Valid() {
        String url = "https://api.example.com";
        assertTrue(url.startsWith("https://"));
    }

    @Test
    void urlScheme_Http_Invalid() {
        String url = "http://api.example.com";
        assertFalse(url.startsWith("https://"));
    }

    // ==================== Internal IP Detection Tests ====================

    @Test
    void internalIp_Localhost_IsInternal() {
        String ip = "127.0.0.1";
        assertTrue(ip.startsWith("127."));
    }

    @Test
    void internalIp_PrivateClassA_IsInternal() {
        String ip = "10.0.0.1";
        assertTrue(ip.startsWith("10."));
    }

    @Test
    void internalIp_PrivateClassB_IsInternal() {
        String ip = "172.16.0.1";
        assertTrue(ip.startsWith("172.16.") || ip.startsWith("172.17."));
    }

    @Test
    void internalIp_PrivateClassC_IsInternal() {
        String ip = "192.168.1.1";
        assertTrue(ip.startsWith("192.168."));
    }

    @Test
    void internalIp_CloudMetadata_IsInternal() {
        String ip = "169.254.169.254";
        assertEquals("169.254.169.254", ip);
    }

    // ==================== Pattern Matching Tests ====================

    @Test
    void appNamePattern_ValidName_Matches() {
        String pattern = "^[a-zA-Z0-9_-]{1,50}$";
        assertTrue("globalfms".matches(pattern));
        assertTrue("global-fms".matches(pattern));
        assertTrue("global_fms".matches(pattern));
        assertTrue("GlobalFMS123".matches(pattern));
    }

    @Test
    void appNamePattern_InvalidName_DoesNotMatch() {
        String pattern = "^[a-zA-Z0-9_-]{1,50}$";
        assertFalse("".matches(pattern));
        assertFalse("global fms".matches(pattern));
        assertFalse("global/fms".matches(pattern));
    }

    // ==================== Base64 Encoding/Decoding Tests ====================

    @Test
    void base64_EncodeDecode_RoundTrip() {
        String original = "username:password";
        String encoded = java.util.Base64.getEncoder().encodeToString(original.getBytes());
        String decoded = new String(java.util.Base64.getDecoder().decode(encoded));

        assertEquals(original, decoded);
    }

    @Test
    void base64_SpecialCharacters_Handled() {
        String original = "user@domain.com:p@ss!word#123";
        String encoded = java.util.Base64.getEncoder().encodeToString(original.getBytes());
        String decoded = new String(java.util.Base64.getDecoder().decode(encoded));

        assertEquals(original, decoded);
    }
}
