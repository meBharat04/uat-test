package com.dell.webservice.controller;

import tools.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ScimResourceListTest {

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
    }

    // ==================== Basic Functionality Tests ====================

    @Test
    void defaultConstructor_CreatesEmptyList() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();

        assertNull(resourceList.getSchemas());
        assertEquals(0, resourceList.getTotalResults());
        assertEquals(0, resourceList.getItemsPerPage());
        assertNotNull(resourceList.getResources());
        assertTrue(resourceList.getResources().isEmpty());
    }

    @Test
    void setSchemas_StoresSchemas() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));

        assertNotNull(resourceList.getSchemas());
        assertTrue(resourceList.getSchemas().contains("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
    }

    @Test
    void setTotalResults_StoresTotalResults() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setTotalResults(100);

        assertEquals(100, resourceList.getTotalResults());
    }

    @Test
    void setItemsPerPage_StoresItemsPerPage() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setItemsPerPage(25);

        assertEquals(25, resourceList.getItemsPerPage());
    }

    @Test
    void setStartIndex_StoresStartIndex() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setStartIndex(51);

        assertEquals(51, resourceList.getStartIndex());
    }

    @Test
    void setResources_StoresResources() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        List<ScimUserV2> users = List.of(
                createTestUser("1", "user1"),
                createTestUser("2", "user2")
        );
        resourceList.setResources(users);

        assertNotNull(resourceList.getResources());
        assertEquals(2, resourceList.getResources().size());
    }

    // ==================== Serialization Tests ====================

    @Test
    void serialize_EmptyList_ProducesValidJson() throws Exception {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
        resourceList.setTotalResults(0);
        resourceList.setItemsPerPage(0);
        resourceList.setStartIndex(1);
        resourceList.setResources(new ArrayList<>());

        String json = objectMapper.writeValueAsString(resourceList);

        assertNotNull(json);
        assertTrue(json.contains("\"totalResults\":0"));
        assertTrue(json.contains("\"itemsPerPage\":0"));
        assertTrue(json.contains("\"startIndex\":1"));
    }

    @Test
    void serialize_WithUsers_IncludesResources() throws Exception {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
        resourceList.setTotalResults(2);
        resourceList.setItemsPerPage(2);
        resourceList.setStartIndex(1);
        resourceList.setResources(List.of(
                createTestUser("1", "user1"),
                createTestUser("2", "user2")
        ));

        String json = objectMapper.writeValueAsString(resourceList);

        assertTrue(json.contains("\"totalResults\":2"));
        assertTrue(json.contains("\"id\":\"1\""));
        assertTrue(json.contains("\"id\":\"2\""));
    }

    @Test
    void serialize_Resources_UsesCapitalR() throws Exception {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
        resourceList.setResources(List.of(createTestUser("1", "user1")));

        String json = objectMapper.writeValueAsString(resourceList);

        assertTrue(json.contains("\"Resources\""));
    }

    // ==================== Pagination Tests ====================

    @Test
    void pagination_FirstPage() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setTotalResults(100);
        resourceList.setItemsPerPage(25);
        resourceList.setStartIndex(1);
        List<ScimUserV2> users = createUserList(25, 0);
        resourceList.setResources(users);

        assertEquals(100, resourceList.getTotalResults());
        assertEquals(25, resourceList.getItemsPerPage());
        assertEquals(1, resourceList.getStartIndex());
        assertEquals(25, resourceList.getResources().size());
    }

    @Test
    void pagination_SecondPage() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setTotalResults(100);
        resourceList.setItemsPerPage(25);
        resourceList.setStartIndex(26);
        List<ScimUserV2> users = createUserList(25, 25);
        resourceList.setResources(users);

        assertEquals(100, resourceList.getTotalResults());
        assertEquals(25, resourceList.getItemsPerPage());
        assertEquals(26, resourceList.getStartIndex());
        assertEquals(25, resourceList.getResources().size());
    }

    @Test
    void pagination_LastPage_PartialResults() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setTotalResults(100);
        resourceList.setItemsPerPage(10);
        resourceList.setStartIndex(91);
        List<ScimUserV2> users = createUserList(10, 90);
        resourceList.setResources(users);

        assertEquals(100, resourceList.getTotalResults());
        assertEquals(10, resourceList.getItemsPerPage());
        assertEquals(91, resourceList.getStartIndex());
        assertEquals(10, resourceList.getResources().size());
    }

    @Test
    void pagination_LargeTotalResults() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setTotalResults(300000);
        resourceList.setItemsPerPage(100);
        resourceList.setStartIndex(1);
        List<ScimUserV2> users = createUserList(100, 0);
        resourceList.setResources(users);

        assertEquals(300000, resourceList.getTotalResults());
        assertEquals(100, resourceList.getItemsPerPage());
    }

    // ==================== Generic Type Tests ====================

    @Test
    void genericType_SupportsScimUserV2() {
        ScimResourceList<ScimUserV2> userList = new ScimResourceList<>();
        userList.setResources(List.of(createTestUser("1", "user1")));

        assertEquals(1, userList.getResources().size());
        assertEquals("user1", userList.getResources().get(0).getUserName());
    }

    // ==================== Null Handling Tests ====================

    @Test
    void nullResources_CanBeSet() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setResources(null);

        assertNull(resourceList.getResources());
    }

    @Test
    void emptyResources_Allowed() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setResources(new ArrayList<>());

        assertNotNull(resourceList.getResources());
        assertTrue(resourceList.getResources().isEmpty());
    }

    // ==================== SCIM Compliance Tests ====================

    @Test
    void scimCompliance_RequiredFieldsPresent() throws Exception {
        ScimResourceList<ScimUserV2> resourceList = createCompliantResourceList();

        String json = objectMapper.writeValueAsString(resourceList);

        assertTrue(json.contains("\"schemas\""));
        assertTrue(json.contains("\"totalResults\""));
        assertTrue(json.contains("\"Resources\""));
    }

    @Test
    void scimCompliance_CorrectSchemaUri() throws Exception {
        ScimResourceList<ScimUserV2> resourceList = createCompliantResourceList();

        String json = objectMapper.writeValueAsString(resourceList);

        assertTrue(json.contains("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
    }

    @Test
    void scimCompliance_PaginationFields() throws Exception {
        ScimResourceList<ScimUserV2> resourceList = createCompliantResourceList();
        resourceList.setStartIndex(1);
        resourceList.setItemsPerPage(100);

        String json = objectMapper.writeValueAsString(resourceList);

        assertTrue(json.contains("\"startIndex\""));
        assertTrue(json.contains("\"itemsPerPage\""));
    }

    // ==================== Helper Methods ====================

    private ScimUserV2 createTestUser(String id, String userName) {
        ScimUserV2 user = new ScimUserV2();
        user.setId(id);
        user.setUserName(userName);
        user.setDisplayName(userName);
        user.setActive(true);
        return user;
    }

    private List<ScimUserV2> createUserList(int count, int startIndex) {
        List<ScimUserV2> users = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            int index = startIndex + i;
            users.add(createTestUser(String.valueOf(index), "user" + index));
        }
        return users;
    }

    private ScimResourceList<ScimUserV2> createCompliantResourceList() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
        resourceList.setTotalResults(1);
        resourceList.setItemsPerPage(1);
        resourceList.setStartIndex(1);
        resourceList.setResources(List.of(createTestUser("1", "user1")));
        return resourceList;
    }
}
