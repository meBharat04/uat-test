package com.dell.webservice.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@WebMvcTest(GroupController.class)
@WithMockUser
class GroupControllerTest {

	@Autowired
    private MockMvc mockMvc;

    // The expected JSON content from the controller, cleaned up for comparison
    private static final String EXPECTED_JSON = """
			{
			  "schemas": [
				"urn:ietf:params:scim:api:messages:2.0:ListResponse"
			  ],
			  "totalResults": 0,
			  "startIndex": 0,
			  "itemsPerPage": 0,
			  "Resources": []
			}
		""";
	
	
	@Test
	final void testDefaultGet() throws Exception {
        MvcResult result = mockMvc.perform(get("/globalfms/scim/v2/Groups"))
                .andExpect(status().isOk()) 
                .andExpect(content().contentType("text/plain;charset=UTF-8"))
                .andReturn();


        String actualJson = result.getResponse().getContentAsString().trim();
        
        assertEquals(EXPECTED_JSON.trim(), actualJson, 
            "The controller method should return the exact, hardcoded Schema JSON string.");
    }

}