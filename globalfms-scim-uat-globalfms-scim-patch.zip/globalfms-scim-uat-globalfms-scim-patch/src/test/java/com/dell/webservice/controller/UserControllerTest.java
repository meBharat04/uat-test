package com.dell.webservice.controller;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.junit.jupiter.api.Assertions.*;

class UserControllerTest {

    private static final Pattern APP_NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_-]{1,50}$");
    private static final Pattern ID_PATTERN = Pattern.compile("^[a-zA-Z0-9@._-]{1,100}$");

    // ==================== Filter Parsing Tests ====================

    @Test
    void parseFilter_UserNameEq_Valid() {
        String filter = "userName eq \"testuser\"";
        assertTrue(filter.contains("userName eq"));

        String username = filter.replaceAll("^userName\\s+eq\\s+\"", "").replace("\"", "");
        assertEquals("testuser", username);
    }

    @Test
    void parseFilter_UserNameEq_WithEmail() {
        String filter = "userName eq \"test.user@dell.com\"";

        String username = filter.replaceAll("^userName\\s+eq\\s+\"", "").replace("\"", "");
        assertEquals("test.user@dell.com", username);
    }

    @Test
    void parseFilter_UserNameEq_WithUnderscore() {
        String filter = "userName eq \"Rohini_Bonam\"";

        String username = filter.replaceAll("^userName\\s+eq\\s+\"", "").replace("\"", "");
        assertEquals("Rohini_Bonam", username);
    }

    @Test
    void parseFilter_LastModifiedGt_Detected() {
        String filter = "meta.lastModified gt \"2026-06-19T00:00:00Z\"";

        assertTrue(filter.contains("meta.lastModified"));
        assertFalse(filter.contains("userName eq"));
    }

    @Test
    void parseFilter_LastModifiedGe_Detected() {
        String filter = "meta.lastModified ge \"2026-06-19T00:00:00Z\"";

        assertTrue(filter.contains("meta.lastModified"));
    }

    // ==================== Validation Tests ====================

    @Test
    void validateAppName_Valid() {
        assertTrue(APP_NAME_PATTERN.matcher("globalfms").matches());
        assertTrue(APP_NAME_PATTERN.matcher("global-fms").matches());
        assertTrue(APP_NAME_PATTERN.matcher("global_fms").matches());
        assertTrue(APP_NAME_PATTERN.matcher("GlobalFMS123").matches());
    }

    @Test
    void validateAppName_Invalid() {
        assertFalse(APP_NAME_PATTERN.matcher("").matches());
        assertFalse(APP_NAME_PATTERN.matcher("global fms").matches());
        assertFalse(APP_NAME_PATTERN.matcher("global/fms").matches());
        assertFalse(APP_NAME_PATTERN.matcher("a".repeat(51)).matches());
    }

    @Test
    void validateId_Valid() {
        assertTrue(ID_PATTERN.matcher("123").matches());
        assertTrue(ID_PATTERN.matcher("user@domain.com").matches());
        assertTrue(ID_PATTERN.matcher("user_name").matches());
        assertTrue(ID_PATTERN.matcher("user-name").matches());
    }

    @Test
    void validateId_Invalid() {
        assertFalse(ID_PATTERN.matcher("").matches());
        assertFalse(ID_PATTERN.matcher("user name").matches());
        assertFalse(ID_PATTERN.matcher("a".repeat(101)).matches());
    }

    @Test
    void validateUser_NullUser_ThrowsException() {
        ScimUserV2 user = null;
        assertNull(user);
    }

    @Test
    void validateUser_NullUserName_Invalid() {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName(null);

        assertTrue(user.getUserName() == null || (user.getUserName() != null && user.getUserName().isBlank()));
    }

    @Test
    void validateUser_BlankUserName_Invalid() {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName("   ");

        assertTrue(user.getUserName().isBlank());
    }

    @Test
    void validateAuthHeader_Valid() {
        String authHeader = "Basic dXNlcm5hbWU6cGFzc3dvcmQ=";

        assertNotNull(authHeader);
        assertFalse(authHeader.isBlank());
        assertTrue(authHeader.startsWith("Basic "));
    }

    @Test
    void validateAuthHeader_NullHeader_Invalid() {
        String authHeader = null;
        assertTrue(authHeader == null || authHeader.isBlank());
    }

    @Test
    void validateAuthHeader_WrongPrefix_Invalid() {
        String authHeader = "Bearer token123";
        assertFalse(authHeader.startsWith("Basic "));
    }

    // ==================== ScimResourceList Tests ====================

    @Test
    void resourceList_SetSchemas() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setSchemas(Set.of("urn:ietf:params:scim:api:messages:2.0:ListResponse"));

        assertTrue(resourceList.getSchemas().contains("urn:ietf:params:scim:api:messages:2.0:ListResponse"));
    }

    @Test
    void resourceList_SetTotalResults() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setTotalResults(100);

        assertEquals(100, resourceList.getTotalResults());
    }

    @Test
    void resourceList_SetItemsPerPage() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setItemsPerPage(25);

        assertEquals(25, resourceList.getItemsPerPage());
    }

    @Test
    void resourceList_SetStartIndex() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        resourceList.setStartIndex(1);

        assertEquals(1, resourceList.getStartIndex());
    }

    @Test
    void resourceList_SetResources() {
        ScimResourceList<ScimUserV2> resourceList = new ScimResourceList<>();
        List<ScimUserV2> users = List.of(createTestUser("1", "user1"), createTestUser("2", "user2"));
        resourceList.setResources(users);

        assertEquals(2, resourceList.getResources().size());
    }

    // ==================== ScimUserV2 Tests ====================

    @Test
    void scimUser_CreateWithEntitlements() {
        ScimUserV2 user = createTestUser("123", "testuser");
        user.setEntitlements(List.of(
                new ScimUserV2.Entitlement("Admin", "Admin", "Entitlement", null),
                new ScimUserV2.Entitlement("User", "User", "Entitlement", null)
        ));

        assertEquals(2, user.getEntitlements().size());
        assertEquals("Admin", user.getEntitlements().get(0).getValue());
    }

    @Test
    void scimUser_ActiveDefaultsToNull() {
        ScimUserV2 user = new ScimUserV2();
        assertNull(user.getActive());
    }

    @Test
    void scimUser_SetActiveTrue() {
        ScimUserV2 user = new ScimUserV2();
        user.setActive(true);
        assertTrue(user.getActive());
    }

    @Test
    void scimUser_SetActiveFalse() {
        ScimUserV2 user = new ScimUserV2();
        user.setActive(false);
        assertFalse(user.getActive());
    }

    // ==================== Pagination Calculation Tests ====================

    @Test
    void pagination_DefaultValues() {
        Integer startIndex = null;
        Integer count = null;

        int actualStart = (startIndex != null && startIndex > 0) ? startIndex : 1;
        int actualCount = (count != null && count > 0) ? Math.min(count, 1000) : 100;

        assertEquals(1, actualStart);
        assertEquals(100, actualCount);
    }

    @Test
    void pagination_ProvidedValues() {
        Integer startIndex = 51;
        Integer count = 50;

        int actualStart = (startIndex != null && startIndex > 0) ? startIndex : 1;
        int actualCount = (count != null && count > 0) ? Math.min(count, 1000) : 100;

        assertEquals(51, actualStart);
        assertEquals(50, actualCount);
    }

    @Test
    void pagination_CountCappedAt1000() {
        Integer count = 5000;

        int actualCount = (count != null && count > 0) ? Math.min(count, 1000) : 100;

        assertEquals(1000, actualCount);
    }

    // ==================== Filter Pattern Matching Tests ====================

    @Test
    void filterPattern_MatchesUserNameFilter() {
        String filter = "userName eq \"testuser\"";
        Pattern filterPattern = Pattern.compile(
                "^([\\w.]+)\\s+(eq|gt|ge|lt|le)\\s+\"([^\"]+)\"$",
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = filterPattern.matcher(filter.trim());

        assertTrue(matcher.matches());
        assertEquals("userName", matcher.group(1));
        assertEquals("eq", matcher.group(2));
        assertEquals("testuser", matcher.group(3));
    }

    @Test
    void filterPattern_MatchesLastModifiedFilter() {
        String filter = "meta.lastModified gt \"2026-06-19T00:00:00Z\"";
        Pattern filterPattern = Pattern.compile(
                "^([\\w.]+)\\s+(eq|gt|ge|lt|le)\\s+\"([^\"]+)\"$",
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = filterPattern.matcher(filter.trim());

        assertTrue(matcher.matches());
        assertEquals("meta.lastModified", matcher.group(1));
        assertEquals("gt", matcher.group(2));
        assertEquals("2026-06-19T00:00:00Z", matcher.group(3));
    }

    @Test
    void filterPattern_DoesNotMatchInvalidFilter() {
        String filter = "invalid filter format";
        Pattern filterPattern = Pattern.compile(
                "^([\\w.]+)\\s+(eq|gt|ge|lt|le)\\s+\"([^\"]+)\"$",
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = filterPattern.matcher(filter.trim());

        assertFalse(matcher.matches());
    }

    // ==================== PATCH / ScimPatchOp Tests ====================

    @Test
    void scimPatchOp_ParsesAddOperation() throws Exception {
        String json = "{\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"],"
                + "\"Operations\":[{\"op\":\"add\",\"path\":\"entitlements\","
                + "\"value\":[{\"value\":\"Admin\",\"type\":\"Entitlement\"},"
                + "{\"value\":\"ReadOnly\",\"type\":\"Entitlement\"}]}]}";
        tools.jackson.databind.ObjectMapper mapper =
                new tools.jackson.databind.ObjectMapper();
        ScimPatchOp patchOp = mapper.readValue(json, ScimPatchOp.class);

        assertNotNull(patchOp);
        assertEquals(1, patchOp.getOperations().size());
        assertEquals("add", patchOp.getOperations().get(0).getOp());
        assertTrue(patchOp.getOperations().get(0).getValue().isArray());
        assertEquals(2, patchOp.getOperations().get(0).getValue().size());
    }

    @Test
    void scimPatchOp_ParsesRemoveOperation() throws Exception {
        String json = "{\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"],"
                + "\"Operations\":[{\"op\":\"remove\","
                + "\"path\":\"entitlements[value eq \\\"Admin\\\" and type eq \\\"Entitlement\\\"]\"}]}";
        tools.jackson.databind.ObjectMapper mapper =
                new tools.jackson.databind.ObjectMapper();
        ScimPatchOp patchOp = mapper.readValue(json, ScimPatchOp.class);

        assertEquals("remove", patchOp.getOperations().get(0).getOp());
        assertTrue(patchOp.getOperations().get(0).getPath().contains("entitlements"));
    }

    @Test
    void scimPatchOp_ExtractValueFromRemovePath() {
        String path = "entitlements[value eq \"Admin\" and type eq \"Entitlement\"]";
        java.util.regex.Pattern valuePattern =
                java.util.regex.Pattern.compile("value\\s+eq\\s+\"([^\"]+)\"",
                        java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher m = valuePattern.matcher(path);
        assertTrue(m.find());
        assertEquals("Admin", m.group(1));
    }

    @Test
    void scimPatchOp_ExtractTypeFromRemovePath() {
        String path = "entitlements[value eq \"Admin\" and type eq \"Entitlement\"]";
        java.util.regex.Pattern typePattern =
                java.util.regex.Pattern.compile("type\\s+eq\\s+\"([^\"]+)\"",
                        java.util.regex.Pattern.CASE_INSENSITIVE);
        java.util.regex.Matcher m = typePattern.matcher(path);
        assertTrue(m.find());
        assertEquals("Entitlement", m.group(1));
    }

    @Test
    void scimPatchOp_NonEntitlementPath_ShouldBeRejected() {
        String path = "userName";
        assertFalse(path.toLowerCase().startsWith("entitlements"));
    }

    @Test
    void scimPatchOp_EntitlementPath_ShouldBeAccepted() {
        assertTrue("entitlements".toLowerCase().startsWith("entitlements"));
        assertTrue("entitlements[value eq \"Admin\"]".toLowerCase().startsWith("entitlements"));
    }

    @Test
    void scimPatchOp_ValidatesSchema() throws Exception {
        String json = "{\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"],"
                + "\"Operations\":[{\"op\":\"add\",\"path\":\"entitlements\","
                + "\"value\":[{\"value\":\"Admin\"}]}]}";
        tools.jackson.databind.ObjectMapper mapper =
                new tools.jackson.databind.ObjectMapper();
        ScimPatchOp patchOp = mapper.readValue(json, ScimPatchOp.class);
        assertTrue(patchOp.getSchemas().contains("urn:ietf:params:scim:api:messages:2.0:PatchOp"));
    }

    @Test
    void scimPatchOp_BatchesMultipleRolesForAddRequest() {
        // Simulates building the entitlementArray string for a batch AddUserRole call.
        java.util.List<String> rolesToAdd = java.util.List.of("\"Admin\"", "\"ReadOnly\"", "\"Auditor\"");
        String addArray = String.join(",", rolesToAdd);
        assertEquals("\"Admin\",\"ReadOnly\",\"Auditor\"", addArray);
    }

    @Test
    void scimPatchOp_BatchesMultipleRolesForRemoveRequest() {
        java.util.List<String> rolesToRemove = java.util.List.of("\"OldRole1\"", "\"OldRole2\"");
        String removeArray = String.join(",", rolesToRemove);
        assertEquals("\"OldRole1\",\"OldRole2\"", removeArray);
    }

    @Test
    void scimPatchOp_SimultaneousAddAndRemove() throws Exception {
        String json = "{\"schemas\":[\"urn:ietf:params:scim:api:messages:2.0:PatchOp\"],"
                + "\"Operations\":["
                + "{\"op\":\"add\",\"path\":\"entitlements\","
                + "\"value\":[{\"value\":\"NewRole\",\"type\":\"Entitlement\"}]},"
                + "{\"op\":\"remove\","
                + "\"path\":\"entitlements[value eq \\\"OldRole\\\" and type eq \\\"Entitlement\\\"]\"}]}";
        tools.jackson.databind.ObjectMapper mapper =
                new tools.jackson.databind.ObjectMapper();
        ScimPatchOp patchOp = mapper.readValue(json, ScimPatchOp.class);

        assertEquals(2, patchOp.getOperations().size());
        assertEquals("add", patchOp.getOperations().get(0).getOp());
        assertEquals("remove", patchOp.getOperations().get(1).getOp());
    }

    // ==================== Helper Methods ====================

    private ScimUserV2 createTestUser(String id, String userName) {
        ScimUserV2 user = new ScimUserV2();
        user.setId(id);
        user.setUserName(userName);
        user.setDisplayName(userName);
        user.setActive(true);
        user.setSchemas(Set.of(
                "urn:ietf:params:scim:schemas:core:2.0:User",
                "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
        ));
        user.setMeta(new ScimUserV2.ResourceMeta("User"));
        user.setEntitlements(new ArrayList<>());
        return user;
    }
}
