package com.dell.webservice.cache;

import com.dell.webservice.controller.ScimUserV2;
import com.dell.webservice.cache.UserCacheService.PaginatedResult;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class UserCacheServiceTest {

    // ==================== PaginatedResult Tests ====================

    @Test
    void paginatedResult_Constructor_SetsAllFields() {
        List<ScimUserV2> users = createUserList(10);
        PaginatedResult<ScimUserV2> result = new PaginatedResult<>(users, 100, 1, 10);

        assertEquals(10, result.getItems().size());
        assertEquals(100, result.getTotalResults());
        assertEquals(1, result.getStartIndex());
        assertEquals(10, result.getItemsPerPage());
    }

    @Test
    void paginatedResult_EmptyList() {
        List<ScimUserV2> users = new ArrayList<>();
        PaginatedResult<ScimUserV2> result = new PaginatedResult<>(users, 0, 1, 0);

        assertTrue(result.getItems().isEmpty());
        assertEquals(0, result.getTotalResults());
        assertEquals(1, result.getStartIndex());
        assertEquals(0, result.getItemsPerPage());
    }

    @Test
    void paginatedResult_LargeDataset() {
        List<ScimUserV2> users = createUserList(100);
        PaginatedResult<ScimUserV2> result = new PaginatedResult<>(users, 300000, 1, 100);

        assertEquals(100, result.getItems().size());
        assertEquals(300000, result.getTotalResults());
    }

    // ==================== Pagination Logic Tests ====================

    @Test
    void pagination_FirstPage_CorrectSlice() {
        List<ScimUserV2> allUsers = createUserList(100);

        int startIndex = 1;
        int count = 25;
        int fromIndex = Math.max(0, startIndex - 1);
        int toIndex = Math.min(fromIndex + count, allUsers.size());

        List<ScimUserV2> page = allUsers.subList(fromIndex, toIndex);

        assertEquals(25, page.size());
        assertEquals("user0", page.get(0).getUserName());
        assertEquals("user24", page.get(24).getUserName());
    }

    @Test
    void pagination_MiddlePage_CorrectSlice() {
        List<ScimUserV2> allUsers = createUserList(100);

        int startIndex = 26;
        int count = 25;
        int fromIndex = Math.max(0, startIndex - 1);
        int toIndex = Math.min(fromIndex + count, allUsers.size());

        List<ScimUserV2> page = allUsers.subList(fromIndex, toIndex);

        assertEquals(25, page.size());
        assertEquals("user25", page.get(0).getUserName());
        assertEquals("user49", page.get(24).getUserName());
    }

    @Test
    void pagination_LastPage_PartialResults() {
        List<ScimUserV2> allUsers = createUserList(100);

        int startIndex = 91;
        int count = 25;
        int fromIndex = Math.max(0, startIndex - 1);
        int toIndex = Math.min(fromIndex + count, allUsers.size());

        List<ScimUserV2> page = allUsers.subList(fromIndex, toIndex);

        assertEquals(10, page.size());
        assertEquals("user90", page.get(0).getUserName());
        assertEquals("user99", page.get(9).getUserName());
    }

    @Test
    void pagination_BeyondDataset_EmptyList() {
        List<ScimUserV2> allUsers = createUserList(100);

        int startIndex = 200;
        int fromIndex = Math.max(0, startIndex - 1);

        List<ScimUserV2> page;
        if (fromIndex >= allUsers.size()) {
            page = new ArrayList<>();
        } else {
            int toIndex = Math.min(fromIndex + 25, allUsers.size());
            page = allUsers.subList(fromIndex, toIndex);
        }

        assertTrue(page.isEmpty());
    }

    @Test
    void pagination_ZeroStartIndex_TreatedAsOne() {
        List<ScimUserV2> allUsers = createUserList(100);

        int startIndex = 0;
        int count = 10;
        int start = (startIndex > 0) ? startIndex : 1;
        int fromIndex = Math.max(0, start - 1);
        int toIndex = Math.min(fromIndex + count, allUsers.size());

        List<ScimUserV2> page = allUsers.subList(fromIndex, toIndex);

        assertEquals(10, page.size());
        assertEquals("user0", page.get(0).getUserName());
    }

    @Test
    void pagination_NegativeStartIndex_TreatedAsOne() {
        List<ScimUserV2> allUsers = createUserList(100);

        int startIndex = -5;
        int count = 10;
        int start = (startIndex > 0) ? startIndex : 1;
        int fromIndex = Math.max(0, start - 1);
        int toIndex = Math.min(fromIndex + count, allUsers.size());

        List<ScimUserV2> page = allUsers.subList(fromIndex, toIndex);

        assertEquals(10, page.size());
        assertEquals("user0", page.get(0).getUserName());
    }

    @Test
    void pagination_CountExceedsMax_CappedAt1000() {
        int requestedCount = 5000;
        int maxCount = 1000;
        int actualCount = Math.min(requestedCount, maxCount);

        assertEquals(1000, actualCount);
    }

    // ==================== Filter Parsing Tests ====================

    @Test
    void filter_LastModifiedGt_ParsesCorrectly() {
        String filter = "meta.lastModified gt \"2026-06-19T00:00:00Z\"";

        assertTrue(filter.contains("meta.lastModified"));
        assertTrue(filter.contains("gt"));

        String operator = filter.contains(" gt ") ? "gt" : "ge";
        assertEquals("gt", operator);

        int startIdx = filter.indexOf("\"") + 1;
        int endIdx = filter.lastIndexOf("\"");
        String dateStr = filter.substring(startIdx, endIdx);

        assertEquals("2026-06-19T00:00:00Z", dateStr);
    }

    @Test
    void filter_LastModifiedGe_ParsesCorrectly() {
        String filter = "meta.lastModified ge \"2026-06-19T00:00:00Z\"";

        String operator = filter.contains(" gt ") ? "gt" : "ge";
        assertEquals("ge", operator);
    }

    @Test
    void filter_RemoveZSuffix() {
        String dateStr = "2026-06-19T00:00:00Z";
        if (dateStr.endsWith("Z")) {
            dateStr = dateStr.substring(0, dateStr.length() - 1);
        }

        assertEquals("2026-06-19T00:00:00", dateStr);
    }

    // ==================== Incremental Import Tests ====================

    @Test
    void incrementalImport_TotalResults_TenPercent() {
        int totalUsers = 1000;
        int reportedTotal = (int) Math.ceil(totalUsers * 0.10);

        assertEquals(100, reportedTotal);
    }

    @Test
    void incrementalImport_TotalResults_LargeDataset() {
        int totalUsers = 300000;
        int reportedTotal = (int) Math.ceil(totalUsers * 0.10);

        assertEquals(30000, reportedTotal);
    }

    @Test
    void incrementalImport_TotalResults_RoundsUp() {
        int totalUsers = 105;
        int reportedTotal = (int) Math.ceil(totalUsers * 0.10);

        assertEquals(11, reportedTotal);
    }

    // ==================== getUserByUserId Logic Tests ====================

    @Test
    void getUserByUserId_FoundOnFirstFetch() {
        List<ScimUserV2> users = createUserListWithUserId(5);

        ScimUserV2 found = users.stream()
                .filter(u -> u.getEnterpriseInfo() != null && "userId2".equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        assertNotNull(found);
        assertEquals("user2", found.getUserName());
        assertEquals("userId2", found.getEnterpriseInfo().getUserId());
    }

    @Test
    void getUserByUserId_NotFound_ReturnsNull() {
        List<ScimUserV2> users = createUserListWithUserId(5);

        ScimUserV2 found = users.stream()
                .filter(u -> u.getEnterpriseInfo() != null && "nonExistentId".equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        assertNull(found);
    }

    @Test
    void getUserByUserId_NullEnterpriseInfo_SkippedSafely() {
        List<ScimUserV2> users = new ArrayList<>();

        ScimUserV2 userWithoutInfo = new ScimUserV2();
        userWithoutInfo.setId("userId0");
        userWithoutInfo.setUserName("user0");
        userWithoutInfo.setEnterpriseInfo(null);
        users.add(userWithoutInfo);

        ScimUserV2 found = users.stream()
                .filter(u -> u.getEnterpriseInfo() != null && "userId0".equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        assertNull(found);
    }

    @Test
    void getUserByUserId_RetryFindsUser() {
        // Simulates: first fetch returns empty, second fetch returns the user
        List<ScimUserV2> emptyList = new ArrayList<>();
        List<ScimUserV2> populatedList = createUserListWithUserId(3);

        String targetUserId = "userId1";

        ScimUserV2 firstAttempt = emptyList.stream()
                .filter(u -> u.getEnterpriseInfo() != null && targetUserId.equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        assertNull(firstAttempt);

        ScimUserV2 secondAttempt = populatedList.stream()
                .filter(u -> u.getEnterpriseInfo() != null && targetUserId.equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        assertNotNull(secondAttempt);
        assertEquals("user1", secondAttempt.getUserName());
    }

    @Test
    void getUserByUserId_NotFoundAfterRetry_ReturnsNull() {
        List<ScimUserV2> users = createUserListWithUserId(3);

        String targetUserId = "nonExistentId";

        // Both first and retry fetch fail
        ScimUserV2 firstAttempt = users.stream()
                .filter(u -> u.getEnterpriseInfo() != null && targetUserId.equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        ScimUserV2 secondAttempt = users.stream()
                .filter(u -> u.getEnterpriseInfo() != null && targetUserId.equals(u.getEnterpriseInfo().getUserId()))
                .findFirst()
                .orElse(null);

        assertNull(firstAttempt);
        assertNull(secondAttempt);
    }

    // ==================== Helper Methods ====================

    private List<ScimUserV2> createUserList(int count) {
        List<ScimUserV2> users = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            ScimUserV2 user = new ScimUserV2();
            user.setId(String.valueOf(i));
            user.setUserName("user" + i);
            user.setDisplayName("User " + i);
            user.setActive(true);
            users.add(user);
        }
        return users;
    }

    private List<ScimUserV2> createUserListWithUserId(int count) {
        List<ScimUserV2> users = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            ScimUserV2 user = new ScimUserV2();
            user.setId("userId" + i);
            user.setUserName("user" + i);
            user.setDisplayName("User " + i);
            user.setActive(true);
            ScimUserV2.ScimEnterpriseUser info = new ScimUserV2.ScimEnterpriseUser();
            info.setUserId("userId" + i);
            user.setEnterpriseInfo(info);
            users.add(user);
        }
        return users;
    }

    // ==================== fetch: 429 / upstream errors ====================

    private UserCacheService cacheWith(int status, java.util.Map<String, List<String>> headers) throws Exception {
        UserCacheService service = new UserCacheService();
        com.dell.webservice.pojos.GlobalFMSSettings settings = new com.dell.webservice.pojos.GlobalFMSSettings();
        settings.setBaseUrl("https://8.8.8.8");
        settings.setListAllUsersPath("/AccessManagement/GetAllUsers");
        settings.setAccessTokenURL("https://8.8.8.8/token");
        com.dell.webservice.api.BuildConnection connection = org.mockito.Mockito.mock(com.dell.webservice.api.BuildConnection.class);
        org.mockito.Mockito.when(connection.getAccessToken(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any()))
                .thenReturn("tok");
        java.net.http.HttpClient client = org.mockito.Mockito.mock(java.net.http.HttpClient.class);
        org.mockito.Mockito.doReturn(com.dell.webservice.testsupport.TestHttpResponses.stringResponse(status, "[]", headers))
                .when(client).send(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
        org.springframework.test.util.ReflectionTestUtils.setField(service, "globalfmssettings", settings);
        org.springframework.test.util.ReflectionTestUtils.setField(service, "buildConnection", connection);
        org.springframework.test.util.ReflectionTestUtils.setField(service, "httpClient", client);
        return service;
    }

    @Test
    void getUserByUserName_upstream429_throwsRateLimitExceptionWithRetryAfter() throws Exception {
        UserCacheService service = cacheWith(429, java.util.Map.of("Retry-After", List.of("17")));

        com.dell.webservice.exception.RateLimitException ex = assertThrows(
                com.dell.webservice.exception.RateLimitException.class,
                () -> service.getUserByUserName("Basic abc", "jdoe"));
        assertEquals("17", ex.getRetryAfter());
    }

    @Test
    void getUserByUserName_upstream500_throwsUpstreamServiceException() throws Exception {
        UserCacheService service = cacheWith(500, java.util.Map.of());

        assertThrows(com.dell.webservice.exception.UpstreamServiceException.class,
                () -> service.getUserByUserName("Basic abc", "jdoe"));
    }

    @Test
    void getUserByUserName_emptyList_returnsNull() throws Exception {
        UserCacheService service = cacheWith(200, java.util.Map.of());

        assertNull(service.getUserByUserName("Basic abc", "jdoe"));
    }
}
