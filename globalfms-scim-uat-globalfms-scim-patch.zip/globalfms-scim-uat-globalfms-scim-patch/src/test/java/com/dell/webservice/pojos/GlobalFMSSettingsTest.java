package com.dell.webservice.pojos;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GlobalFMSSettingsTest {

    private static final String BASE = "https://api.example.com";

    private GlobalFMSSettings settings;

    @BeforeEach
    void setUp() {
        settings = new GlobalFMSSettings();
        settings.setBaseUrl(BASE);
    }

    // ==================== Computed URL Tests ====================

    @Test
    void createUserURL_ComputedFromBaseAndPath() {
        settings.setCreateUserPath("/AccessManagement/AddUser");
        assertEquals(BASE + "/AccessManagement/AddUser", settings.getCreateUserURL());
    }

    @Test
    void updateUserURL_ComputedFromBaseAndPath() {
        settings.setUpdateUserPath("/AccessManagement/UpdateUserPreference");
        assertEquals(BASE + "/AccessManagement/UpdateUserPreference", settings.getUpdateUserURL());
    }

    @Test
    void entitlementsURL_ComputedFromBaseAndPath() {
        settings.setEntitlementsPath("/AccessManagement/GetAllRoles");
        assertEquals(BASE + "/AccessManagement/GetAllRoles", settings.getEntitlementsURL());
    }

    @Test
    void listAllUsersURL_ComputedFromBaseAndPath() {
        settings.setListAllUsersPath("/AccessManagement/GetAllUsers");
        assertEquals(BASE + "/AccessManagement/GetAllUsers", settings.getListAllUsersURL());
    }

    @Test
    void addUserRole_ComputedFromBaseAndPath() {
        settings.setAddUserRolePath("/AccessManagement/AddUserRole");
        assertEquals(BASE + "/AccessManagement/AddUserRole", settings.getAddUserRole());
    }

    @Test
    void removeUserRole_ComputedFromBaseAndPath() {
        settings.setRemoveUserRolePath("/AccessManagement/RemoveUserRole");
        assertEquals(BASE + "/AccessManagement/RemoveUserRole", settings.getRemoveUserRole());
    }

    @Test
    void url_NormalisesTrailingSlashOnBase() {
        settings.setBaseUrl("https://api.example.com/");
        settings.setCreateUserPath("/AccessManagement/AddUser");
        assertEquals("https://api.example.com/AccessManagement/AddUser", settings.getCreateUserURL());
    }

    @Test
    void url_AddsLeadingSlashToPathIfMissing() {
        settings.setCreateUserPath("AccessManagement/AddUser");
        assertEquals(BASE + "/AccessManagement/AddUser", settings.getCreateUserURL());
    }

    @Test
    void url_ReturnsEmptyWhenBaseUrlIsBlank() {
        settings.setBaseUrl("");
        settings.setCreateUserPath("/AccessManagement/AddUser");
        assertEquals("", settings.getCreateUserURL());
    }

    @Test
    void url_ReturnsEmptyWhenPathIsNull() {
        settings.setCreateUserPath(null);
        assertEquals("", settings.getCreateUserURL());
    }

    @Test
    void url_DefaultsToEmptyWhenNoBaseOrPath() {
        GlobalFMSSettings empty = new GlobalFMSSettings();
        assertEquals("", empty.getCreateUserURL());
        assertEquals("", empty.getEntitlementsURL());
        assertEquals("", empty.getAddUserRole());
    }

    // ==================== AccessTokenURL Tests (not base+path) ====================

    @Test
    void accessTokenURL_SetAndGet() {
        settings.setAccessTokenURL("https://www-sit-g4.dell.com/di/api/v3/oauth/token");
        assertEquals("https://www-sit-g4.dell.com/di/api/v3/oauth/token",
                settings.getAccessTokenURL());
    }

    @Test
    void accessTokenURL_DefaultsToNull() {
        GlobalFMSSettings fresh = new GlobalFMSSettings();
        assertNull(fresh.getAccessTokenURL());
    }

    // ==================== Shared Settings Tests ====================

    @Test
    void totalUsers_SetAndGet() {
        settings.setTotalUsers("2000");
        assertEquals("2000", settings.getTotalUsers());
    }

    @Test
    void credURL_SetAndGet() {
        settings.setCredURL("https://api.example.com/credentials");
        assertEquals("https://api.example.com/credentials", settings.getCredURL());
    }

    @Test
    void allowedHosts_SetAndGet() {
        settings.setAllowedHosts("api.example.com,api2.example.com");
        assertEquals("api.example.com,api2.example.com", settings.getAllowedHosts());
    }

    @Test
    void cachecttlValue_SetAndGet() {
        settings.setCachecttlValue("3");
        assertEquals("3", settings.getCachecttlValue());
    }

    // ==================== Proxy Settings Tests ====================

    @Test
    void proxyHost_SetAndGet() {
        settings.setProxyHost("proxy.corp.dell.com");
        assertEquals("proxy.corp.dell.com", settings.getProxyHost());
    }

    @Test
    void proxyPort_SetAndGet() {
        settings.setProxyPort(8080);
        assertEquals(8080, settings.getProxyPort());
    }

    @Test
    void proxyUsername_SetAndGet() {
        settings.setProxyUsername("proxyuser");
        assertEquals("proxyuser", settings.getProxyUsername());
    }

    @Test
    void proxyPassword_SetAndGet() {
        settings.setProxyPassword("secret");
        assertEquals("secret", settings.getProxyPassword());
    }

    @Test
    void proxy_DefaultsToNullAndZero() {
        GlobalFMSSettings fresh = new GlobalFMSSettings();
        assertNull(fresh.getProxyHost());
        assertEquals(0, fresh.getProxyPort());
        assertNull(fresh.getProxyUsername());
        assertNull(fresh.getProxyPassword());
    }

    // ==================== Full Configuration Test ====================

    @Test
    void fullConfiguration_AllUrlsResolveCorrectly() {
        settings.setBaseUrl("https://gfmsuiapidi-ge4.pnp8.pcf.dell.com");
        settings.setCreateUserPath("/AccessManagement/AddUser");
        settings.setUpdateUserPath("/AccessManagement/UpdateUserPreference");
        settings.setEntitlementsPath("/AccessManagement/GetAllRoles");
        settings.setListAllUsersPath("/AccessManagement/GetAllUsers");
        settings.setAddUserRolePath("/AccessManagement/AddUserRole");
        settings.setRemoveUserRolePath("/AccessManagement/RemoveUserRole");
        settings.setAccessTokenURL("https://www-sit-g4.dell.com/di/api/v3/oauth/token");
        settings.setTotalUsers("2000");

        assertTrue(settings.getCreateUserURL().startsWith("https://gfmsuiapidi-ge4.pnp8.pcf.dell.com"));
        assertTrue(settings.getEntitlementsURL().startsWith("https://gfmsuiapidi-ge4.pnp8.pcf.dell.com"));
        assertTrue(settings.getAddUserRole().startsWith("https://gfmsuiapidi-ge4.pnp8.pcf.dell.com"));
        assertTrue(settings.getAccessTokenURL().startsWith("https://www-sit-g4.dell.com"));
        assertNotNull(settings.getTotalUsers());
    }
}
