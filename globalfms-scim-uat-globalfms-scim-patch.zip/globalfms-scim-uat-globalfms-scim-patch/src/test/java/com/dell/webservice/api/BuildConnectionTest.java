package com.dell.webservice.api;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class BuildConnectionTest {

    // ==================== Token Expiry Tests ====================

    @Test
    void tokenExpiry_NewToken_NotExpired() {
        LocalDateTime tokenExpiry = LocalDateTime.now().plusMinutes(55);
        LocalDateTime now = LocalDateTime.now();

        assertTrue(now.isBefore(tokenExpiry));
    }

    @Test
    void tokenExpiry_ExpiredToken_IsExpired() {
        LocalDateTime tokenExpiry = LocalDateTime.now().minusMinutes(5);
        LocalDateTime now = LocalDateTime.now();

        assertFalse(now.isBefore(tokenExpiry));
    }

    @Test
    void tokenExpiry_CalculateBufferSeconds() {
        Integer expiresIn = 3600; // 1 hour
        int bufferSeconds = (expiresIn != null ? expiresIn : 3600) - 300;

        assertEquals(3300, bufferSeconds); // 55 minutes
    }

    @Test
    void tokenExpiry_DefaultBufferSeconds() {
        Integer expiresIn = null;
        int bufferSeconds = (expiresIn != null ? expiresIn : 3600) - 300;

        assertEquals(3300, bufferSeconds);
    }

    // ==================== Token Validation Tests ====================

    @Test
    void token_NullToken_Invalid() {
        String token = null;
        assertTrue(token == null || token.isBlank());
    }

    @Test
    void token_BlankToken_Invalid() {
        String token = "   ";
        assertTrue(token.isBlank());
    }

    @Test
    void token_ValidToken_Valid() {
        String token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
        assertFalse(token == null || token.isBlank());
    }

    // ==================== HTTP Status Tests ====================

    @Test
    void httpStatus_200_IsSuccess() {
        int statusCode = 200;
        assertTrue(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_201_IsSuccess() {
        int statusCode = 201;
        assertTrue(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_400_IsNotSuccess() {
        int statusCode = 400;
        assertFalse(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_401_IsNotSuccess() {
        int statusCode = 401;
        assertFalse(statusCode >= 200 && statusCode < 300);
    }

    @Test
    void httpStatus_500_IsNotSuccess() {
        int statusCode = 500;
        assertFalse(statusCode >= 200 && statusCode < 300);
    }

    // ==================== URL Validation Tests ====================

    @Test
    void url_HttpsScheme_Valid() {
        String url = "https://api.example.com/token";
        assertTrue(url.startsWith("https://"));
    }

    @Test
    void url_HttpScheme_Invalid() {
        String url = "http://api.example.com/token";
        assertFalse(url.startsWith("https://"));
    }

    @Test
    void url_NullUrl_Invalid() {
        String url = null;
        assertTrue(url == null || url.isBlank());
    }

    @Test
    void url_EmptyUrl_Invalid() {
        String url = "";
        assertTrue(url.isBlank());
    }

    // ==================== Request Body Tests ====================

    @Test
    void requestBody_GrantType_ClientCredentials() {
        String grantType = "client_credentials";
        assertEquals("client_credentials", grantType);
    }

    @Test
    void requestBody_JsonFormat() {
        String expectedJson = "{\"grant_type\":\"client_credentials\"}";
        assertTrue(expectedJson.contains("grant_type"));
        assertTrue(expectedJson.contains("client_credentials"));
    }

    // ==================== Response Parsing Tests ====================

    @Test
    void response_AccessTokenKey() {
        String key = "access_token";
        assertEquals("access_token", key);
    }

    @Test
    void response_ExpiresInKey() {
        String key = "expires_in";
        assertEquals("expires_in", key);
    }

    // ==================== Timeout Tests ====================

    @Test
    void timeout_ConnectTimeout_60Seconds() {
        int timeoutSeconds = 60;
        assertEquals(60, timeoutSeconds);
    }

    @Test
    void timeout_RequestTimeout_60Seconds() {
        int timeoutSeconds = 60;
        assertEquals(60, timeoutSeconds);
    }

    // ==================== Thread Safety Tests ====================

    @Test
    void synchronization_LockObject_NotNull() {
        Object lock = new Object();
        assertNotNull(lock);
    }

    @Test
    void volatileToken_CanBeNull() {
        String token = null;
        assertNull(token);
    }

    @Test
    void volatileExpiry_CanBeMinValue() {
        LocalDateTime expiry = LocalDateTime.MIN;
        assertEquals(LocalDateTime.MIN, expiry);
    }

    // ==================== Proxy Configuration Tests ====================

    @Test
    void proxy_NoProxyWhenHostIsNull() {
        // When proxyHost is null, no proxy should be applied.
        com.dell.webservice.pojos.GlobalFMSSettings settings =
                new com.dell.webservice.pojos.GlobalFMSSettings();
        assertNull(settings.getProxyHost());
        assertEquals(0, settings.getProxyPort());
    }

    @Test
    void proxy_NoProxyWhenHostIsBlank() {
        com.dell.webservice.pojos.GlobalFMSSettings settings =
                new com.dell.webservice.pojos.GlobalFMSSettings();
        settings.setProxyHost("  ");
        assertTrue(settings.getProxyHost().isBlank());
    }

    @Test
    void proxy_NoProxyWhenPortIsZero() {
        com.dell.webservice.pojos.GlobalFMSSettings settings =
                new com.dell.webservice.pojos.GlobalFMSSettings();
        settings.setProxyHost("proxy.corp.dell.com");
        // port not set — defaults to 0, so no proxy should be applied
        assertEquals(0, settings.getProxyPort());
    }

    @Test
    void proxy_WithHostAndPort_ShouldApply() {
        com.dell.webservice.pojos.GlobalFMSSettings settings =
                new com.dell.webservice.pojos.GlobalFMSSettings();
        settings.setProxyHost("proxy.corp.dell.com");
        settings.setProxyPort(8080);
        assertFalse(settings.getProxyHost().isBlank());
        assertTrue(settings.getProxyPort() > 0);
    }

    @Test
    void proxy_WithCredentials_BothRequired() {
        com.dell.webservice.pojos.GlobalFMSSettings settings =
                new com.dell.webservice.pojos.GlobalFMSSettings();
        settings.setProxyHost("proxy.corp.dell.com");
        settings.setProxyPort(8080);
        settings.setProxyUsername("proxyuser");
        settings.setProxyPassword("secret");

        assertFalse(settings.getProxyUsername().isBlank());
        assertFalse(settings.getProxyPassword().isBlank());
    }

    @Test
    void proxy_WithHostPortNoCredentials_NoAuthApplied() {
        com.dell.webservice.pojos.GlobalFMSSettings settings =
                new com.dell.webservice.pojos.GlobalFMSSettings();
        settings.setProxyHost("proxy.corp.dell.com");
        settings.setProxyPort(8080);
        // No username/password set
        assertNull(settings.getProxyUsername());
        assertNull(settings.getProxyPassword());
    }

    // ==================== getAccessToken: real behavior ====================

    private static final String TOKEN_URL = "https://8.8.8.8/di/api/v3/oauth/token";
    private static final String CREDS = "Basic aWQ6c2VjcmV0";

    private java.net.http.HttpClient mockClient;
    private BuildConnection buildConnection;

    @org.junit.jupiter.api.BeforeEach
    void setUpConnection() {
        buildConnection = new BuildConnection(org.mockito.Mockito.mock(com.dell.webservice.pojos.GlobalFMSSettings.class));
        mockClient = org.mockito.Mockito.mock(java.net.http.HttpClient.class);
        org.springframework.test.util.ReflectionTestUtils.setField(buildConnection, "httpClient", mockClient);
    }

    private void respondWith(int status, String body) throws Exception {
        org.mockito.Mockito.doReturn(com.dell.webservice.testsupport.TestHttpResponses.stringResponse(status, body))
                .when(mockClient).send(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    void getAccessToken_success_returnsTokenAndCaches() throws Exception {
        respondWith(200, "{\"access_token\":\"tok-1\",\"expires_in\":3600}");

        assertEquals("tok-1", buildConnection.getAccessToken(TOKEN_URL, CREDS));
        assertEquals("tok-1", buildConnection.getAccessToken(TOKEN_URL, CREDS));
        org.mockito.Mockito.verify(mockClient, org.mockito.Mockito.times(1))
                .send(org.mockito.ArgumentMatchers.any(), org.mockito.ArgumentMatchers.any());
    }

    @Test
    void getAccessToken_401_throwsUnauthorizedException() throws Exception {
        respondWith(401, "unauthorized");

        assertThrows(com.dell.webservice.exception.UnauthorizedException.class,
                () -> buildConnection.getAccessToken(TOKEN_URL, CREDS));
    }

    @Test
    void getAccessToken_429_throwsRateLimitException() throws Exception {
        respondWith(429, "slow down");

        assertThrows(com.dell.webservice.exception.RateLimitException.class,
                () -> buildConnection.getAccessToken(TOKEN_URL, CREDS));
    }

    @Test
    void getAccessToken_500_throwsUpstreamServiceException() throws Exception {
        respondWith(500, "boom");

        assertThrows(com.dell.webservice.exception.UpstreamServiceException.class,
                () -> buildConnection.getAccessToken(TOKEN_URL, CREDS));
    }

    @Test
    void getAccessToken_missingAccessToken_throwsUpstreamServiceException() throws Exception {
        respondWith(200, "{\"expires_in\":3600}");

        assertThrows(com.dell.webservice.exception.UpstreamServiceException.class,
                () -> buildConnection.getAccessToken(TOKEN_URL, CREDS));
    }
}
