package com.dell.webservice.controller;

import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class ScimUserV2Test {

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
    }

    // ==================== Serialization Tests ====================

    @Test
    void serialize_FullUser_ProducesValidJson() throws Exception {
        ScimUserV2 user = createFullUser();

        String json = objectMapper.writeValueAsString(user);

        assertNotNull(json);
        assertTrue(json.contains("\"id\":\"123\""));
        assertTrue(json.contains("\"userName\":\"Wilson_Bradley\""));
        assertTrue(json.contains("\"active\":true"));
    }

    @Test
    void serialize_UserWithEntitlements_IncludesEntitlements() throws Exception {
        ScimUserV2 user = new ScimUserV2();
        user.setId("123");
        user.setUserName("testuser");
        user.setEntitlements(List.of(
                new ScimUserV2.Entitlement("Admin", "Admin Role", "Entitlement", null),
                new ScimUserV2.Entitlement("User", "User Role", "Entitlement", null)
        ));

        String json = objectMapper.writeValueAsString(user);

        assertTrue(json.contains("\"entitlements\""));
        assertTrue(json.contains("\"value\":\"Admin\""));
        assertTrue(json.contains("\"display\":\"Admin Role\""));
    }

    @Test
    void serialize_NullFields_ExcludedFromJson() throws Exception {
        ScimUserV2 user = new ScimUserV2();
        user.setId("123");
        user.setUserName("testuser");

        String json = objectMapper.writeValueAsString(user);

        assertFalse(json.contains("\"emails\""));
        assertFalse(json.contains("\"phoneNumbers\""));
    }

    @Test
    void serialize_EnterpriseInfo_UsesCorrectJsonProperty() throws Exception {
        ScimUserV2 user = new ScimUserV2();
        user.setId("123");
        ScimUserV2.ScimEnterpriseUser enterpriseInfo = new ScimUserV2.ScimEnterpriseUser();
        enterpriseInfo.setRegion("DAO");
        enterpriseInfo.setManager("R_Laing");
        user.setEnterpriseInfo(enterpriseInfo);

        String json = objectMapper.writeValueAsString(user);

        assertTrue(json.contains("\"urn:ietf:params:scim:schemas:extension:enterprise:2.0:User\""));
        assertTrue(json.contains("\"region\":\"DAO\""));
        assertTrue(json.contains("\"manager\":\"R_Laing\""));
    }

    @Test
    void serialize_Name_UsesFamilyNameAndGivenName() throws Exception {
        ScimUserV2 user = new ScimUserV2();
        user.setId("123");
        user.setDetailedName(new ScimUserV2.Name("Smith", "John"));

        String json = objectMapper.writeValueAsString(user);

        assertTrue(json.contains("\"name\""));
        assertTrue(json.contains("\"familyName\":\"Smith\""));
        assertTrue(json.contains("\"givenName\":\"John\""));
    }

    @Test
    void serialize_Email_UsesValueProperty() throws Exception {
        ScimUserV2 user = new ScimUserV2();
        user.setId("123");
        user.setEmails(List.of(new ScimUserV2.Email("Wilson_Bradley@Dell.com", true)));

        String json = objectMapper.writeValueAsString(user);

        assertTrue(json.contains("\"emails\""));
        assertTrue(json.contains("\"value\":\"Wilson_Bradley@Dell.com\""));
        assertTrue(json.contains("\"primary\":true"));
    }

    @Test
    void serialize_ResourceMeta_IncludesLastModified() throws Exception {
        ScimUserV2 user = new ScimUserV2();
        user.setId("123");
        ScimUserV2.ResourceMeta meta = new ScimUserV2.ResourceMeta("User");
        meta.setLastModified("2023-06-16T05:28:01.78");
        meta.setCreated("2018-09-18T12:40:42.767");
        user.setMeta(meta);

        String json = objectMapper.writeValueAsString(user);

        assertTrue(json.contains("\"resourceType\":\"User\""));
        assertTrue(json.contains("\"lastModified\":\"2023-06-16T05:28:01.78\""));
        assertTrue(json.contains("\"created\":\"2018-09-18T12:40:42.767\""));
    }

    // ==================== Deserialization Tests ====================

    @Test
    void deserialize_ValidJson_CreatesUser() throws Exception {
        String json = """
                {
                    "id": "123",
                    "userName": "testuser",
                    "active": true,
                    "displayName": "Test User"
                }
                """;

        ScimUserV2 user = objectMapper.readValue(json, ScimUserV2.class);

        assertEquals("123", user.getId());
        assertEquals("testuser", user.getUserName());
        assertTrue(user.getActive());
        assertEquals("Test User", user.getDisplayName());
    }

    @Test
    void deserialize_JsonWithEntitlements_ParsesEntitlements() throws Exception {
        String json = """
                {
                    "id": "123",
                    "userName": "testuser",
                    "entitlements": [
                        {"value": "Admin", "display": "Admin Role", "type": "Entitlement"},
                        {"value": "User", "display": "User Role", "type": "Entitlement"}
                    ]
                }
                """;

        ScimUserV2 user = objectMapper.readValue(json, ScimUserV2.class);

        assertNotNull(user.getEntitlements());
        assertEquals(2, user.getEntitlements().size());
        assertEquals("Admin", user.getEntitlements().get(0).getValue());
        assertEquals("Admin Role", user.getEntitlements().get(0).getDisplay());
    }

    @Test
    void deserialize_JsonWithEnterpriseInfo_ParsesEnterpriseInfo() throws Exception {
        String json = """
                {
                    "id": "123",
                    "userName": "testuser",
                    "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User": {
                        "region": "DAO",
                        "manager": "R_Laing",
                        "userRoles": "Admin,User,Conus"
                    }
                }
                """;

        ScimUserV2 user = objectMapper.readValue(json, ScimUserV2.class);

        assertNotNull(user.getEnterpriseInfo());
        assertEquals("DAO", user.getEnterpriseInfo().getRegion());
        assertEquals("R_Laing", user.getEnterpriseInfo().getManager());
        assertEquals("Admin,User,Conus", user.getEnterpriseInfo().getUserRoles());
    }

    @Test
    void deserialize_JsonWithName_ParsesName() throws Exception {
        String json = """
                {
                    "id": "123",
                    "userName": "testuser",
                    "name": {
                        "familyName": "Bradley",
                        "givenName": "Wilson"
                    }
                }
                """;

        ScimUserV2 user = objectMapper.readValue(json, ScimUserV2.class);

        assertNotNull(user.getDetailedName());
        assertEquals("Bradley", user.getDetailedName().getLastName());
        assertEquals("Wilson", user.getDetailedName().getFirstName());
    }

    @Test
    void deserialize_JsonWithEmails_ParsesEmails() throws Exception {
        String json = """
                {
                    "id": "123",
                    "userName": "testuser",
                    "emails": [
                        {"value": "Wilson_Bradley@Dell.com", "primary": true}
                    ]
                }
                """;

        ScimUserV2 user = objectMapper.readValue(json, ScimUserV2.class);

        assertNotNull(user.getEmails());
        assertEquals(1, user.getEmails().size());
        assertEquals("Wilson_Bradley@Dell.com", user.getEmails().get(0).getEmailAddress());
        assertTrue(user.getEmails().get(0).getPrimary());
    }

    @Test
    void deserialize_UnknownFields_IgnoredWithConfig() throws Exception {
        ObjectMapper lenientMapper = JsonMapper.builder()
                .disable(tools.jackson.databind.DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .build();

        String json = """
                {
                    "id": "123",
                    "userName": "testuser",
                    "unknownField": "unknownValue"
                }
                """;

        ScimUserV2 user = lenientMapper.readValue(json, ScimUserV2.class);

        assertEquals("123", user.getId());
        assertEquals("testuser", user.getUserName());
    }

    // ==================== Entitlement Tests ====================

    @Test
    void entitlement_DefaultConstructor_CreatesEmptyEntitlement() {
        ScimUserV2.Entitlement entitlement = new ScimUserV2.Entitlement();

        assertNull(entitlement.getValue());
        assertNull(entitlement.getDisplay());
        assertNull(entitlement.getType());
    }

    @Test
    void entitlement_ValueConstructor_SetsValue() {
        ScimUserV2.Entitlement entitlement = new ScimUserV2.Entitlement("Admin");

        assertEquals("Admin", entitlement.getValue());
        assertNull(entitlement.getDisplay());
    }

    @Test
    void entitlement_FullConstructor_SetsAllFields() {
        ScimUserV2.Entitlement entitlement = new ScimUserV2.Entitlement("Admin", "Administrator", "Entitlement", false);

        assertEquals("Admin", entitlement.getValue());
        assertEquals("Administrator", entitlement.getDisplay());
        assertEquals("Entitlement", entitlement.getType());
        assertFalse(entitlement.getPrimary());
    }

    @Test
    void entitlement_Setters_UpdateFields() {
        ScimUserV2.Entitlement entitlement = new ScimUserV2.Entitlement();
        entitlement.setValue("Conus");
        entitlement.setDisplay("Conus Role");
        entitlement.setType("Entitlement");
        entitlement.setDescription("Access to Conus features");

        assertEquals("Conus", entitlement.getValue());
        assertEquals("Conus Role", entitlement.getDisplay());
        assertEquals("Entitlement", entitlement.getType());
        assertEquals("Access to Conus features", entitlement.getDescription());
    }

    // ==================== Name Tests ====================

    @Test
    void name_DefaultConstructor_CreatesEmptyName() {
        ScimUserV2.Name name = new ScimUserV2.Name();

        assertNull(name.getFirstName());
        assertNull(name.getLastName());
    }

    @Test
    void name_FullConstructor_SetsFields() {
        ScimUserV2.Name name = new ScimUserV2.Name("Bradley", "Wilson");

        assertEquals("Bradley", name.getLastName());
        assertEquals("Wilson", name.getFirstName());
    }

    // ==================== Email Tests ====================

    @Test
    void email_DefaultConstructor_CreatesEmptyEmail() {
        ScimUserV2.Email email = new ScimUserV2.Email();

        assertNull(email.getEmailAddress());
        assertNull(email.getPrimary());
    }

    @Test
    void email_FullConstructor_SetsFields() {
        ScimUserV2.Email email = new ScimUserV2.Email("Wilson_Bradley@Dell.com", true);

        assertEquals("Wilson_Bradley@Dell.com", email.getEmailAddress());
        assertTrue(email.getPrimary());
    }

    // ==================== ScimEnterpriseUser Tests ====================

    @Test
    void enterpriseUser_DefaultConstructor_CreatesEmptyUser() {
        ScimUserV2.ScimEnterpriseUser enterpriseUser = new ScimUserV2.ScimEnterpriseUser();

        assertNull(enterpriseUser.getRegion());
        assertNull(enterpriseUser.getManager());
        assertNull(enterpriseUser.getUserRoles());
        assertNull(enterpriseUser.getUserId());
    }

    @Test
    void enterpriseUser_Setters_UpdateFields() {
        ScimUserV2.ScimEnterpriseUser enterpriseUser = new ScimUserV2.ScimEnterpriseUser();
        enterpriseUser.setRegion("DAO");
        enterpriseUser.setManager("R_Laing");
        enterpriseUser.setUserRoles("Admin,User,Conus");
        enterpriseUser.setIsActive("true");
        enterpriseUser.setCreatedBy("GFMS");
        enterpriseUser.setModifiedBy("Penumetcha_Sai_Venka");

        assertEquals("DAO", enterpriseUser.getRegion());
        assertEquals("R_Laing", enterpriseUser.getManager());
        assertEquals("Admin,User,Conus", enterpriseUser.getUserRoles());
        assertEquals("true", enterpriseUser.getIsActive());
        assertEquals("GFMS", enterpriseUser.getCreatedBy());
        assertEquals("Penumetcha_Sai_Venka", enterpriseUser.getModifiedBy());
    }

    @Test
    void enterpriseUser_UserId_SetAndGet() {
        ScimUserV2.ScimEnterpriseUser enterpriseUser = new ScimUserV2.ScimEnterpriseUser();
        enterpriseUser.setUserId("3488");
        assertEquals("3488", enterpriseUser.getUserId());
    }

    @Test
    void scimUser_IdIsUserName_NotNumericUserId() {
        // Verifies the design decision: SCIM id = userName so PATCH/PUT URLs
        // contain the userName directly, with numeric userId preserved separately.
        ScimUserV2 user = new ScimUserV2();
        user.setId("testdellblue39");        // userName as id
        user.setUserName("testdellblue39");

        ScimUserV2.ScimEnterpriseUser info = new ScimUserV2.ScimEnterpriseUser();
        info.setUserId("3488");              // numeric userId preserved in extension
        user.setEnterpriseInfo(info);

        assertEquals("testdellblue39", user.getId());
        assertEquals("testdellblue39", user.getUserName());
        assertEquals("3488", user.getEnterpriseInfo().getUserId());
    }

    // ==================== ResourceMeta Tests ====================

    @Test
    void resourceMeta_DefaultConstructor_CreatesEmptyMeta() {
        ScimUserV2.ResourceMeta meta = new ScimUserV2.ResourceMeta();

        assertNull(meta.getResourceType());
        assertNull(meta.getLocation());
        assertNull(meta.getVersion());
        assertNull(meta.getLastModified());
        assertNull(meta.getCreated());
    }

    @Test
    void resourceMeta_TypeConstructor_SetsResourceType() {
        ScimUserV2.ResourceMeta meta = new ScimUserV2.ResourceMeta("User");

        assertEquals("User", meta.getResourceType());
        assertNull(meta.getLocation());
    }

    @Test
    void resourceMeta_FullConstructor_SetsAllFields() {
        ScimUserV2.ResourceMeta meta = new ScimUserV2.ResourceMeta("User", "/Users/123", "v1");

        assertEquals("User", meta.getResourceType());
        assertEquals("/Users/123", meta.getLocation());
        assertEquals("v1", meta.getVersion());
    }

    @Test
    void resourceMeta_LastModified_Setters() {
        ScimUserV2.ResourceMeta meta = new ScimUserV2.ResourceMeta("User");
        meta.setLastModified("2023-06-16T05:28:01.78");
        meta.setCreated("2018-09-18T12:40:42.767");

        assertEquals("2023-06-16T05:28:01.78", meta.getLastModified());
        assertEquals("2018-09-18T12:40:42.767", meta.getCreated());
    }

    // ==================== Role Tests ====================

    @Test
    void role_DefaultConstructor_CreatesEmptyRole() {
        ScimUserV2.Role role = new ScimUserV2.Role();

        assertNull(role.getValue());
        assertNull(role.getDisplay());
    }

    @Test
    void role_ValueConstructor_SetsValue() {
        ScimUserV2.Role role = new ScimUserV2.Role("admin");

        assertEquals("admin", role.getValue());
        assertNull(role.getDisplay());
    }

    @Test
    void role_FullConstructor_SetsAllFields() {
        ScimUserV2.Role role = new ScimUserV2.Role("admin", "Administrator");

        assertEquals("admin", role.getValue());
        assertEquals("Administrator", role.getDisplay());
    }

    // ==================== PhoneNumber Tests ====================

    @Test
    void phoneNumber_DefaultConstructor_CreatesEmptyPhoneNumber() {
        ScimUserV2.PhoneNumber phone = new ScimUserV2.PhoneNumber();

        assertNull(phone.getPhoneNumber());
        assertNull(phone.getPhoneType());
    }

    @Test
    void phoneNumber_FullConstructor_SetsAllFields() {
        ScimUserV2.PhoneNumber phone = new ScimUserV2.PhoneNumber("555-1234", "work");

        assertEquals("555-1234", phone.getPhoneNumber());
        assertEquals("work", phone.getPhoneType());
    }

    // ==================== Round-trip Tests ====================

    @Test
    void roundTrip_FullUser_PreservesAllData() throws Exception {
        ScimUserV2 original = createFullUser();

        String json = objectMapper.writeValueAsString(original);
        ScimUserV2 deserialized = objectMapper.readValue(json, ScimUserV2.class);

        assertEquals(original.getId(), deserialized.getId());
        assertEquals(original.getUserName(), deserialized.getUserName());
        assertEquals(original.getDisplayName(), deserialized.getDisplayName());
        assertEquals(original.getActive(), deserialized.getActive());
        assertEquals(original.getExternalId(), deserialized.getExternalId());
    }

    @Test
    void roundTrip_UserWithEntitlements_PreservesEntitlements() throws Exception {
        ScimUserV2 original = new ScimUserV2();
        original.setId("123");
        original.setUserName("testuser");
        original.setEntitlements(List.of(
                new ScimUserV2.Entitlement("Admin", "Admin", "Entitlement", null)
        ));

        String json = objectMapper.writeValueAsString(original);
        ScimUserV2 deserialized = objectMapper.readValue(json, ScimUserV2.class);

        assertNotNull(deserialized.getEntitlements());
        assertEquals(1, deserialized.getEntitlements().size());
        assertEquals("Admin", deserialized.getEntitlements().get(0).getValue());
    }

    private ScimUserV2 createFullUser() {
        ScimUserV2 user = new ScimUserV2();
        user.setId("123");
        user.setUserName("Wilson_Bradley");
        user.setExternalId("Wilson_Bradley");
        user.setDisplayName("Wilson Bradley");
        user.setActive(true);
        user.setSchemas(Set.of(
                "urn:ietf:params:scim:schemas:core:2.0:User",
                "urn:ietf:params:scim:schemas:extension:enterprise:2.0:User"
        ));

        ScimUserV2.ResourceMeta meta = new ScimUserV2.ResourceMeta("User");
        meta.setLastModified("2023-06-16T05:28:01.78");
        meta.setCreated("2018-09-18T12:40:42.767");
        user.setMeta(meta);

        user.setDetailedName(new ScimUserV2.Name("Bradley", "Wilson"));
        user.setEmails(List.of(new ScimUserV2.Email("Wilson_Bradley@Dell.com", true)));

        ScimUserV2.ScimEnterpriseUser enterpriseInfo = new ScimUserV2.ScimEnterpriseUser();
        enterpriseInfo.setRegion("DAO");
        enterpriseInfo.setManager("R_Laing");
        enterpriseInfo.setUserRoles("Admin,User,Conus,SuperUser,Fed");
        user.setEnterpriseInfo(enterpriseInfo);

        return user;
    }
}
