package com.dell.webservice.scim.salesworks.extpojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.okta.ps.scim.pojos.ScimResource;

import java.util.List;

/**
 * SalesWorks-specific {@link ScimResource} used to advertise the resource types
 * exposed via /v2/ResourceTypes ("User", "SalesLeaders", "UserTypes") with
 * name/schema/endpoint/schemaExtensions — core@1.1.0 (main)'s bare ScimResource
 * carries none of those fields. Same pattern as scim-connector-synchro-scim's
 * SynchroResourceType and scim-connector-prismacloud's PrismaCloudResourceType;
 * schemaExtensions is SalesWorks' own addition since none of those needed it.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SalesWorksResourceType extends ScimResource {

    private String name;
    private String description;
    private String schema;
    private String endpoint;
    private List<SchemaExtension> schemaExtensions;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSchema() { return schema; }
    public void setSchema(String schema) { this.schema = schema; }

    public String getEndpoint() { return endpoint; }
    public void setEndpoint(String endpoint) { this.endpoint = endpoint; }

    public List<SchemaExtension> getSchemaExtensions() { return schemaExtensions; }
    public void setSchemaExtensions(List<SchemaExtension> schemaExtensions) { this.schemaExtensions = schemaExtensions; }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class SchemaExtension {
        private String schema;
        private boolean required;

        public SchemaExtension() {}
        public SchemaExtension(String schema, boolean required) {
            this.schema = schema;
            this.required = required;
        }

        public String getSchema() { return schema; }
        public void setSchema(String schema) { this.schema = schema; }

        public boolean isRequired() { return required; }
        public void setRequired(boolean required) { this.required = required; }
    }
}
