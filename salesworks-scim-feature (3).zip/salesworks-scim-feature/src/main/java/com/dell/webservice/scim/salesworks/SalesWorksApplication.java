package com.dell.webservice.scim.salesworks;

import com.okta.ps.scim.ScimConnectorApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.okta.ps.scim", "com.dell.webservice.scim.salesworks"})
public class SalesWorksApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        new SpringApplicationBuilder(ScimConnectorApplication.class, SalesWorksApplication.class)
                .run(args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(ScimConnectorApplication.class, SalesWorksApplication.class);
    }
}
