package com.dell.webservice.scim.salesworks.descriptor;

import com.okta.ps.scim.api.ConnectorDescriptor;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.ScimResource;
import com.okta.ps.scim.pojos.SchemaAttribute;
import com.okta.ps.scim.pojos.ScimSchema;
import com.okta.ps.scim.pojos.ScimSchemas;
import com.okta.ps.scim.pojos.ServiceProviderConfigs;
import com.dell.webservice.scim.salesworks.api.SalesWorksEntitlementSource;
import com.dell.webservice.scim.salesworks.extpojos.SalesWorksResourceType;
import com.dell.webservice.scim.salesworks.extpojos.SalesWorksServiceProviderConfigs;
import com.dell.webservice.scim.salesworks.pojos.SalesWorksScimUser;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class SalesWorksDescriptor implements ConnectorDescriptor {

    private final SalesWorksEntitlementSource entitlementSource;

    public SalesWorksDescriptor(SalesWorksEntitlementSource entitlementSource) {
        this.entitlementSource = entitlementSource;
    }

    @Override
    public ServiceProviderConfigs serviceProviderConfig() {
        SalesWorksServiceProviderConfigs cfg = new SalesWorksServiceProviderConfigs();
        cfg.getSchemas().add("urn:okta:schemas:scim:providerconfig:2.0");

        // core@1.1.0 handles PATCH for active plus entitlements/roles add, filtered
        // remove, and whole-attribute replace via the existing setEntitlement/
        // getEntitlements calls — no ConnectorApi changes needed to opt in.
        cfg.setPatch(new ServiceProviderConfigs.Patch(true, 100));

        // Capabilities advertised per spec scim_advertisement:
        // PUSH_PROFILE_UPDATES per Config Salesworks.docx — Update User Attributes
        // must be enabled; already implemented via PUT's entitlement diff.
        // IMPORT_USER_SCHEMA/IMPORT_PROFILE_UPDATES: CORRECTED (functional testing)
        // — without these, Okta's Test Connector Configuration skipped
        // schema-driven attribute discovery and never refreshed profile
        // attributes for already-matched existing users on re-import.
        // change_password: false
        // bulk: false
        cfg.setCustomPropertiesMap(Map.of("userManagementCapabilities", List.of(
                "IMPORT_NEW_USERS",
                "IMPORT_PROFILE_UPDATES",
                "IMPORT_USER_SCHEMA",
                "PUSH_NEW_USERS",
                "PUSH_PROFILE_UPDATES",
                "PUSH_USER_DEACTIVATION",
                "REACTIVATE_USERS")));

        cfg.getAuthenticationSchemes().add(
                new ServiceProviderConfigs.AuthenticationScheme(
                        "oauthbearertoken",
                        "OAuth Bearer Token",
                        "Bearer token authentication via the Okta provisioning agent"));

        return cfg;
    }

    @Override
    public List<Entitlement> entitlementCatalog() {
        List<Entitlement> all = new ArrayList<>();
        all.addAll(entitlementSource.listSalesLeaderEntitlements());
        all.addAll(entitlementSource.listUserTypeEntitlements());
        return all;
    }

    @Override
    public List<ScimResource> resourceTypes() {
        // endpoint is relative to Okta's configured SCIM base URL for this app, which
        // already includes /v2 — a /v2 prefix here doubles up (confirmed: Okta 404'd on
        // "v2/v2/SalesLeaders" until this was dropped).
        SalesWorksResourceType userType = new SalesWorksResourceType();
        userType.getSchemas().add(ScimSchemas.RESOURCE_TYPE);
        userType.setId("User");
        userType.setName("User");
        userType.setDescription("User Accounts");
        userType.setSchema(ScimSchemas.USER);
        userType.setEndpoint("/Users");
        // Every user carries the SalesWorks extension (accountName/categoryName/
        // accountId) — see SalesWorksScimUser — so it's always present, hence required.
        // CORRECTED: a connector-specific URN, not the standard IETF enterprise
        // extension — see SalesWorksScimUser's class comment for why.
        userType.setSchemaExtensions(List.of(
                new SalesWorksResourceType.SchemaExtension(SalesWorksScimUser.EXTENSION_URN, true)));

        // Sales Leaders and User Types are advertised as their own resource types
        // (not the generic Entitlement type) so Okta's OIG entitlement import can
        // discover and import each independently — matches the prior working
        // implementation's ResourceTypes response.
        SalesWorksResourceType salesLeadersType = new SalesWorksResourceType();
        salesLeadersType.getSchemas().add(ScimSchemas.RESOURCE_TYPE);
        salesLeadersType.setId("SalesLeaders");
        salesLeadersType.setName("SalesLeaders");
        salesLeadersType.setDescription("SalesLeaders resource");
        salesLeadersType.setSchema(ScimSchemas.ENTITLEMENT);
        salesLeadersType.setEndpoint("/SalesLeaders");

        SalesWorksResourceType userTypesType = new SalesWorksResourceType();
        userTypesType.getSchemas().add(ScimSchemas.RESOURCE_TYPE);
        userTypesType.setId("UserTypes");
        userTypesType.setName("UserTypes");
        userTypesType.setDescription("UserTypes resource");
        userTypesType.setSchema(ScimSchemas.ENTITLEMENT);
        userTypesType.setEndpoint("/UserTypes");

        return List.of(userType, salesLeadersType, userTypesType);
    }

    @Override
    public List<ScimSchema> schemas() {
        ScimSchema userSchema = new ScimSchema();
        userSchema.setId(ScimSchemas.USER);
        userSchema.setName("User");
        // Declared so Okta's schema discovery knows these are real, mappable
        // attributes — without this, only baseline attributes Okta always
        // understands (userName) show up in the admin console, even though
        // displayName is already present in every /v2/Users response
        // (SalesWorksMapper.toScimUser() sets it from AccountName). name is
        // declared for the same reason — Okta's dashboard "Name" column reads
        // name.givenName/familyName, not displayName.
        userSchema.setAttributes(List.of(
                SchemaAttribute.simple("userName", "string", true),
                SchemaAttribute.simple("active", "boolean", false),
                SchemaAttribute.simple("displayName", "string", false),
                nameAttribute()));

        ScimSchema entitlementSchema = new ScimSchema();
        entitlementSchema.setId(ScimSchemas.ENTITLEMENT);
        entitlementSchema.setName("Entitlement");

        // accountName/categoryName/accountId, per Config Salesworks.docx's
        // SalesWorks-to-Okta import mapping (appuser.AccountName -> accountName,
        // etc.) — import-only, see SalesWorksScimUser. CORRECTED: a
        // connector-specific URN, not the standard IETF enterprise extension.
        ScimSchema salesWorksSchema = new ScimSchema();
        salesWorksSchema.setId(SalesWorksScimUser.EXTENSION_URN);
        salesWorksSchema.setName("SalesWorksUser");
        salesWorksSchema.setDescription("SalesWorks import attributes");
        salesWorksSchema.setAttributes(List.of(
                SchemaAttribute.simple("accountName", "string", false),
                SchemaAttribute.simple("categoryName", "string", false),
                SchemaAttribute.simple("accountId", "string", false)));

        return List.of(userSchema, entitlementSchema, salesWorksSchema);
    }

    private static SchemaAttribute nameAttribute() {
        SchemaAttribute name = SchemaAttribute.simple("name", "complex", false);
        name.setSubAttributes(List.of(
                SchemaAttribute.simple("givenName", "string", false),
                SchemaAttribute.simple("familyName", "string", false),
                SchemaAttribute.simple("formatted", "string", false)));
        return name;
    }
}
