package com.dell.webservice.scim.salesworks.extpojos;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.okta.ps.scim.pojos.ServiceProviderConfigs;

import java.util.Map;

/**
 * SalesWorks-specific {@link ServiceProviderConfigs}, carrying the Okta-proprietary
 * userManagementCapabilities list under the urn:okta:schemas:scim:providerconfig:2.0
 * custom schema. core@1.1.0 (main) has no first-class support for this vendor
 * extension, so it's added here locally rather than in core — same pattern as
 * scim-connector-synchro-scim's SynchroServiceProviderConfigs and
 * scim-connector-prismacloud's PrismaCloudServiceProviderConfigs.
 */
public class SalesWorksServiceProviderConfigs extends ServiceProviderConfigs {

    @JsonProperty("urn:okta:schemas:scim:providerconfig:2.0")
    private Map<String, Object> customPropertiesMap;

    public Map<String, Object> getCustomPropertiesMap() { return customPropertiesMap; }
    public void setCustomPropertiesMap(Map<String, Object> customPropertiesMap) { this.customPropertiesMap = customPropertiesMap; }
}
