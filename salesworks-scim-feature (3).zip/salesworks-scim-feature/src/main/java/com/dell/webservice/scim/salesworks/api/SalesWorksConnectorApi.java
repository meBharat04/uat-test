package com.dell.webservice.scim.salesworks.api;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.dell.webservice.scim.salesworks.mapper.SalesWorksMapper;
import com.okta.ps.scim.scim.ScimErrorException;
import com.okta.ps.scim.utils.StandardLogger;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Component
@Profile("!in-memory")
public class SalesWorksConnectorApi implements ConnectorApi, SalesWorksEntitlementSource {

    private static final StandardLogger LOG = StandardLogger.forClass(SalesWorksConnectorApi.class);

    private final SalesWorksMapper mapper;
    private final ObjectMapper objectMapper;

    @Value("${salesworks.base.url:}")
    private String baseUrl;

    @Value("${salesworks.persona.name:Analyst}")
    private String personaName;

    @Value("${salesworks.service.badge:}")
    private String serviceBadge;

    // Not @Value-injected in production: Okta sends this per-request as the
    // password of an inbound Basic Authorization header (username "apiKey"),
    // per company standard — see resolveApiKey(). The test constructor below
    // sets this field directly, bypassing that inbound-request lookup.
    private String apiKey;

    @Value("${salesworks.post.create.delay.ms:10000}")
    private long postCreateDelayMs;

    @Value("${salesworks.http.logging.enabled:false}")
    private boolean httpLoggingEnabled;

    // get-sales-leaders/get-user-types have no server-side pagination — Okta paging
    // through /v2/SalesLeaders or /v2/UserTypes at the SCIM level (observed: 6 pages
    // in one import burst) would otherwise re-fetch the full upstream dataset per page.
    // Default (20000) matches the DEFAULT_ENTITLEMENT_CACHE_TTL_MS used by the test
    // constructor below — keep both in sync if this default ever changes.
    @Value("${salesworks.entitlement.cache.ttl.ms:20000}")
    private long entitlementCacheTtlMs;

    // Not a secret — this is the fixed Basic Auth username Okta is configured to
    // send alongside the SalesWorks API key password (see resolveApiKey()).
    // Externalized to application.properties so it isn't flagged by
    // hardcoded-credential scanners.
    @Value("${salesworks.inbound.basic.auth.username:apiKey}")
    private String inboundBasicAuthUsername;

    private final TimedCache<List<Entitlement>> salesLeadersCache = new TimedCache<>(() -> entitlementCacheTtlMs);
    private final TimedCache<List<Entitlement>> userTypesCache = new TimedCache<>(() -> entitlementCacheTtlMs);

    private RestTemplate restTemplate;

    @org.springframework.beans.factory.annotation.Autowired
    public SalesWorksConnectorApi(SalesWorksMapper mapper, ObjectMapper objectMapper) {
        this.mapper = mapper;
        this.objectMapper = objectMapper;
        this.restTemplate = buildRestTemplate();
    }

    /** Test constructor — injects values directly, bypasses @PostConstruct validation. */
    public SalesWorksConnectorApi(SalesWorksMapper mapper, ObjectMapper objectMapper,
                                   String baseUrl, String apiKey, String personaName,
                                   String serviceBadge) {
        this.mapper = mapper;
        this.objectMapper = objectMapper;
        this.baseUrl = baseUrl;
        this.apiKey = apiKey;
        this.personaName = personaName;
        this.serviceBadge = serviceBadge;
        this.postCreateDelayMs = 0;
        // Matches the @Value default above — this constructor bypasses Spring
        // injection entirely, so without this the field would default to 0 and
        // defeat caching (every call would immediately re-fetch).
        this.entitlementCacheTtlMs = 20_000;
        // Matches the @Value default above — see entitlementCacheTtlMs comment.
        this.inboundBasicAuthUsername = "apiKey";
        this.restTemplate = buildRestTemplate();
    }

    private RestTemplate buildRestTemplate() {
        RestTemplate rt = new RestTemplate();
        rt.setErrorHandler(new ResponseErrorHandler() {
            @Override
            public boolean hasError(ClientHttpResponse response) throws IOException {
                int code = response.getStatusCode().value();
                // Treat 5xx as handled (we inspect body to distinguish not-found from error)
                return code >= 400 && code < 500;
            }

            @Override
            public void handleError(URI url, HttpMethod method, ClientHttpResponse response) throws IOException {
                int code = response.getStatusCode().value();
                throw new ScimErrorException(
                        HttpStatus.valueOf(code), "serverError",
                        "SalesWorks error: HTTP " + code);
            }
        });
        // Buffering lets the logging interceptor read the response body without
        // exhausting the stream before the message converter reads it too.
        rt.setRequestFactory(new BufferingClientHttpRequestFactory(rt.getRequestFactory()));
        // httpLoggingEnabled isn't injected yet at this point (this runs from the
        // constructor, before Spring populates @Value fields) — the interceptor
        // reads it lazily per-request via this supplier instead of capturing it now.
        rt.getInterceptors().add(new SalesWorksHttpLoggingInterceptor(() -> httpLoggingEnabled));
        return rt;
    }

    /** Test-only hook to exercise the logging-enabled path without a full Spring context. */
    public void setHttpLoggingEnabled(boolean enabled) {
        this.httpLoggingEnabled = enabled;
    }

    @Override
    @PostConstruct
    public void init() {
        String configPath = "application.properties (WEB-INF/classes/application.properties in the WAR)";
        if (baseUrl == null || baseUrl.isBlank()) {
            throw new IllegalStateException(
                    "salesworks.base.url is required — set it in " + configPath);
        }
        if (serviceBadge == null || serviceBadge.isBlank()) {
            throw new IllegalStateException(
                    "salesworks.service.badge is required — set it in " + configPath);
        }
        LOG.info("SalesWorksConnectorApi initialized, baseUrl={}", baseUrl);
    }

    // -------------------------------------------------------------------------
    // ConnectorApi implementation
    // -------------------------------------------------------------------------

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        JsonNode response = doGet(url("get-members?Badge=0&personaName=test"));
        List<ScimUserV2> all = mapper.toScimUsers(response.path("data"));

        if (filter != null && filter.isUserNameEq()) {
            String badge = filter.getValue();
            all = all.stream()
                    .filter(u -> badge.equals(u.getUserName()))
                    .collect(java.util.stream.Collectors.toList());
        }
        return all;
    }

    @Override
    public ScimUserV2 getUser(String id) {
        // get-member is confirmed broken against the real SalesWorks API
        // (out-of-band testing) — fetch the full list and filter in-memory
        // instead, same as core's own create-if-exists lookup already does.
        ScimFilter filter = new ScimFilter("userName", ScimFilter.Operator.EQ, id, null);
        List<ScimUserV2> matches = getUsers(1, 1, filter);
        return matches.isEmpty() ? null : matches.get(0);
    }

    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        String body = serialize(mapper.toCreateBody(user, personaName));
        doPost(url("create-member"), body);

        // Wait for SalesWorks propagation before fetching the created user (OQ-009)
        if (postCreateDelayMs > 0) {
            try {
                Thread.sleep(postCreateDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        ScimUserV2 created = getUser(user.getUserName());
        if (created == null) {
            // Return a minimal user if still not visible after delay
            user.setId(user.getUserName());
            user.setActive(true);
            return user;
        }
        return created;
    }

    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        // No profile update endpoint in SalesWorks — return current state.
        ScimUserV2 current = getUser(id);
        if (current != null) {
            return current;
        }
        // CONFIRMED (Okta admin console "Unassign User" test, live dev env):
        // get-members omits any Badge with zero current Sales Leaders. Core's
        // deactivate-then-strip PUT path (UserController.replace()) calls
        // deactivateUser() BEFORE this method, which removes every Sales Leader
        // via a single remove-member call — so a member with no OTHER leaders
        // besides the ones just stripped becomes invisible to get-members, even
        // though SalesWorks' own soft-removal semantics (OQ-004) mean the Badge
        // is still valid and re-addable via create-member. Returning null here
        // would make core treat this successful deactivation as a 404 ("User not
        // found after replace") — report the TRUE resulting state instead,
        // matching the incoming PUT's own intended active=false, the same
        // "synthesize the real outcome rather than 404" pattern used by
        // AnsiraConnectorApi.replaceUser for its own analogous "deactivation
        // makes the record invisible" case.
        ScimUserV2 stub = new ScimUserV2();
        stub.setId(id);
        stub.setUserName(id);
        stub.setActive(false);
        return stub;
    }

    @Override
    public void activateUser(String id) {
        // Reactivation = re-call create-member with Badge only (no entitlement context available).
        // Sales Leaders are pushed separately by Okta after reactivation.
        ScimUserV2 stub = new ScimUserV2();
        stub.setUserName(id);
        String body = serialize(mapper.toCreateBody(stub, personaName));
        doPost(url("create-member"), body);
        LOG.info("activateUser: re-created membership for Badge={}", id);
    }

    @Override
    public void deactivateUser(String id) {
        // Fetch current Sales Leaders to include in the remove-member body.
        List<UserEntitlement> ents = getEntitlements(id);
        String salesLeaderName = mapper.buildSalesLeaderName(ents);
        String body = serialize(mapper.toRemoveBody(id, personaName, salesLeaderName));
        doPost(url("remove-member"), body);
        LOG.info("deactivateUser: removed membership for Badge={}", id);
    }

    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 user = getUser(userId);
        if (user == null) {
            return List.of();
        }
        List<UserEntitlement> ents = user.getEntitlements();
        return ents != null ? new ArrayList<>(ents) : List.of();
    }

    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        // User Type entitlements are not mutable post-creation — no-op.
        if ("Analyst".equalsIgnoreCase(entitlementId) || "Sales".equalsIgnoreCase(entitlementId)) {
            LOG.debug("setEntitlement: User Type '{}' is not mutable — no-op", entitlementId);
            return;
        }

        // Sales Leader entitlement: delta add or remove.
        ScimUserV2 stub = new ScimUserV2();
        stub.setUserName(userId);
        if (add) {
            UserEntitlement ent = new UserEntitlement(entitlementId, entitlementId);
            ent.setType(SalesWorksMapper.TYPE_SALES_LEADERS);
            stub.getEntitlements().add(ent);
            String body = serialize(mapper.toCreateBody(stub, personaName));
            doPost(url("create-member"), body);
        } else {
            // Removing an already-absent entitlement must be a no-op (core's PATCH remove
            // path assumes this — see UserController's opp-patch.md §9 Idempotence comment).
            // Without this check, a redundant remove (e.g. Okta pushing both a profile PUT
            // and an entitlement-governance PATCH for the same revocation) calls remove-member
            // on a Sales Leader the member is no longer in, which SalesWorks rejects with 400.
            boolean currentlyAssigned = getEntitlements(userId).stream()
                    .anyMatch(ent -> entitlementId.equals(ent.getValue()));
            if (!currentlyAssigned) {
                LOG.debug("setEntitlement: '{}' already absent for Badge={} — no-op", entitlementId, userId);
                return;
            }
            String body = serialize(mapper.toRemoveBody(userId, personaName, entitlementId));
            doPost(url("remove-member"), body);
        }
    }

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        // SalesWorks has no Group concept — Sales Leaders and User Types are
        // modeled as their own dedicated resource types (SalesLeadersController,
        // UserTypesController), not as generic SCIM Groups. The prior/reference
        // implementation never had a Groups endpoint at all. Returning them here
        // too just duplicated the same get-sales-leaders/get-user-types calls
        // under a second resource path whenever Okta's Group Push happens to be
        // enabled, independent of what ResourceTypes actually advertises.
        return List.of();
    }

    @Override
    public List<Entitlement> listSalesLeaderEntitlements() {
        return salesLeadersCache.get(() -> {
            JsonNode response = doGet(url("get-sales-leaders?Badge=" + serviceBadge));
            return toEntitlements(response.path("data"), SalesWorksMapper.TYPE_SALES_LEADERS);
        });
    }

    @Override
    public List<Entitlement> listUserTypeEntitlements() {
        return userTypesCache.get(() -> {
            JsonNode response = doGet(url("get-user-types?Badge=" + serviceBadge));
            return toEntitlements(response.path("data"), SalesWorksMapper.TYPE_USER_TYPES);
        });
    }

    private List<Entitlement> toEntitlements(JsonNode dataArray, String type) {
        List<Entitlement> result = new ArrayList<>();
        if (dataArray != null && dataArray.isArray()) {
            for (JsonNode node : dataArray) {
                String name = node.path("Name").asText(null);
                if (name == null || name.isBlank()) continue;
                Entitlement e = new Entitlement();
                e.setId(name);
                e.setDisplayName(name);
                e.setType(type);
                result.add(e);
            }
        }
        return result;
    }

    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------

    private String url(String path) {
        String base = baseUrl.endsWith("/") ? baseUrl : baseUrl + "/";
        return base + path;
    }

    private HttpHeaders apiKeyHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("apikey", resolveApiKey());
        return headers;
    }

    // Company standard: Okta is configured with Basic Authorization credentials
    // (static username "apiKey", password = the SalesWorks API key) and sends
    // them on every inbound SCIM request. We pass that password straight through
    // as the outbound "apikey" header instead of reading a locally-configured value.
    private String resolveApiKey() {
        if (apiKey != null && !apiKey.isBlank()) {
            return apiKey;
        }
        return apiKeyFromInboundBasicAuth();
    }

    private String apiKeyFromInboundBasicAuth() {
        String header = currentRequest().getHeader(HttpHeaders.AUTHORIZATION);
        if (header == null || !header.regionMatches(true, 0, "Basic ", 0, 6)) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Missing Basic Authorization header — Okta must be configured to send the " +
                            "SalesWorks API key as the Basic Auth password (username '" +
                            inboundBasicAuthUsername + "')");
        }

        String decoded;
        try {
            decoded = new String(Base64.getDecoder().decode(header.substring(6).trim()),
                    StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Malformed Basic Authorization header");
        }

        int colon = decoded.indexOf(':');
        if (colon < 0) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Malformed Basic Authorization header");
        }

        String username = decoded.substring(0, colon);
        String password = decoded.substring(colon + 1);
        if (!inboundBasicAuthUsername.equals(username)) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Basic Authorization username must be '" + inboundBasicAuthUsername + "'");
        }
        if (password.isBlank()) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "Basic Authorization password (the SalesWorks API key) must not be blank");
        }
        return password;
    }

    private HttpServletRequest currentRequest() {
        RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
        if (!(attrs instanceof ServletRequestAttributes servletAttrs)) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, null,
                    "No inbound HTTP request available to read the SalesWorks API key from");
        }
        return servletAttrs.getRequest();
    }

    private HttpHeaders writeHeaders() {
        HttpHeaders headers = apiKeyHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Accept", "*/*");
        return headers;
    }

    /**
     * GET that throws a ScimErrorException on any non-2xx response, 4xx or 5xx.
     * 5xx is retried with backoff (CONFIRMED live, non-prod: get-members sporadically
     * 500s with no apparent cause — the exact same request immediately retried via
     * Postman succeeds). 4xx is never retried; a malformed request won't fix itself.
     * Only GET is retried here — doPost (create-member/remove-member) is a separate,
     * deliberate decision since a write's retry-safety depends on whether the
     * original attempt actually landed before timing out, not just idempotence.
     */
    JsonNode doGet(String url) {
        ResponseEntity<String> resp = rawGet(url);
        int attempt = 0;
        while (resp.getStatusCode().is5xxServerError() && attempt < MAX_SERVER_ERROR_RETRIES) {
            attempt++;
            LOG.warn("SalesWorks HTTP {} on GET {} (attempt {}/{}) — retrying",
                    resp.getStatusCode().value(), url, attempt, MAX_SERVER_ERROR_RETRIES);
            backoffSleep(attempt);
            resp = rawGet(url);
        }
        // CONFIRMED (sporadic SalesWorks 5xx observed directly via Postman, non-prod):
        // the shared RestTemplate error handler's hasError() only flags 4xx — 5xx is
        // intentionally let through as a "normal" response (see buildRestTemplate()).
        // Without this check, a transient 500 on get-members silently parses as an
        // empty/malformed body, mapper.toScimUsers() sees no "data" array and returns
        // List.of(), and getUser()/getEntitlements() then report the member as
        // genuinely absent — indistinguishable from a real "not found". That false
        // signal propagates into setEntitlement's idempotence pre-check and into core's
        // UserController before/after getUser() checks, surfacing as a wrong silent
        // no-op or a false 404 instead of a retryable error. Fail loudly here instead,
        // after retries above have been exhausted.
        if (!resp.getStatusCode().is2xxSuccessful()) {
            throw new ScimErrorException(HttpStatus.valueOf(resp.getStatusCode().value()),
                    "serverError", "SalesWorks error on GET " + url + ": HTTP "
                            + resp.getStatusCode().value());
        }
        return parseJson(resp.getBody());
    }

    private ResponseEntity<String> rawGet(String url) {
        return restTemplate.exchange(url, HttpMethod.GET, new HttpEntity<>(apiKeyHeaders()), String.class);
    }

    // Same shape as scim-connector-blackline's execute()/backoffSleep (429-retry) and
    // scim-connector-prismacloud's execute() — established pattern in this codebase
    // for a bounded, backing-off retry around a transient upstream failure.
    private static final int MAX_SERVER_ERROR_RETRIES = 3;

    private static void backoffSleep(int attempt) {
        try {
            Thread.sleep(200L * (1L << attempt)); // 400ms, 800ms, 1600ms
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    void doPost(String url, String body) {
        restTemplate.exchange(url, HttpMethod.POST,
                new HttpEntity<>(body, writeHeaders()), String.class);
    }

    private JsonNode parseJson(String body) {
        if (body == null || body.isBlank()) {
            return objectMapper.createObjectNode();
        }
        try {
            return objectMapper.readTree(body);
        } catch (JacksonException e) {
            throw new ScimErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "serverError", "Failed to parse SalesWorks response: " + e.getMessage());
        }
    }

    private String serialize(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JacksonException e) {
            throw new ScimErrorException(HttpStatus.INTERNAL_SERVER_ERROR,
                    "serverError", "Failed to serialize request body: " + e.getMessage());
        }
    }
}
