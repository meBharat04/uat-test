package com.dell.webservice.scim.salesworks.api;

import java.util.function.LongSupplier;
import java.util.function.Supplier;

/**
 * Caches a single value for a configurable TTL. Built for get-sales-leaders/
 * get-user-types: SalesWorks has no server-side pagination on those endpoints
 * (they return the full dataset regardless of parameters), but Okta pages
 * through /v2/SalesLeaders and /v2/UserTypes at the SCIM level — without this,
 * a single Okta import burst (observed: 6 pages in a row) re-fetches the
 * entire upstream dataset once per page.
 *
 * Takes a LongSupplier rather than a fixed long: this is constructed inside
 * SalesWorksConnectorApi's constructor, before Spring has injected the
 * @Value-backed TTL onto that field (same reasoning as
 * SalesWorksHttpLoggingInterceptor's BooleanSupplier) — reading it lazily on
 * every get() means it always reflects the real configured value, and picks
 * up config changes on the next cache expiry without a restart.
 *
 * synchronized rather than a lock-free scheme: contention is rare (a handful of
 * requests within one import burst) and this also collapses a thundering herd of
 * concurrent page requests into a single upstream fetch instead of one each.
 */
class TimedCache<T> {

    private final LongSupplier ttlMillis;
    private T value;
    private long expiresAtMillis;

    TimedCache(LongSupplier ttlMillis) {
        this.ttlMillis = ttlMillis;
    }

    synchronized T get(Supplier<T> loader) {
        long now = System.currentTimeMillis();
        if (value == null || now >= expiresAtMillis) {
            value = loader.get();
            expiresAtMillis = now + ttlMillis.getAsLong();
        }
        return value;
    }
}
