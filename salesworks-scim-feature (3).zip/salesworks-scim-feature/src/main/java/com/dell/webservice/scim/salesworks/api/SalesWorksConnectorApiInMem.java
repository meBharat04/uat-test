package com.dell.webservice.scim.salesworks.api;

import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.Meta;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.dell.webservice.scim.salesworks.mapper.SalesWorksMapper;
import com.dell.webservice.scim.salesworks.pojos.SalesWorksScimUser;
import com.okta.ps.scim.utils.StandardLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Component
@Profile("in-memory")
public class SalesWorksConnectorApiInMem implements ConnectorApi, SalesWorksEntitlementSource {

    private static final StandardLogger LOG = StandardLogger.forClass(SalesWorksConnectorApiInMem.class);

    private final Map<String, ScimUserV2> members = new ConcurrentHashMap<>();
    private final List<Group> salesLeaders = new ArrayList<>();
    private final List<Group> userTypes = new ArrayList<>();

    @PostConstruct
    public void seed() {
        init();

        ScimUserV2 jane = newMember("111111", "Jane Smith", "Alice Leader");
        ScimUserV2 bob  = newMember("222222", "Bob Jones", "Alice Leader,Bob Leader");
        members.put(jane.getId(), jane);
        members.put(bob.getId(), bob);

        salesLeaders.add(makeGroup("Alice Leader"));
        salesLeaders.add(makeGroup("Bob Leader"));

        userTypes.add(makeGroup("Analyst"));
        userTypes.add(makeGroup("Sales"));

        LOG.info("SalesWorksConnectorApiInMem seeded {} members", members.size());
    }

    @Override
    public void init() {
        LOG.info("SalesWorksConnectorApiInMem initialized (in-memory, no real target).");
    }

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        return members.values().stream()
                .filter(u -> matches(u, filter))
                .collect(Collectors.toList());
    }

    @Override
    public ScimUserV2 getUser(String id) {
        return members.get(id);
    }

    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        user.setId(user.getUserName());
        Meta m = new Meta("User");
        m.setCreated(Instant.now());
        m.setLastModified(Instant.now());
        user.setMeta(m);
        user.setActive(true);
        members.put(user.getId(), user);
        return user;
    }

    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        // No update endpoint in SalesWorks — return current state.
        ScimUserV2 current = members.get(id);
        return current;
    }

    @Override
    public void activateUser(String id) {
        // Reactivation = re-create the membership. In InMem, just set active=true.
        ScimUserV2 u = members.get(id);
        if (u != null) {
            u.setActive(true);
        }
    }

    @Override
    public void deactivateUser(String id) {
        // Soft removal: mark inactive (mirrors remove-member semantics).
        ScimUserV2 u = members.get(id);
        if (u != null) {
            u.setActive(false);
        }
    }

    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 u = members.get(userId);
        return u == null ? List.of() : new ArrayList<>(u.getEntitlements());
    }

    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        ScimUserV2 u = members.get(userId);
        if (u == null) return;

        // User Type entitlements are not mutable — silently no-op.
        if ("Analyst".equalsIgnoreCase(entitlementId) || "Sales".equalsIgnoreCase(entitlementId)) {
            return;
        }

        // Sales Leader entitlement
        u.getEntitlements().removeIf(e ->
                entitlementId.equals(e.getValue())
                && SalesWorksMapper.TYPE_SALES_LEADERS.equals(e.getType()));
        if (add) {
            UserEntitlement ent = new UserEntitlement(entitlementId, entitlementId);
            ent.setType(SalesWorksMapper.TYPE_SALES_LEADERS);
            u.getEntitlements().add(ent);
        }
    }

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        // No Group concept in SalesWorks — see SalesWorksConnectorApi.getGroups().
        return List.of();
    }

    @Override
    public List<Entitlement> listSalesLeaderEntitlements() {
        return toEntitlements(salesLeaders, SalesWorksMapper.TYPE_SALES_LEADERS);
    }

    @Override
    public List<Entitlement> listUserTypeEntitlements() {
        return toEntitlements(userTypes, SalesWorksMapper.TYPE_USER_TYPES);
    }

    private static List<Entitlement> toEntitlements(List<Group> groups, String type) {
        List<Entitlement> result = new ArrayList<>();
        for (Group g : groups) {
            Entitlement e = new Entitlement();
            e.setId(g.getId());
            e.setDisplayName(g.getDisplayName());
            e.setType(type);
            result.add(e);
        }
        return result;
    }

    // -------------------------------------------------------------------------

    private static boolean matches(ScimUserV2 u, ScimFilter f) {
        if (f == null) return true;
        if (f.isUserNameEq()) {
            return f.getValue().equalsIgnoreCase(u.getUserName());
        }
        return true;
    }

    private static ScimUserV2 newMember(String badge, String displayName, String salesLeadersStr) {
        SalesWorksScimUser u = new SalesWorksScimUser();
        u.setId(badge);
        u.setUserName(badge);
        u.setDisplayName(displayName);
        u.setName(SalesWorksMapper.buildName(displayName));
        u.setActive(true);
        u.setImportAttributes(displayName, "Analyst", badge);
        Meta m = new Meta("User");
        m.setCreated(Instant.now());
        m.setLastModified(Instant.now());
        u.setMeta(m);
        for (String leader : salesLeadersStr.split(",")) {
            String name = leader.trim();
            if (!name.isEmpty()) {
                UserEntitlement e = new UserEntitlement(name, name);
                e.setType(SalesWorksMapper.TYPE_SALES_LEADERS);
                u.getEntitlements().add(e);
            }
        }
        UserEntitlement ut = new UserEntitlement("Analyst", "Analyst");
        ut.setType(SalesWorksMapper.TYPE_USER_TYPES);
        u.getEntitlements().add(ut);
        return u;
    }

    private static Group makeGroup(String name) {
        Group g = new Group();
        g.setId(name);
        g.setDisplayName(name);
        return g;
    }
}
