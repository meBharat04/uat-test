package com.dell.webservice.scim.salesworks.api;

import com.okta.ps.scim.pojos.Entitlement;

import java.util.List;

/**
 * Connector-internal contract for fetching the live entitlement catalog.
 * Implemented by both the real and in-memory connector API so that
 * SalesWorksDescriptor can back GET /v2/Entitlements without a core change.
 */
public interface SalesWorksEntitlementSource {
    List<Entitlement> listSalesLeaderEntitlements();
    List<Entitlement> listUserTypeEntitlements();
}
