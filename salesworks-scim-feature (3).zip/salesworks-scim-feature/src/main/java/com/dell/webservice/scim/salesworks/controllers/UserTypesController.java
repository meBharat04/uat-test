package com.dell.webservice.scim.salesworks.controllers;

import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.ScimResourceList;
import com.dell.webservice.scim.salesworks.api.SalesWorksEntitlementSource;
import com.okta.ps.scim.scim.PaginationHelper;
import com.okta.ps.scim.scim.ScimErrorException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Dedicated resource type for User Type entitlements, mirroring the
 * UserTypes resource type advertised by SalesWorksDescriptor.resourceTypes().
 * Kept separate from the generic /v2/Entitlements catalog — see SalesLeadersController.
 */
@RestController
@RequestMapping(path = {"/v2/UserTypes", "/scim/v2/UserTypes"},
        produces = {"application/scim+json", "application/json"})
public class UserTypesController {

    private final SalesWorksEntitlementSource entitlementSource;

    public UserTypesController(SalesWorksEntitlementSource entitlementSource) {
        this.entitlementSource = entitlementSource;
    }

    @GetMapping
    public ScimResourceList<Entitlement> list(
            @RequestParam(value = "startIndex", required = false) Integer startIndex,
            @RequestParam(value = "count", required = false) Integer count) {
        int normStart = PaginationHelper.normalizeStartIndex(startIndex);
        int normCount = PaginationHelper.normalizeCount(count);
        List<Entitlement> all = entitlementSource.listUserTypeEntitlements();
        return PaginationHelper.page(all, normStart, normCount);
    }

    @GetMapping("/{id}")
    public Entitlement get(@PathVariable String id) {
        for (Entitlement e : entitlementSource.listUserTypeEntitlements()) {
            if (id.equals(e.getId())) {
                return e;
            }
        }
        throw ScimErrorException.notFound("UserTypes entitlement not found: " + id);
    }
}
