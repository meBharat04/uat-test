package com.dell.webservice.scim.salesworks.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.okta.ps.scim.pojos.ScimUserV2;

/**
 * SalesWorks-specific import attributes (accountName, categoryName, accountId)
 * per "Config Salesworks.docx": SalesWorks-to-Okta mapping is
 * appuser.AccountName -> accountName, appuser.categoryName -> categoryName,
 * appuser.accountId -> accountId.
 *
 * CORRECTED: exposed under a SalesWorks-specific extension URN, not the standard
 * IETF enterprise extension (urn:...:extension:enterprise:2.0:User). Okta's admin
 * console appears to treat that well-known URN as having a fixed, hardcoded shape
 * (employeeNumber/costCenter/organization/division/department/manager) — reusing
 * it for these unrelated fields meant accountId never became visible/selectable
 * in Profile Editor's attribute mappings, which is required for the App-to-Okta
 * mapping ("Config Salesworks.docx": appuser.accountId -> accountId) that feeds
 * the Application Username format (user.accountId) configured on Sign On >
 * Credential Details. A connector-specific URN has no such hardcoded assumptions.
 *
 * Import-only: these three fields aren't accepted on create/update (there's no
 * SalesWorks endpoint that accepts them — create-member/remove-member only ever
 * take Badge/PersonaName/SalesLeaderName/CreatedBy), so this only needs to be
 * constructed on the read side (SalesWorksMapper.toScimUser()).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SalesWorksScimUser extends ScimUserV2 {

    public static final String EXTENSION_URN = "urn:okta:scim:schemas:extension:salesworks:1.0:User";

    @JsonProperty(EXTENSION_URN)
    private Extension salesWorksExtension;

    public Extension getSalesWorksExtension() { return salesWorksExtension; }
    public void setSalesWorksExtension(Extension salesWorksExtension) { this.salesWorksExtension = salesWorksExtension; }

    public void setImportAttributes(String accountName, String categoryName, String accountId) {
        Extension ext = new Extension();
        ext.setAccountName(accountName);
        ext.setCategoryName(categoryName);
        ext.setAccountId(accountId);
        this.salesWorksExtension = ext;
        getSchemas().add(EXTENSION_URN);
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Extension {
        private String accountName;
        private String categoryName;
        private String accountId;

        public String getAccountName() { return accountName; }
        public void setAccountName(String accountName) { this.accountName = accountName; }

        public String getCategoryName() { return categoryName; }
        public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

        public String getAccountId() { return accountId; }
        public void setAccountId(String accountId) { this.accountId = accountId; }
    }
}
