package com.dell.webservice.scim.salesworks.mapper;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.node.ObjectNode;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.Name;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.dell.webservice.scim.salesworks.pojos.SalesWorksScimUser;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class SalesWorksMapper {

    public static final String TYPE_SALES_LEADERS = "Sales Leaders";
    public static final String TYPE_USER_TYPES    = "User Types";

    private final ObjectMapper objectMapper;

    public SalesWorksMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    // ---- Target → SCIM (read direction) ------------------------------------

    public ScimUserV2 toScimUser(JsonNode memberNode) {
        SalesWorksScimUser user = new SalesWorksScimUser();
        String badge = memberNode.path("Account").asText(null);
        String accountName = memberNode.path("AccountName").asText(null);
        user.setId(badge);
        user.setUserName(badge);
        user.setDisplayName(accountName);
        // Okta's dashboard "Name" column is driven by name.givenName/familyName
        // (via its own base firstName/lastName), not displayName — without this,
        // "Name" showed blank despite AccountName already being present via
        // displayName and the enterprise-extension accountName.
        user.setName(buildName(accountName));
        user.setActive(true);
        // Import-only custom attributes per Config Salesworks.docx — accountId
        // mirrors Account/Badge (same value already used for id/userName).
        user.setImportAttributes(accountName, memberNode.path("CategoryName").asText(null), badge);

        // Sales Leader entitlements — comma-separated string
        String salesLeadersRaw = memberNode.path("SalesLeaders").asText(null);
        if (salesLeadersRaw != null && !salesLeadersRaw.isBlank()) {
            for (String leader : salesLeadersRaw.split(",")) {
                String name = leader.trim();
                if (!name.isEmpty()) {
                    UserEntitlement ent = new UserEntitlement(name, name);
                    ent.setType(TYPE_SALES_LEADERS);
                    user.getEntitlements().add(ent);
                }
            }
        }

        // User Type entitlement — GroupName field
        String groupName = memberNode.path("GroupName").asText(null);
        if (groupName != null && !groupName.isBlank()) {
            UserEntitlement ent = new UserEntitlement(groupName, groupName);
            ent.setType(TYPE_USER_TYPES);
            user.getEntitlements().add(ent);
        }

        return user;
    }

    /**
     * Splits a full name string into SCIM's name.givenName/familyName/formatted —
     * first token is givenName, the rest (joined) is familyName. AccountName has
     * no structured first/last split on the SalesWorks side, so this is a
     * best-effort split, matching the reference implementation's approach.
     */
    public static Name buildName(String fullName) {
        if (fullName == null || fullName.isBlank()) {
            return null;
        }
        String trimmed = fullName.trim();
        String[] parts = trimmed.split("\\s+");
        Name name = new Name();
        name.setFormatted(trimmed);
        name.setGivenName(parts[0]);
        if (parts.length > 1) {
            name.setFamilyName(String.join(" ", Arrays.asList(parts).subList(1, parts.length)));
        }
        return name;
    }

    public List<ScimUserV2> toScimUsers(JsonNode dataArray) {
        List<ScimUserV2> users = new ArrayList<>();
        if (dataArray != null && dataArray.isArray()) {
            for (JsonNode node : dataArray) {
                users.add(toScimUser(node));
            }
        }
        return users;
    }

    public List<Group> toGroups(JsonNode dataArray) {
        List<Group> groups = new ArrayList<>();
        if (dataArray != null && dataArray.isArray()) {
            for (JsonNode node : dataArray) {
                Group g = new Group();
                String name = node.path("Name").asText(null);
                g.setId(name);
                g.setDisplayName(name);
                groups.add(g);
            }
        }
        return groups;
    }

    // ---- SCIM → Target (write direction) -----------------------------------

    public ObjectNode toCreateBody(ScimUserV2 user, String personaName) {
        String badge = user.getUserName();
        List<UserEntitlement> entitlements = user.getEntitlements();
        String resolvedPersonaName = resolvePersonaName(entitlements, personaName);
        String salesLeaderName = buildSalesLeaderName(entitlements);

        ObjectNode body = objectMapper.createObjectNode();
        body.put("Badge", badge);
        body.put("PersonaName", resolvedPersonaName);
        body.put("SalesLeaderName", salesLeaderName);
        body.put("CreatedBy", badge);
        return body;
    }

    public ObjectNode toRemoveBody(String badge, String personaName, String salesLeaderName) {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("Badge", badge);
        body.put("PersonaName", personaName);
        body.put("SalesLeaderName", salesLeaderName != null ? salesLeaderName : "");
        return body;
    }

    /**
     * Returns comma-joined Sales Leader names from the given entitlement list.
     * User Type entitlements (see isUserTypeEntitlement) are excluded — they set
     * PersonaName instead, via resolvePersonaName.
     */
    public String buildSalesLeaderName(List<UserEntitlement> entitlements) {
        if (entitlements == null || entitlements.isEmpty()) {
            return "";
        }
        List<String> names = new ArrayList<>();
        for (UserEntitlement e : entitlements) {
            if (e.getValue() == null) continue;
            if (isUserTypeEntitlement(e)) continue;
            names.add(e.getValue());
        }
        return String.join(",", names);
    }

    /**
     * Returns the value of the first User Type entitlement found (see
     * isUserTypeEntitlement), or defaultPersonaName if none is present. An admin
     * assigning a User Type entitlement ("Analyst"/"Sales") means PersonaName for
     * that user, not another Sales Leader — the two are mutually exclusive fields
     * in the create-member/remove-member request bodies.
     */
    public String resolvePersonaName(List<UserEntitlement> entitlements, String defaultPersonaName) {
        if (entitlements != null) {
            for (UserEntitlement e : entitlements) {
                if (isUserTypeEntitlement(e) && e.getValue() != null && !e.getValue().isBlank()) {
                    return e.getValue();
                }
            }
        }
        return defaultPersonaName;
    }

    /**
     * True if this entitlement represents a User Type ("Analyst"/"Sales"), not a
     * Sales Leader. Checks the type string we set ourselves (TYPE_USER_TYPES,
     * when reading a member back from SalesWorks) and the resourceType id we
     * advertise ("UserTypes", no space — likely what Okta echoes back on a
     * pushed entitlement), then falls back to matching the value directly, since
     * "Analyst"/"Sales" are the only two possible User Type values regardless of
     * what type string convention the caller happens to use.
     */
    public boolean isUserTypeEntitlement(UserEntitlement e) {
        if (e == null) {
            return false;
        }
        String type = e.getType();
        if (TYPE_USER_TYPES.equalsIgnoreCase(type) || "UserTypes".equalsIgnoreCase(type)) {
            return true;
        }
        return isUserTypeValue(e.getValue());
    }

    private static boolean isUserTypeValue(String value) {
        return "Analyst".equalsIgnoreCase(value) || "Sales".equalsIgnoreCase(value);
    }
}
