package com.dell.webservice.scim.salesworks.api;

import com.okta.ps.scim.utils.StandardLogger;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.function.BooleanSupplier;

/**
 * Logs every outbound request/response to the SalesWorks API — method, URL,
 * request body, response status, response body — to its own logger (routed to
 * a dedicated file via log4j2-salesworks.xml, not the console/app log).
 *
 * Deliberately never logs headers, since every request carries the apikey header
 * (see SalesWorksConnectorApi.apiKeyHeaders()) and this is meant to be safe to
 * leave enabled while pasting log output into a support ticket.
 *
 * Requires the RestTemplate's request factory to be wrapped in
 * BufferingClientHttpRequestFactory — otherwise reading the response body here
 * would exhaust the stream before the message converter reads it.
 *
 * Takes a BooleanSupplier rather than a plain boolean: this interceptor is built
 * inside SalesWorksConnectorApi's constructor, before Spring has injected the
 * @Value-backed enabled flag onto that field. Reading the flag lazily on every
 * request — instead of capturing it once at construction time — means it always
 * reflects the real configured value by the time any HTTP call actually happens.
 */
public class SalesWorksHttpLoggingInterceptor implements ClientHttpRequestInterceptor {

    private static final StandardLogger LOG = StandardLogger.forClass(SalesWorksHttpLoggingInterceptor.class);

    private final BooleanSupplier enabled;

    public SalesWorksHttpLoggingInterceptor(BooleanSupplier enabled) {
        this.enabled = enabled;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        if (!enabled.getAsBoolean()) {
            return execution.execute(request, body);
        }

        LOG.info("--> {} {}\n{}", request.getMethod(), request.getURI(), bodyAsString(body));

        ClientHttpResponse response = execution.execute(request, body);

        String responseBody = new String(response.getBody().readAllBytes(), StandardCharsets.UTF_8);
        LOG.info("<-- {} {} {}\n{}", response.getStatusCode(), request.getMethod(), request.getURI(), responseBody);

        return response;
    }

    private static String bodyAsString(byte[] body) {
        return (body == null || body.length == 0) ? "(no body)" : new String(body, StandardCharsets.UTF_8);
    }
}
