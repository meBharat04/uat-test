package com.okta.ps.scim.synchro.api;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.synchro.mapper.SynchroMapper;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import com.okta.ps.scim.utils.StandardLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClient;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Synchro ConnectorApi implementation.
 *
 * Auth is a per-request relay, not a stored credential: Okta encodes
 * Synchro's real clientId/clientSecret as the Basic Auth username/password
 * and sends {@code Authorization: Basic <base64>} on every incoming SCIM
 * request. {@link SynchroBasicAuthFilter} decodes that header into
 * {@link SynchroCredentialsContext} for the life of the request only; this
 * class reads it from there (never from Vault/env/config) to log into
 * Synchro (POST {@code authlayer/external/login}) and obtain a bearer token,
 * cached in the same request-scoped context so multiple outbound calls
 * triggered by one incoming request (e.g. entitlement diff -> several
 * setEntitlement calls) share a single login. Credentials/tokens are never
 * logged.
 *
 * replaceUser is a documented no-op: no profile-update endpoint exists on
 * the target.
 *
 * Group membership: confirmed against a real target response that
 * {@code gruCodigo} and {@code nome} are always the same string, so the
 * per-user "grupos" name list is already the canonical entitlement id — no
 * catalog lookup is needed (see SynchroMapper).
 */
@Component
public class SynchroConnectorApi implements ConnectorApi {

    private static final StandardLogger LOG = StandardLogger.forClass(SynchroConnectorApi.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Value("${synchro.base_url:}")
    private String baseUrl;

    @Value("${synchro.login_path:authlayer/external/login}")
    private String loginPath = "authlayer/external/login";

    @Value("${synchro.users_path:synchro4me-corporativo-api/api/v1/usuario/}")
    private String usersPath = "synchro4me-corporativo-api/api/v1/usuario/";

    @Value("${synchro.groups_path:synchro4me-corporativo-api/api/v1/grupo-usuarios/}")
    private String groupsPath = "synchro4me-corporativo-api/api/v1/grupo-usuarios/";

    @Value("${synchro.add_group_path_suffix:/grupos/adicionar}")
    private String addGroupPathSuffix = "/grupos/adicionar";

    @Value("${synchro.remove_group_path_suffix:/grupos/remover}")
    private String removeGroupPathSuffix = "/grupos/remover";

    @Value("${synchro.activate_path_suffix:/ativar}")
    private String activatePathSuffix = "/ativar";

    @Value("${synchro.deactivate_path_suffix:/desativar}")
    private String deactivatePathSuffix = "/desativar";

    @Value("${synchro.disable_reason:IDN Termination}")
    private String disableReason;

    @Value("${synchro.enable_reason:IdentityNow reactivation}")
    private String enableReason;

    private final RestClient restClient = RestClient.create();

    @PostConstruct
    @Override
    public void init() {
        LOG.info("SynchroConnectorApi initialized (per-request Basic Auth relay). base_url={}", baseUrl);
    }

    // -------------------------------------------------------------------------
    // getUsers
    // -------------------------------------------------------------------------

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        String token = currentAccessToken();
        // notFoundReturnsNull=false: a 404 on the users COLLECTION endpoint means the
        // target is unavailable/misconfigured, not "zero users exist". Conflating the two
        // (as a bare get() would) turns a paged-import failure into a silently truncated,
        // apparently-successful empty page — see Okta OPP-1123270 (unintended
        // deprovisioning from a premature/incomplete import).
        JsonNode response = get(baseUrl + usersPath, token, false);

        List<ScimUserV2> all = new ArrayList<>();
        if (response != null && response.isArray()) {
            for (JsonNode node : response) {
                ScimUserV2 user = SynchroMapper.targetUserToScim(node);
                if (matchesFilter(user, filter)) {
                    all.add(user);
                }
            }
        }
        return all;
    }

    // -------------------------------------------------------------------------
    // getUser
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 getUser(String id) {
        String token = currentAccessToken();
        JsonNode response = get(baseUrl + usersPath + id, token);
        if (response == null || response.isNull() || response.isMissingNode()) {
            return null;
        }
        return SynchroMapper.targetUserDetailToScim(response);
    }

    // -------------------------------------------------------------------------
    // getEntitlements — delegates to getUser
    // -------------------------------------------------------------------------

    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 user = getUser(userId);
        return user == null ? List.of() : new ArrayList<>(user.getEntitlements());
    }

    // -------------------------------------------------------------------------
    // createUser
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        String token = currentAccessToken();
        Map<String, Object> payload = SynchroMapper.scimUserToCreatePayload(user);
        LOG.info("createUser codigoUsuario={}", payload.get("codigoUsuario"));
        JsonNode response = postJson(baseUrl + usersPath, payload, token);
        if (response == null || response.isNull() || response.isMissingNode()) {
            return user;
        }
        return SynchroMapper.targetUserToScim(response);
    }

    // -------------------------------------------------------------------------
    // replaceUser — documented no-op, no update endpoint exists on the target
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        LOG.debug("replaceUser: profile update not supported by Synchro target; returning current user unchanged. id={}", id);
        return getUser(id);
    }

    // -------------------------------------------------------------------------
    // activateUser / deactivateUser
    // -------------------------------------------------------------------------

    @Override
    public void activateUser(String id) {
        String token = currentAccessToken();
        Map<String, Object> payload = SynchroMapper.motivoPayload(enableReason);
        LOG.info("activateUser id={}", id);
        putJson(baseUrl + usersPath + id + activatePathSuffix, payload, token);
    }

    @Override
    public void deactivateUser(String id) {
        String token = currentAccessToken();
        Map<String, Object> payload = SynchroMapper.motivoPayload(disableReason);
        LOG.info("deactivateUser id={}", id);
        putJson(baseUrl + usersPath + id + deactivatePathSuffix, payload, token);
    }

    // -------------------------------------------------------------------------
    // setEntitlement — Add/Remove Group
    // -------------------------------------------------------------------------

    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        // Both directions must be idempotent (core's PATCH path assumes this — see
        // UserController's opp-patch.md §9 Idempotence comment). Without these checks, a
        // redundant PATCH (e.g. Okta pushing both a profile PUT and an entitlement-governance
        // PATCH for the same change, or re-running an import after a target-side change already
        // landed) posts a second "adicionar"/"remover" action the target either already
        // reflects or no longer has.
        boolean currentlyAssigned = getEntitlements(userId).stream()
                .anyMatch(ent -> entitlementId.equals(ent.getValue()));
        if (add && currentlyAssigned) {
            LOG.debug("setEntitlement: '{}' already assigned for userId={} — no-op", entitlementId, userId);
            return;
        }
        if (!add && !currentlyAssigned) {
            LOG.debug("setEntitlement: '{}' already absent for userId={} — no-op", entitlementId, userId);
            return;
        }
        String token = currentAccessToken();
        Map<String, Object> payload = SynchroMapper.codigoGrupoPayload(entitlementId);
        String suffix = add ? addGroupPathSuffix : removeGroupPathSuffix;
        LOG.info("setEntitlement userId={} entitlementId={} add={}", userId, entitlementId, add);
        putJson(baseUrl + usersPath + userId + suffix, payload, token);
    }

    // -------------------------------------------------------------------------
    // getGroups — entitlement catalog
    // -------------------------------------------------------------------------

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        String token = currentAccessToken();
        JsonNode response = get(baseUrl + groupsPath, token);

        List<Group> all = new ArrayList<>();
        if (response != null && response.isArray()) {
            for (JsonNode node : response) {
                all.add(SynchroMapper.targetGroupToGroup(node));
            }
        }
        return all;
    }

    // -------------------------------------------------------------------------
    // Per-request auth
    // -------------------------------------------------------------------------

    /**
     * Returns the Synchro bearer token for the current request, logging in
     * with the Basic-Auth-decoded credentials on first use and caching the
     * result for the rest of this request (see SynchroCredentialsContext).
     */
    private String currentAccessToken() {
        String cached = SynchroCredentialsContext.getToken();
        if (cached != null && !cached.isBlank()) {
            return cached;
        }

        SynchroCredentialsContext.Credentials creds = SynchroCredentialsContext.getCredentials();
        if (creds == null) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, "invalidValue",
                    "Missing Basic Authorization header with Synchro credentials");
        }

        JsonNode loginResponse = login(creds.clientId(), creds.clientSecret());
        String token = SynchroMapper.extractAccessToken(loginResponse);
        SynchroCredentialsContext.setToken(token);
        return token;
    }

    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------

    private JsonNode login(String clientId, String clientSecret) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("clientId", clientId);
        payload.put("clientSecret", clientSecret);

        try {
            String body = restClient.post()
                    .uri(baseUrl + loginPath)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(SynchroMapper.toJson(payload))
                    .retrieve()
                    .body(String.class);
            return parseBody(body);
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        }
    }

    private JsonNode get(String url, String token) {
        return get(url, token, true);
    }

    /**
     * @param notFoundReturnsNull whether a 404 should be treated as "resource genuinely
     *                            absent" (single-resource GETs, e.g. getUser) vs. an error
     *                            to propagate (collection GETs, e.g. getUsers — see caller).
     */
    private JsonNode get(String url, String token, boolean notFoundReturnsNull) {
        try {
            String body = restClient.get()
                    .uri(url)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .body(String.class);
            return parseBody(body);
        } catch (HttpClientErrorException e) {
            if (notFoundReturnsNull && e.getStatusCode() == HttpStatus.NOT_FOUND) {
                return null;
            }
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        } catch (HttpServerErrorException e) {
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        }
    }

    private JsonNode postJson(String url, Map<String, Object> payload, String token) {
        return write(url, HttpMethod.POST, payload, token);
    }

    private JsonNode putJson(String url, Map<String, Object> payload, String token) {
        return write(url, HttpMethod.PUT, payload, token);
    }

    private JsonNode write(String url, HttpMethod method, Map<String, Object> payload, String token) {
        try {
            String body = restClient.method(method)
                    .uri(url)
                    .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(SynchroMapper.toJson(payload))
                    .retrieve()
                    .body(String.class);
            return parseBody(body);
        } catch (HttpClientErrorException e) {
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        } catch (HttpServerErrorException e) {
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        }
    }

    private JsonNode parseBody(String body) {
        if (body == null || body.isBlank()) return null;
        try {
            return OBJECT_MAPPER.readTree(body);
        } catch (Exception e) {
            LOG.debug("Non-JSON response body: {}", body);
            return null;
        }
    }

    private static ScimErrorException toScimError(int status, String detail) {
        return new ScimErrorException(
                HttpStatus.valueOf(status),
                status == 404 ? "invalidValue" : "invalidSyntax",
                "Synchro API error " + status + ": " + detail);
    }

    private static boolean matchesFilter(ScimUserV2 user, ScimFilter filter) {
        if (filter == null) return true;
        if (filter.isUserNameEq()) {
            return filter.getValue() != null && filter.getValue().equalsIgnoreCase(user.getUserName());
        }
        return true;
    }

    // Package-private for test injection
    void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    void setDisableReason(String reason) { this.disableReason = reason; }
    void setEnableReason(String reason) { this.enableReason = reason; }
}
