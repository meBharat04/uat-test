package com.okta.ps.scim.synchro.api;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * ConnectorApi implementation tests against a WireMock target.
 * No Spring context needed — pure unit tests of the HTTP layer.
 *
 * Credentials are never injected via a stored config value: every test
 * populates {@link SynchroCredentialsContext} directly, mirroring exactly
 * what {@link SynchroBasicAuthFilter} does for a real incoming request
 * carrying a decoded Basic Authorization header.
 */
class SynchroConnectorApiTest {

    private static WireMockServer wireMock;
    private static String baseUrl;
    private SynchroConnectorApi api;

    @BeforeAll
    static void startWireMock() {
        wireMock = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        wireMock.start();
        baseUrl = "http://localhost:" + wireMock.port() + "/";
    }

    @AfterAll
    static void stopWireMock() {
        wireMock.stop();
    }

    @BeforeEach
    void setup() {
        wireMock.resetAll();
        api = new SynchroConnectorApi();
        api.setBaseUrl(baseUrl);
        api.setDisableReason("IDN Termination");
        api.setEnableReason("IdentityNow reactivation");
        SynchroCredentialsContext.setCredentials("test-client", "test-secret");
        stubLogin("test-token");
    }

    @AfterEach
    void tearDown() {
        SynchroCredentialsContext.clear();
    }

    // -------------------------------------------------------------------------
    // init — no longer authenticates; that only happens per-request now
    // -------------------------------------------------------------------------

    @Test
    void init_isNoOpAndMakesNoNetworkCall() {
        assertDoesNotThrow(() -> new SynchroConnectorApi().init());
        wireMock.verify(0, postRequestedFor(anyUrl()));
        wireMock.verify(0, getRequestedFor(anyUrl()));
    }

    // -------------------------------------------------------------------------
    // per-request auth relay
    // -------------------------------------------------------------------------

    @Test
    void outboundCall_withNoCredentialsInContext_throws401() {
        SynchroCredentialsContext.clear();
        ScimErrorException ex = assertThrows(ScimErrorException.class, () -> api.getUsers(1, 50, null));
        assertEquals(401, ex.getStatus().value());
    }

    @Test
    void currentAccessToken_isCachedAcrossMultipleOutboundCalls() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(okJson("[]")));
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/grupo-usuarios/"))
                .willReturn(okJson("[]")));

        api.getUsers(1, 50, null);
        api.getGroups(1, 100);

        // Two outbound Synchro calls, but only one login — token cached in
        // SynchroCredentialsContext for the life of this "request" (thread).
        wireMock.verify(1, postRequestedFor(urlPathEqualTo("/authlayer/external/login")));
    }

    // -------------------------------------------------------------------------
    // getUsers
    // -------------------------------------------------------------------------

    @Test
    void getUsers_returnsAllUsers() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(okJson("""
                        [{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":"alex@example.com"},
                         {"codigo":"SYNTH002","nome":"Jordan","indicaAtivo":"S","email":"jordan@example.com"}]
                        """)));

        List<ScimUserV2> users = api.getUsers(1, 50, null);
        assertEquals(2, users.size());
        assertEquals("SYNTH001", users.get(0).getId());

        wireMock.verify(getRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .withHeader("Authorization", equalTo("Bearer test-token")));
    }

    @Test
    void getUsers_emptyResponseReturnsEmptyList() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(okJson("[]")));

        assertTrue(api.getUsers(1, 50, null).isEmpty());
    }

    @Test
    void getUsers_userNameEqFilterAppliedClientSide() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(okJson("""
                        [{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":""},
                         {"codigo":"SYNTH002","nome":"Jordan","indicaAtivo":"S","email":""}]
                        """)));

        ScimFilter filter = new ScimFilter("userName", ScimFilter.Operator.EQ, "SYNTH001", null);
        List<ScimUserV2> users = api.getUsers(1, 50, filter);
        assertEquals(1, users.size());
        assertEquals("SYNTH001", users.get(0).getUserName());
    }

    @Test
    void getUsers_5xxProducesScimError() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(serverError()));

        assertThrows(ScimErrorException.class, () -> api.getUsers(1, 50, null));
    }

    // A 404 on the users COLLECTION endpoint must propagate as an error, not silently
    // become an empty page — otherwise a paged import treats "target unavailable mid-import"
    // as "no more users", causing Okta to conclude the import finished and deprovision
    // anyone not seen in the truncated result (see Okta OPP-1123270).
    @Test
    void getUsers_404DuringImportProducesScimErrorRatherThanEmptyList() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(notFound()));

        assertThrows(ScimErrorException.class, () -> api.getUsers(1, 50, null));
    }

    // -------------------------------------------------------------------------
    // getUser — grupos names map directly to entitlements, no catalog lookup
    // -------------------------------------------------------------------------

    @Test
    void getUser_returnsUserWithEntitlementsFromGroupNames() {
        stubUserDetail("SYNTH001", """
                {"usuario":{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":"alex@example.com"},
                 "grupos":["AP_RELATORIOS"]}
                """);

        ScimUserV2 user = api.getUser("SYNTH001");
        assertNotNull(user);
        assertEquals("SYNTH001", user.getId());
        assertEquals(1, user.getEntitlements().size());
        assertEquals("AP_RELATORIOS", user.getEntitlements().get(0).getValue());
    }

    @Test
    void getUser_404ReturnsNull() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/UNKNOWN"))
                .willReturn(notFound()));

        assertNull(api.getUser("UNKNOWN"));
    }

    @Test
    void getUser_5xxProducesScimError() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001"))
                .willReturn(serverError()));

        assertThrows(ScimErrorException.class, () -> api.getUser("SYNTH001"));
    }

    // -------------------------------------------------------------------------
    // getEntitlements — delegates to getUser
    // -------------------------------------------------------------------------

    @Test
    void getEntitlements_delegatesToGetUser() {
        stubUserDetail("SYNTH001", """
                {"usuario":{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":""},
                 "grupos":["CONSULTA"]}
                """);

        List<UserEntitlement> ents = api.getEntitlements("SYNTH001");
        assertEquals(1, ents.size());
        assertEquals("CONSULTA", ents.get(0).getValue());
    }

    @Test
    void getEntitlements_userNotFoundReturnsEmptyList() {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/GHOST"))
                .willReturn(notFound()));

        assertTrue(api.getEntitlements("GHOST").isEmpty());
    }

    // -------------------------------------------------------------------------
    // createUser
    // -------------------------------------------------------------------------

    @Test
    void createUser_postsCreateEndpoint() {
        wireMock.stubFor(post(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(okJson("""
                        {"codigo":"SYNTH003","nome":"New User","indicaAtivo":"S","email":"new@example.com"}
                        """)));

        ScimUserV2 user = new ScimUserV2();
        user.setUserName("SYNTH003");
        user.setDisplayName("New User");

        ScimUserV2 created = api.createUser(user);
        assertNotNull(created);
        assertEquals("SYNTH003", created.getId());

        wireMock.verify(postRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .withRequestBody(matchingJsonPath("$.codigoUsuario", equalTo("SYNTH003"))));
    }

    @Test
    void createUser_5xxProducesScimError() {
        wireMock.stubFor(post(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/"))
                .willReturn(serverError()));

        ScimUserV2 user = new ScimUserV2();
        user.setUserName("SYNTH003");
        assertThrows(ScimErrorException.class, () -> api.createUser(user));
    }

    // -------------------------------------------------------------------------
    // replaceUser — no-op, no update endpoint exists
    // -------------------------------------------------------------------------

    @Test
    void replaceUser_returnsCurrentUserWithoutAnyWriteCall() {
        stubUserDetail("SYNTH001", """
                {"usuario":{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":""},
                 "grupos":[]}
                """);

        ScimUserV2 incoming = new ScimUserV2();
        incoming.setDisplayName("Ignored Update");

        ScimUserV2 result = api.replaceUser("SYNTH001", incoming);
        assertNotNull(result);
        assertEquals("Alex", result.getDisplayName());

        // The login POST (a different path) still happens — only assert no
        // write call was made to a Synchro user endpoint.
        wireMock.verify(0, postRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/")));
        wireMock.verify(0, putRequestedFor(anyUrl()));
    }

    // -------------------------------------------------------------------------
    // activateUser / deactivateUser — paths confirmed against a real target
    // response to drop "/grupos/" (unlike Add/Remove Group, which keep it)
    // -------------------------------------------------------------------------

    @Test
    void activateUser_putsAtivarWithConfiguredMotivo() {
        wireMock.stubFor(put(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/ativar"))
                .willReturn(okJson("{}")));

        api.activateUser("SYNTH001");

        wireMock.verify(putRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/ativar"))
                .withRequestBody(matchingJsonPath("$.motivo", equalTo("IdentityNow reactivation"))));
    }

    @Test
    void deactivateUser_putsDesativarWithConfiguredMotivo() {
        wireMock.stubFor(put(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/desativar"))
                .willReturn(okJson("{}")));

        api.deactivateUser("SYNTH001");

        wireMock.verify(putRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/desativar"))
                .withRequestBody(matchingJsonPath("$.motivo", equalTo("IDN Termination"))));
    }

    @Test
    void deactivateUser_5xxProducesScimError() {
        wireMock.stubFor(put(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/desativar"))
                .willReturn(serverError()));

        assertThrows(ScimErrorException.class, () -> api.deactivateUser("SYNTH001"));
    }

    // -------------------------------------------------------------------------
    // setEntitlement — Add/Remove Group; entitlementId is the group NAME
    // -------------------------------------------------------------------------

    @Test
    void setEntitlement_add_putsAdicionarWithCodigoGrupo() {
        // SYNTH001 does not yet have CONSULTA — add's idempotence guard checks current
        // entitlements first, same as the remove path, so this must be stubbed for the add
        // PUT to actually go out.
        stubUserDetail("SYNTH001", """
                {"usuario":{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":""},
                 "grupos":["AP_RELATORIOS"]}
                """);
        wireMock.stubFor(put(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/grupos/adicionar"))
                .willReturn(okJson("{}")));

        api.setEntitlement("SYNTH001", "CONSULTA", true);

        wireMock.verify(putRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/grupos/adicionar"))
                .withRequestBody(matchingJsonPath("$.codigoGrupo", equalTo("CONSULTA"))));
    }

    // Adding an entitlement SYNTH001 already has (e.g. a redundant PATCH add, or an import
    // re-running after the target-side add already landed) must not call the target at all.
    // Mirrors setEntitlement_removeAlreadyAbsentEntitlement_isNoOp for the add direction.
    @Test
    void setEntitlement_addAlreadyAssignedEntitlement_isNoOp() {
        stubUserDetail("SYNTH001", """
                {"usuario":{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":""},
                 "grupos":["CONSULTA"]}
                """);

        api.setEntitlement("SYNTH001", "CONSULTA", true);

        wireMock.verify(0, putRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/grupos/adicionar")));
    }

    @Test
    void setEntitlement_remove_putsRemoverWithCodigoGrupo() {
        // SYNTH001 currently has CONSULTA — setEntitlement's remove path now checks current
        // entitlements first (idempotence guard), so this must be stubbed for the remove
        // PUT to actually go out.
        stubUserDetail("SYNTH001", """
                {"usuario":{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":""},
                 "grupos":["CONSULTA"]}
                """);
        wireMock.stubFor(put(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/grupos/remover"))
                .willReturn(okJson("{}")));

        api.setEntitlement("SYNTH001", "CONSULTA", false);

        wireMock.verify(putRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/grupos/remover"))
                .withRequestBody(matchingJsonPath("$.codigoGrupo", equalTo("CONSULTA"))));
    }

    // Removing an entitlement SYNTH001 was never assigned (or was already removed, e.g. by an
    // earlier PUT in the same Okta push) must not call the target at all. Without this guard,
    // Okta pushing both a profile PUT and an entitlement-governance PATCH for the same
    // revocation causes a redundant remove call (see opp-patch.md §9 Idempotence — core's
    // PATCH remove path assumes ConnectorApi.setEntitlement(..., false) is a no-op on an
    // already-absent value).
    @Test
    void setEntitlement_removeAlreadyAbsentEntitlement_isNoOp() {
        stubUserDetail("SYNTH001", """
                {"usuario":{"codigo":"SYNTH001","nome":"Alex","indicaAtivo":"S","email":""},
                 "grupos":["CONSULTA"]}
                """);

        api.setEntitlement("SYNTH001", "AP_RELATORIOS", false);

        wireMock.verify(0, putRequestedFor(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/SYNTH001/grupos/remover")));
    }

    // -------------------------------------------------------------------------
    // getGroups — entitlement catalog
    // -------------------------------------------------------------------------

    @Test
    void getGroups_returnsCatalog() {
        stubCatalog("""
                [{"gruCodigo":"AP_RELATORIOS","nome":"AP_RELATORIOS","descricao":"Reports","ativoFlag":"S"},
                 {"gruCodigo":"CONSULTA","nome":"CONSULTA","descricao":"Read only","ativoFlag":"S"}]
                """);

        List<Group> groups = api.getGroups(1, 100);
        assertEquals(2, groups.size());
        assertTrue(groups.stream().anyMatch(g -> "AP_RELATORIOS".equals(g.getId())));
    }

    // -------------------------------------------------------------------------
    // Stub helpers
    // -------------------------------------------------------------------------

    private void stubLogin(String token) {
        wireMock.stubFor(post(urlPathEqualTo("/authlayer/external/login"))
                .willReturn(okJson("""
                        {"success":true,"result":"","details":null,
                         "content":{"access_token":"%s","token_type":"Bearer","refresh_token":"","expiry":""},
                         "version":""}
                        """.formatted(token))));
    }

    private void stubUserDetail(String codigo, String body) {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/usuario/" + codigo))
                .willReturn(okJson(body)));
    }

    private void stubCatalog(String body) {
        wireMock.stubFor(get(urlPathEqualTo("/synchro4me-corporativo-api/api/v1/grupo-usuarios/"))
                .willReturn(okJson(body)));
    }
}
