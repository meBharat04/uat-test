package com.okta.ps.scim.delldatalake.mapper;

import tools.jackson.databind.JsonNode;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class DellDataLakeMapperTest {

    // ----- target -> SCIM: row grouping (rowsToScimUsers) -----

    @Test
    void rowsToScimUsers_groupsMultipleRowsForSameUserIntoOneScimUser() {
        JsonNode rows = DellDataLakeMapper.parse("""
                [{"requesteentId":"aastha_arora","entitlementId":"e1","schema":"s1","profile":"p1","requestorntId":null,"requestDetails":null},
                 {"requesteentId":"aastha_arora","entitlementId":"e2","schema":"s2","profile":"p2","requestorntId":null,"requestDetails":null}]
                """);
        List<ScimUserV2> users = DellDataLakeMapper.rowsToScimUsers(rows);
        assertEquals(1, users.size());
        assertEquals("aastha_arora", users.get(0).getUserName());
        assertEquals(2, users.get(0).getEntitlements().size());
    }

    @Test
    void rowsToScimUsers_separatesRowsForDifferentUsers() {
        JsonNode rows = DellDataLakeMapper.parse("""
                [{"requesteentId":"user_a","entitlementId":"e1","schema":"s1","profile":"p1"},
                 {"requesteentId":"user_b","entitlementId":"e2","schema":"s2","profile":"p2"}]
                """);
        List<ScimUserV2> users = DellDataLakeMapper.rowsToScimUsers(rows);
        assertEquals(2, users.size());
        assertTrue(users.stream().anyMatch(u -> "user_a".equals(u.getUserName())));
        assertTrue(users.stream().anyMatch(u -> "user_b".equals(u.getUserName())));
    }

    @Test
    void rowsToScimUsers_emptyArrayReturnsEmptyList() {
        JsonNode rows = DellDataLakeMapper.parse("[]");
        assertTrue(DellDataLakeMapper.rowsToScimUsers(rows).isEmpty());
    }

    @Test
    void rowsToScimUsers_preservesInsertionOrderOfFirstAppearance() {
        JsonNode rows = DellDataLakeMapper.parse("""
                [{"requesteentId":"user_b","entitlementId":"e1"},
                 {"requesteentId":"user_a","entitlementId":"e2"},
                 {"requesteentId":"user_b","entitlementId":"e3"}]
                """);
        List<ScimUserV2> users = DellDataLakeMapper.rowsToScimUsers(rows);
        assertEquals(2, users.size());
        assertEquals("user_b", users.get(0).getUserName());
        assertEquals("user_a", users.get(1).getUserName());
        assertEquals(2, users.get(0).getEntitlements().size());
    }

    @Test
    void rowsToScimUsers_activeIsAlwaysTrue() {
        JsonNode rows = DellDataLakeMapper.parse("""
                [{"requesteentId":"user_a","entitlementId":"e1"}]
                """);
        assertTrue(Boolean.TRUE.equals(DellDataLakeMapper.rowsToScimUsers(rows).get(0).getActive()));
    }

    @Test
    void rowsToScimUsers_entitlementValueAndDisplayAreTheEntitlementId() {
        JsonNode rows = DellDataLakeMapper.parse("""
                [{"requesteentId":"user_a","entitlementId":"4e27ab28-9372-43b3-acc7-7c77b4b6e471"}]
                """);
        UserEntitlement ue = DellDataLakeMapper.rowsToScimUsers(rows).get(0).getEntitlements().get(0);
        assertEquals("4e27ab28-9372-43b3-acc7-7c77b4b6e471", ue.getValue());
        assertEquals("4e27ab28-9372-43b3-acc7-7c77b4b6e471", ue.getDisplay());
        assertEquals(DellDataLakeMapper.TYPE_GROUP, ue.getType());
    }

    // ----- target -> SCIM: single-user row grouping -----

    @Test
    void rowsToSingleScimUser_foldsAllRowsForThatUser() {
        JsonNode rows = DellDataLakeMapper.parse("""
                [{"requesteentId":"aastha_arora","entitlementId":"e1"},
                 {"requesteentId":"aastha_arora","entitlementId":"e2"}]
                """);
        ScimUserV2 user = DellDataLakeMapper.rowsToSingleScimUser("aastha_arora", rows);
        assertNotNull(user);
        assertEquals("aastha_arora", user.getId());
        assertEquals(2, user.getEntitlements().size());
    }

    @Test
    void rowsToSingleScimUser_emptyArrayReturnsNull() {
        assertNull(DellDataLakeMapper.rowsToSingleScimUser("ghost", DellDataLakeMapper.parse("[]")));
    }

    @Test
    void rowsToSingleScimUser_nullRowsReturnsNull() {
        assertNull(DellDataLakeMapper.rowsToSingleScimUser("ghost", null));
    }

    // ----- target -> SCIM: group catalog -----

    @Test
    void targetGroupToGroup_mapsIdAndProfile() {
        JsonNode n = DellDataLakeMapper.parse("""
                {"id":"05567373-caf7-4d62-b0d6-ee3f12131683","application":"Dell Data Lake - VM",
                 "schema":"ws_cco_ops","profile":"ws_cco_ops_grp (Test Main)",
                 "propagationFlag":"false","configurationItem":"ddl_tst_main","status":"active"}
                """);
        Group g = DellDataLakeMapper.targetGroupToGroup(n);
        assertEquals("05567373-caf7-4d62-b0d6-ee3f12131683", g.getId());
        assertEquals("ws_cco_ops_grp (Test Main)", g.getDisplayName());
    }

    @Test
    void groupToEntitlement_setsIdDisplayNameAndType() {
        Group g = new Group();
        g.setId("gid");
        g.setDisplayName("gname");
        Entitlement e = DellDataLakeMapper.groupToEntitlement(g);
        assertEquals("gid", e.getId());
        assertEquals("gname", e.getDisplayName());
        assertEquals(DellDataLakeMapper.TYPE_GROUP, e.getType());
    }

    // ----- SCIM -> target: write payload builder -----

    @Test
    void writePayload_addAction_setsAllFields() {
        Map<String, Object> payload = DellDataLakeMapper.writePayload("add", "jdoe", "ent-1", "CI0011", "IDNCreation");
        assertEquals("add", payload.get("action"));
        assertEquals("CI0011", payload.get("ci"));
        assertEquals("ent-1", payload.get("entitlementId"));
        assertEquals("jdoe", payload.get("requestorNtId"));
        assertEquals("IDNCreation", payload.get("taskNumber"));
        assertEquals("jdoe", payload.get("userName"));
    }

    @Test
    void writePayload_removeAction_setsAction() {
        Map<String, Object> payload = DellDataLakeMapper.writePayload("remove", "jdoe", "ent-1", "CI0011", "IDNCreation");
        assertEquals("remove", payload.get("action"));
    }

    @Test
    void writePayload_requestorNtIdMirrorsUserName() {
        Map<String, Object> payload = DellDataLakeMapper.writePayload("add", "jdoe", "ent-1", "CI0011", "IDNCreation");
        assertEquals("jdoe", payload.get("requestorNtId"));
        assertEquals(payload.get("userName"), payload.get("requestorNtId"));
    }

    @Test
    void toJson_serializes() {
        Map<String, Object> m = Map.of("action", "add");
        assertTrue(DellDataLakeMapper.toJson(m).contains("action"));
    }
}
