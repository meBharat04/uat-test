package com.okta.ps.scim.delldatalake;

import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.delldatalake.api.DellDataLakeConnectorApiInMem;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@TestConfiguration
class ContractTestConfig {

    @Bean
    @Primary
    ConnectorApi connectorApi() {
        DellDataLakeConnectorApiInMem inMem = new DellDataLakeConnectorApiInMem();
        inMem.seed();
        return inMem;
    }
}
