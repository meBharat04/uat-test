package com.okta.ps.scim.delldatalake.api;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.jupiter.api.Assertions.*;

/**
 * ConnectorApi implementation tests against a WireMock target.
 * No Spring context needed — pure unit tests of the HTTP layer.
 *
 * Credentials are never injected via a stored config value: every test
 * populates {@link DellDataLakeCredentialsContext} directly, mirroring
 * exactly what {@link DellDataLakeBasicAuthFilter} does for a real incoming
 * request carrying a decoded Basic Authorization header. Unlike
 * synchro-scim, there is no login step to stub — this target authenticates
 * with Basic Auth directly on every call.
 */
class DellDataLakeConnectorApiTest {

    private static final String TEST_USERNAME = "test-user";
    private static final String TEST_PASSWORD = "test-pass";
    private static final String EXPECTED_BASIC_AUTH = "Basic " + Base64.getEncoder()
            .encodeToString((TEST_USERNAME + ":" + TEST_PASSWORD).getBytes(StandardCharsets.UTF_8));

    private static WireMockServer wireMock;
    private static String baseUrl;
    private DellDataLakeConnectorApi api;

    @BeforeAll
    static void startWireMock() {
        wireMock = new WireMockServer(WireMockConfiguration.options().dynamicPort());
        wireMock.start();
        baseUrl = "http://localhost:" + wireMock.port() + "/";
    }

    @AfterAll
    static void stopWireMock() {
        wireMock.stop();
    }

    @BeforeEach
    void setup() {
        wireMock.resetAll();
        api = new DellDataLakeConnectorApi();
        api.setBaseUrl(baseUrl);
        api.setWriteCi("CI0011");
        api.setWriteTaskNumber("IDNCreation");
        DellDataLakeCredentialsContext.setCredentials(TEST_USERNAME, TEST_PASSWORD);
    }

    @AfterEach
    void tearDown() {
        DellDataLakeCredentialsContext.clear();
    }

    // -------------------------------------------------------------------------
    // init — no network call, nothing to authenticate at startup
    // -------------------------------------------------------------------------

    @Test
    void init_isNoOpAndMakesNoNetworkCall() {
        assertDoesNotThrow(() -> new DellDataLakeConnectorApi().init());
        wireMock.verify(0, getRequestedFor(anyUrl()));
        wireMock.verify(0, postRequestedFor(anyUrl()));
    }

    // -------------------------------------------------------------------------
    // per-request auth relay
    // -------------------------------------------------------------------------

    @Test
    void outboundCall_withNoCredentialsInContext_throws401() {
        DellDataLakeCredentialsContext.clear();
        ScimErrorException ex = assertThrows(ScimErrorException.class, () -> api.getUsers(1, 50, null));
        assertEquals(401, ex.getStatus().value());
    }

    // -------------------------------------------------------------------------
    // getUsers — flat rows grouped by requesteentId
    // -------------------------------------------------------------------------

    @Test
    void getUsers_groupsFlatRowsIntoOneUserPerRequesteentId() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("""
                        [{"requesteentId":"aastha_arora","entitlementId":"e1","schema":"s1","profile":"p1"},
                         {"requesteentId":"aastha_arora","entitlementId":"e2","schema":"s2","profile":"p2"},
                         {"requesteentId":"aarushi_shanker","entitlementId":"e3","schema":"s3","profile":"p3"}]
                        """)));

        List<ScimUserV2> users = api.getUsers(1, 50, null);
        assertEquals(2, users.size());
        ScimUserV2 aastha = users.stream().filter(u -> "aastha_arora".equals(u.getUserName())).findFirst().orElseThrow();
        assertEquals(2, aastha.getEntitlements().size());

        wireMock.verify(getRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .withHeader("Authorization", equalTo(EXPECTED_BASIC_AUTH)));
    }

    @Test
    void getUsers_emptyResponseReturnsEmptyList() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("[]")));

        assertTrue(api.getUsers(1, 50, null).isEmpty());
    }

    @Test
    void getUsers_userNameEqFilterAppliedClientSideAfterGrouping() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("""
                        [{"requesteentId":"user_a","entitlementId":"e1"},
                         {"requesteentId":"user_b","entitlementId":"e2"}]
                        """)));

        ScimFilter filter = new ScimFilter("userName", ScimFilter.Operator.EQ, "user_a", null);
        List<ScimUserV2> users = api.getUsers(1, 50, filter);
        assertEquals(1, users.size());
        assertEquals("user_a", users.get(0).getUserName());
    }

    @Test
    void getUsers_5xxProducesScimError() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(serverError()));

        assertThrows(ScimErrorException.class, () -> api.getUsers(1, 50, null));
    }

    // A 404 on the users COLLECTION endpoint must propagate as an error, not silently
    // become an empty page — otherwise a paged import treats "target unavailable mid-import"
    // as "no more users", causing Okta to conclude the import finished and deprovision
    // anyone not seen in the truncated result (see Okta OPP-1123270).
    @Test
    void getUsers_404DuringImportProducesScimErrorRatherThanEmptyList() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(notFound()));

        assertThrows(ScimErrorException.class, () -> api.getUsers(1, 50, null));
    }

    // -------------------------------------------------------------------------
    // getUser
    // -------------------------------------------------------------------------

    @Test
    void getUser_returnsUserWithEntitlementsFromRows() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/aastha_arora"))
                .willReturn(okJson("""
                        [{"requesteentId":"aastha_arora","entitlementId":"e1","schema":"s1","profile":"p1"},
                         {"requesteentId":"aastha_arora","entitlementId":"e2","schema":"s2","profile":"p2"}]
                        """)));

        ScimUserV2 user = api.getUser("aastha_arora");
        assertNotNull(user);
        assertEquals("aastha_arora", user.getId());
        assertEquals(2, user.getEntitlements().size());
    }

    @Test
    void getUser_emptyArrayReturnsNull() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/ghost"))
                .willReturn(okJson("[]")));

        assertNull(api.getUser("ghost"));
    }

    @Test
    void getUser_404ReturnsNull() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/ghost"))
                .willReturn(notFound()));

        assertNull(api.getUser("ghost"));
    }

    @Test
    void getUser_5xxProducesScimError() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/aastha_arora"))
                .willReturn(serverError()));

        assertThrows(ScimErrorException.class, () -> api.getUser("aastha_arora"));
    }

    // -------------------------------------------------------------------------
    // getEntitlements — delegates to getUser
    // -------------------------------------------------------------------------

    @Test
    void getEntitlements_delegatesToGetUser() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/aastha_arora"))
                .willReturn(okJson("""
                        [{"requesteentId":"aastha_arora","entitlementId":"e1"}]
                        """)));

        List<UserEntitlement> ents = api.getEntitlements("aastha_arora");
        assertEquals(1, ents.size());
        assertEquals("e1", ents.get(0).getValue());
    }

    @Test
    void getEntitlements_userNotFoundReturnsEmptyList() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/ghost"))
                .willReturn(okJson("[]")));

        assertTrue(api.getEntitlements("ghost").isEmpty());
    }

    // -------------------------------------------------------------------------
    // createUser — no distinct create-account endpoint
    // -------------------------------------------------------------------------

    @Test
    void createUser_postsAddForFirstEntitlement() {
        wireMock.stubFor(post(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("{}")));

        ScimUserV2 user = new ScimUserV2();
        user.setUserName("jdoe");
        UserEntitlement ue = new UserEntitlement("ent-1", "ent-1");
        user.getEntitlements().add(ue);

        ScimUserV2 created = api.createUser(user);
        assertNotNull(created);

        wireMock.verify(postRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .withHeader("Authorization", equalTo(EXPECTED_BASIC_AUTH))
                .withRequestBody(matchingJsonPath("$.action", equalTo("add")))
                .withRequestBody(matchingJsonPath("$.userName", equalTo("jdoe")))
                .withRequestBody(matchingJsonPath("$.entitlementId", equalTo("ent-1")))
                .withRequestBody(matchingJsonPath("$.ci", equalTo("CI0011")))
                .withRequestBody(matchingJsonPath("$.taskNumber", equalTo("IDNCreation"))));
    }

    @Test
    void createUser_postsOneAddCallPerAdditionalEntitlement() {
        wireMock.stubFor(post(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("{}")));

        ScimUserV2 user = new ScimUserV2();
        user.setUserName("jdoe");
        user.getEntitlements().add(new UserEntitlement("ent-1", "ent-1"));
        user.getEntitlements().add(new UserEntitlement("ent-2", "ent-2"));

        api.createUser(user);

        wireMock.verify(2, postRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user")));
        wireMock.verify(postRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .withRequestBody(matchingJsonPath("$.entitlementId", equalTo("ent-1"))));
        wireMock.verify(postRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .withRequestBody(matchingJsonPath("$.entitlementId", equalTo("ent-2"))));
    }

    @Test
    void createUser_setsIdToUserName() {
        wireMock.stubFor(post(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("{}")));

        ScimUserV2 user = new ScimUserV2();
        user.setUserName("jdoe");
        user.getEntitlements().add(new UserEntitlement("ent-1", "ent-1"));

        ScimUserV2 created = api.createUser(user);
        assertEquals("jdoe", created.getId());
    }

    @Test
    void createUser_noEntitlements_doesNotCallTargetAtAll() {
        ScimUserV2 user = new ScimUserV2();
        user.setUserName("jdoe");

        ScimUserV2 result = api.createUser(user);
        assertSame(user, result);
        wireMock.verify(0, postRequestedFor(anyUrl()));
    }

    @Test
    void createUser_5xxProducesScimError() {
        wireMock.stubFor(post(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(serverError()));

        ScimUserV2 user = new ScimUserV2();
        user.setUserName("jdoe");
        user.getEntitlements().add(new UserEntitlement("ent-1", "ent-1"));

        assertThrows(ScimErrorException.class, () -> api.createUser(user));
    }

    // -------------------------------------------------------------------------
    // replaceUser / activateUser / deactivateUser — documented no-ops
    // -------------------------------------------------------------------------

    @Test
    void replaceUser_returnsCurrentUserWithoutAnyWriteCall() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/jdoe"))
                .willReturn(okJson("""
                        [{"requesteentId":"jdoe","entitlementId":"e1"}]
                        """)));

        ScimUserV2 incoming = new ScimUserV2();
        incoming.setUserName("jdoe-ignored");

        ScimUserV2 result = api.replaceUser("jdoe", incoming);
        assertNotNull(result);
        assertEquals("jdoe", result.getUserName());

        wireMock.verify(0, postRequestedFor(anyUrl()));
    }

    @Test
    void activateUser_isNoOpMakesNoHttpCall() {
        assertDoesNotThrow(() -> api.activateUser("jdoe"));
        wireMock.verify(0, getRequestedFor(anyUrl()));
        wireMock.verify(0, postRequestedFor(anyUrl()));
    }

    @Test
    void deactivateUser_isNoOpMakesNoHttpCall() {
        assertDoesNotThrow(() -> api.deactivateUser("jdoe"));
        wireMock.verify(0, getRequestedFor(anyUrl()));
        wireMock.verify(0, postRequestedFor(anyUrl()));
    }

    // -------------------------------------------------------------------------
    // setEntitlement — add/remove via the same unified endpoint
    // -------------------------------------------------------------------------

    @Test
    void setEntitlement_add_postsActionAdd() {
        wireMock.stubFor(post(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("{}")));

        api.setEntitlement("jdoe", "ent-1", true);

        wireMock.verify(postRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .withRequestBody(matchingJsonPath("$.action", equalTo("add")))
                .withRequestBody(matchingJsonPath("$.userName", equalTo("jdoe")))
                .withRequestBody(matchingJsonPath("$.entitlementId", equalTo("ent-1"))));
    }

    @Test
    void setEntitlement_remove_postsActionRemove() {
        // jdoe currently has ent-1 — setEntitlement's remove path now checks current
        // entitlements first (idempotence guard), so this must be stubbed for the
        // remove POST to actually go out.
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/jdoe"))
                .willReturn(okJson("""
                        [{"requesteentId":"jdoe","entitlementId":"ent-1"}]
                        """)));
        wireMock.stubFor(post(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .willReturn(okJson("{}")));

        api.setEntitlement("jdoe", "ent-1", false);

        wireMock.verify(postRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user"))
                .withRequestBody(matchingJsonPath("$.action", equalTo("remove"))));
    }

    // Removing an entitlement jdoe was never assigned (or was already removed, e.g. by an
    // earlier PUT in the same Okta push) must not call the target at all. Without this guard,
    // Okta pushing both a profile PUT and an entitlement-governance PATCH for the same
    // revocation causes a redundant remove call (see opp-patch.md §9 Idempotence — core's
    // PATCH remove path assumes ConnectorApi.setEntitlement(..., false) is a no-op on an
    // already-absent value).
    @Test
    void setEntitlement_removeAlreadyAbsentEntitlement_isNoOp() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/user/jdoe"))
                .willReturn(okJson("""
                        [{"requesteentId":"jdoe","entitlementId":"ent-1"}]
                        """)));

        api.setEntitlement("jdoe", "ent-2", false);

        wireMock.verify(0, postRequestedFor(urlPathEqualTo("/api/v1/platform/greenplum/user")));
    }

    // -------------------------------------------------------------------------
    // getGroups — entitlement catalog
    // -------------------------------------------------------------------------

    @Test
    void getGroups_returnsCatalog() {
        wireMock.stubFor(get(urlPathEqualTo("/api/v1/platform/greenplum/groups"))
                .willReturn(okJson("""
                        [{"id":"g1","application":"Dell Data Lake - VM","schema":"s1","profile":"p1","propagationFlag":"false","configurationItem":"ddl_tst_main","status":"active"},
                         {"id":"g2","application":"Dell Data Lake - VM","schema":"s2","profile":"p2","propagationFlag":"false","configurationItem":"ddl_tst_main","status":"active"}]
                        """)));

        List<Group> groups = api.getGroups(1, 100);
        assertEquals(2, groups.size());
        assertTrue(groups.stream().anyMatch(g -> "g1".equals(g.getId())));
    }
}
