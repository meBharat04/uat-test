package com.okta.ps.scim.delldatalake.api;

import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.delldatalake.mapper.DellDataLakeMapper;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.Meta;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.utils.StandardLogger;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * In-memory ConnectorApi double for Dell Data Lake.
 * Backs the core controller tests with no network. Registered via @TestConfiguration.
 *
 * Mirrors the real connector's documented behaviors: replaceUser,
 * activateUser, and deactivateUser are all no-ops (no update/activate/
 * deactivate endpoint exists on this target), and "active" is always true
 * — there is no status concept anywhere in this target's API surface. The
 * core's deactivate-then-strip orchestration still strips entitlements via
 * setEntitlement(add=false), which IS meaningful here.
 */
public class DellDataLakeConnectorApiInMem implements ConnectorApi {

    private static final StandardLogger LOG = StandardLogger.forClass(DellDataLakeConnectorApiInMem.class);

    private final Map<String, ScimUserV2> users = new ConcurrentHashMap<>();
    private final List<Group> catalog = new ArrayList<>();

    public void seed() {
        init();

        ScimUserV2 synth1 = newUser("synth_user_1");
        ScimUserV2 synth2 = newUser("synth_user_2");
        users.put(synth1.getId(), synth1);
        users.put(synth2.getId(), synth2);

        catalog.add(newGroup("11111111-1111-1111-1111-111111111111", "ws_synth_reports_grp"));
        catalog.add(newGroup("22222222-2222-2222-2222-222222222222", "ws_synth_readonly_grp"));

        LOG.info("DellDataLakeConnectorApiInMem seeded {} users, {} catalog entries",
                users.size(), catalog.size());
    }

    @Override
    public void init() {
        LOG.info("DellDataLakeConnectorApiInMem initialized (in-memory, no real target).");
    }

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        return users.values().stream()
                .filter(u -> matches(u, filter))
                .collect(Collectors.toList());
    }

    @Override
    public ScimUserV2 getUser(String id) {
        return users.get(id);
    }

    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        String id = user.getUserName() != null ? user.getUserName() : user.getId();
        if (id == null) id = java.util.UUID.randomUUID().toString();
        user.setId(id);
        user.setExternalId(id);
        Meta m = user.getMeta() == null ? new Meta("User") : user.getMeta();
        m.setResourceType("User");
        m.setCreated(Instant.now());
        m.setLastModified(Instant.now());
        user.setMeta(m);
        user.setActive(true); // no status concept on this target; always true
        users.put(id, user);
        return user;
    }

    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        // No update endpoint exists on the real target; mirror that here.
        ScimUserV2 existing = users.get(id);
        return existing != null ? existing : user;
    }

    @Override
    public void activateUser(String id) {
        // No activate/enable endpoint exists on the real target; no-op.
    }

    @Override
    public void deactivateUser(String id) {
        // No deactivate/disable endpoint exists on the real target; no-op.
        // Entitlement stripping still happens via the core's separate
        // setEntitlement(add=false) calls, which DO have a real endpoint.
    }

    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 u = users.get(userId);
        return u == null ? List.of() : new ArrayList<>(u.getEntitlements());
    }

    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        ScimUserV2 u = users.get(userId);
        if (u == null) {
            LOG.debug("setEntitlement: user {} not found, skipping", userId);
            return;
        }
        u.getEntitlements().removeIf(e -> entitlementId.equals(e.getValue()));
        if (add) {
            String display = catalog.stream()
                    .filter(g -> entitlementId.equals(g.getId()))
                    .map(Group::getDisplayName)
                    .findFirst()
                    .orElse(entitlementId);
            UserEntitlement ue = new UserEntitlement(entitlementId, display);
            ue.setType(DellDataLakeMapper.TYPE_GROUP);
            u.getEntitlements().add(ue);
        }
    }

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        return new ArrayList<>(catalog);
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private static boolean matches(ScimUserV2 u, ScimFilter f) {
        if (f == null) return true;
        if (f.isUserNameEq()) {
            return f.getValue() != null && f.getValue().equalsIgnoreCase(u.getUserName());
        }
        return true;
    }

    private static ScimUserV2 newUser(String userName) {
        ScimUserV2 u = new ScimUserV2();
        u.setId(userName);
        u.setExternalId(userName);
        u.setUserName(userName);
        u.setActive(true);
        Meta m = new Meta("User");
        m.setCreated(Instant.now());
        m.setLastModified(Instant.now());
        u.setMeta(m);
        return u;
    }

    private static Group newGroup(String id, String displayName) {
        Group g = new Group();
        g.setId(id);
        g.setDisplayName(displayName);
        return g;
    }
}
