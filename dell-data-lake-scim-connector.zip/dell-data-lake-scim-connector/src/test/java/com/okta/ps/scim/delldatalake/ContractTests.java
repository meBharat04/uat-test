package com.okta.ps.scim.delldatalake;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.okta.ps.scim.pojos.ScimSchemas;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest(classes = DellDataLakeApplication.class)
@AutoConfigureMockMvc
@Import(ContractTestConfig.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
class ContractTests {

    private static final String SCIM_JSON = "application/scim+json";
    private static final String USER1 = "synth_user_1";
    private static final String USER2 = "synth_user_2";
    private static final String ENT_A = "11111111-1111-1111-1111-111111111111";
    private static final String ENT_B = "22222222-2222-2222-2222-222222222222";

    @Autowired private MockMvc mvc;
    @Autowired private ObjectMapper mapper;

    @Test
    void listReturnsSeededUsers() throws Exception {
        mvc.perform(get("/v2/Users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.schemas", hasItem(ScimSchemas.LIST_RESPONSE)))
                .andExpect(jsonPath("$.totalResults", is(2)))
                .andExpect(jsonPath("$.Resources[*].userName",
                        containsInAnyOrder(USER1, USER2)));
    }

    @Test
    void filterUserNameEqReturnsExactlyOne() throws Exception {
        mvc.perform(get("/v2/Users").param("filter", "userName eq \"" + USER1 + "\""))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalResults", is(1)))
                .andExpect(jsonPath("$.Resources[0].userName", is(USER1)));
    }

    @Test
    void paginationStartIndexAndCount() throws Exception {
        mvc.perform(get("/v2/Users").param("startIndex", "1").param("count", "1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.totalResults", is(2)))
                .andExpect(jsonPath("$.itemsPerPage", is(1)))
                .andExpect(jsonPath("$.Resources.length()", is(1)));
    }

    @Test
    void postCreatesNewUser() throws Exception {
        String body = """
                {
                  "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
                  "userName": "SYNTH003",
                  "active": true
                }
                """;
        mvc.perform(post("/v2/Users").contentType(SCIM_JSON).content(body))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id", is("SYNTH003")))
                .andExpect(jsonPath("$.userName", is("SYNTH003")));
    }

    @Test
    void postDuplicateActiveReturnsUniquenessError() throws Exception {
        String body = """
                {
                  "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
                  "userName": "%s",
                  "active": true
                }
                """.formatted(USER1);
        mvc.perform(post("/v2/Users").contentType(SCIM_JSON).content(body))
                .andExpect(status().isConflict())
                .andExpect(content().contentTypeCompatibleWith(SCIM_JSON))
                .andExpect(jsonPath("$.schemas", hasItem(ScimSchemas.ERROR)))
                .andExpect(jsonPath("$.status", is("409")))
                .andExpect(jsonPath("$.scimType", is("uniqueness")));
    }

    @Test
    void putEntitlementsFieldIsIgnoredNowThatPatchOwnsEntitlementReconciliation() throws Exception {
        // core 1.1.1: PUT no longer set-diffs entitlements from the request body once
        // patch.supported is true -- PATCH is the sole channel now (UserController.replace()).
        // First prove a PATCH-added entitlement survives an unrelated full-profile PUT that
        // includes a stale/different entitlements array (the exact "HR update" problem
        // scenario this closes), then confirm the PUT's own entitlements value never applied.
        String id = idOf(USER1);

        mvc.perform(patch("/v2/Users/" + id).contentType(SCIM_JSON).content(patchOp(
                        op("add", "entitlements", "[{\"value\":\"" + ENT_A + "\"}]"))))
                .andExpect(status().isOk());

        String putWithDifferentEntitlements = """
                {
                  "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
                  "userName": "%s",
                  "active": true,
                  "entitlements": [{"value": "%s"}]
                }
                """.formatted(USER1, ENT_B);
        mvc.perform(put("/v2/Users/" + id).contentType(SCIM_JSON).content(putWithDifferentEntitlements))
                .andExpect(status().isOk());

        mvc.perform(get("/v2/Users/" + id))
                .andExpect(jsonPath("$.entitlements[*].value", containsInAnyOrder(ENT_A)));
    }

    @Test
    void putDeactivateStripsEntitlementsButActiveStaysTrue() throws Exception {
        // This target has no status/active concept at all — deactivateUser is
        // a documented no-op. Only the entitlement-strip side effect (via
        // setEntitlement, which DOES have a real endpoint) is observable.
        String id = idOf(USER1);

        // Seed via PATCH, not PUT -- PUT no longer applies its entitlements field now that
        // patch.supported is true (core 1.1.1).
        mvc.perform(patch("/v2/Users/" + id).contentType(SCIM_JSON).content(patchOp(
                        op("add", "entitlements",
                                "[{\"value\":\"" + ENT_A + "\"},{\"value\":\"" + ENT_B + "\"}]"))))
                .andExpect(status().isOk());

        String deactivate = """
                {
                  "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
                  "userName": "%s",
                  "active": false
                }
                """.formatted(USER1);
        mvc.perform(put("/v2/Users/" + id).contentType(SCIM_JSON).content(deactivate))
                .andExpect(status().isOk());

        mvc.perform(get("/v2/Users/" + id))
                .andExpect(jsonPath("$.entitlements.length()", is(0)))
                .andExpect(jsonPath("$.active", is(true)));
    }

    @Test
    void putProfileIsUnchangedSinceReplaceUserIsANoOp() throws Exception {
        String id = idOf(USER1);

        String update = """
                {
                  "schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"],
                  "userName": "attempted-rename",
                  "active": true
                }
                """;
        mvc.perform(put("/v2/Users/" + id).contentType(SCIM_JSON).content(update))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userName", is(USER1)));
    }

    @Test
    void getMissingUserReturnsScimError404() throws Exception {
        mvc.perform(get("/v2/Users/DOES-NOT-EXIST"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.schemas", hasItem(ScimSchemas.ERROR)))
                .andExpect(jsonPath("$.status", is("404")))
                .andExpect(jsonPath("$.scimType", is("noTarget")));
    }

    @Test
    void postWithoutUserNameReturnsInvalidValue() throws Exception {
        String body = """
                {"schemas": ["urn:ietf:params:scim:schemas:core:2.0:User"], "active": true}
                """;
        mvc.perform(post("/v2/Users").contentType(SCIM_JSON).content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.scimType", is("invalidValue")));
    }

    @Test
    void serviceProviderConfigAdvertisesCorrectly() throws Exception {
        mvc.perform(get("/v2/ServiceProviderConfig"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.patch.supported", is(true)))
                .andExpect(jsonPath("$.patch.maxOperations", is(100)))
                .andExpect(jsonPath("$.bulk.supported", is(false)))
                .andExpect(jsonPath("$.filter.supported", is(true)));
    }

    @Test
    void patchAddsSingleEntitlementWithoutTouchingOtherFields() throws Exception {
        String id = idOf(USER1);

        mvc.perform(patch("/v2/Users/" + id).contentType(SCIM_JSON).content(patchOp(
                        op("add", "entitlements", "[{\"value\":\"" + ENT_A + "\"}]"))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.entitlements[*].value", containsInAnyOrder(ENT_A)))
                .andExpect(jsonPath("$.userName", is(USER1)));
    }

    @Test
    void patchRemovesOnlyTheTargetedEntitlementLeavingOthersIntact() throws Exception {
        String id = idOf(USER1);

        mvc.perform(patch("/v2/Users/" + id).contentType(SCIM_JSON).content(patchOp(
                        op("add", "entitlements",
                                "[{\"value\":\"" + ENT_A + "\"},{\"value\":\"" + ENT_B + "\"}]"))))
                .andExpect(status().isOk());

        mvc.perform(patch("/v2/Users/" + id).contentType(SCIM_JSON).content(patchOp(
                        op("remove", "entitlements[value eq \"" + ENT_A + "\"]", null))))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.entitlements[*].value", containsInAnyOrder(ENT_B)));
    }

    private String[] op(String op, String path, String valueJson) {
        return new String[] {op, path, valueJson};
    }

    private String patchOp(String[]... ops) {
        StringBuilder operations = new StringBuilder();
        for (int i = 0; i < ops.length; i++) {
            if (i > 0) {
                operations.append(',');
            }
            String[] o = ops[i];
            operations.append('{');
            operations.append("\"op\":\"").append(o[0]).append('"');
            if (o[1] != null) {
                operations.append(",\"path\":\"").append(o[1].replace("\"", "\\\"")).append('"');
            }
            if (o[2] != null) {
                operations.append(",\"value\":").append(o[2]);
            }
            operations.append('}');
        }
        return """
                {
                  "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                  "Operations": [%s]
                }
                """.formatted(operations);
    }

    @Test
    void entitlementsEndpointReturnsCatalog() throws Exception {
        mvc.perform(get("/v2/Entitlements"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.schemas", hasItem(ScimSchemas.LIST_RESPONSE)));
    }

    private String idOf(String userName) throws Exception {
        MvcResult result = mvc.perform(
                        get("/v2/Users").param("filter", "userName eq \"" + userName + "\""))
                .andExpect(status().isOk())
                .andReturn();
        JsonNode node = mapper.readTree(result.getResponse().getContentAsString());
        JsonNode resources = node.get("Resources");
        assertNotNull(resources);
        assertEquals(1, resources.size());
        return resources.get(0).get("id").asText();
    }
}
