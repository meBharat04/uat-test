package com.okta.ps.scim.delldatalake.mapper;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.Meta;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Bidirectional mapping between Dell Data Lake's flat JSON and SCIM domain
 * objects.
 *
 * Get Users / Get single user return a FLAT LIST OF ASSIGNMENT ROWS — one
 * row per (user, entitlement) pair, not one row per user. This target has
 * no email/display-name/active field anywhere in its captured API surface,
 * so userName is the only populatable profile attribute.
 */
public final class DellDataLakeMapper {

    public static final String TYPE_GROUP = "group";

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private DellDataLakeMapper() {}

    // -------------------------------------------------------------------------
    // target -> SCIM: users (row grouping)
    // -------------------------------------------------------------------------

    /** Groups a flat assignment-row list into one ScimUserV2 per unique requesteentId. */
    public static List<ScimUserV2> rowsToScimUsers(JsonNode rows) {
        Map<String, ScimUserV2> byUser = new LinkedHashMap<>();
        if (rows != null && rows.isArray()) {
            for (JsonNode row : rows) {
                String userName = text(row, "requesteentId");
                if (userName.isEmpty()) continue;
                ScimUserV2 user = byUser.computeIfAbsent(userName, DellDataLakeMapper::newUser);
                addEntitlementFromRow(user, row);
            }
        }
        return new ArrayList<>(byUser.values());
    }

    /** Groups assignment rows scoped to one user (get-single-user) into a ScimUserV2, or null if there are none. */
    public static ScimUserV2 rowsToSingleScimUser(String userName, JsonNode rows) {
        if (rows == null || !rows.isArray() || rows.isEmpty()) {
            return null;
        }
        ScimUserV2 user = newUser(userName);
        for (JsonNode row : rows) {
            addEntitlementFromRow(user, row);
        }
        return user;
    }

    private static void addEntitlementFromRow(ScimUserV2 user, JsonNode row) {
        String entitlementId = text(row, "entitlementId");
        if (entitlementId.isEmpty()) return;
        UserEntitlement ue = new UserEntitlement(entitlementId, entitlementId);
        ue.setType(TYPE_GROUP);
        user.getEntitlements().add(ue);
    }

    private static ScimUserV2 newUser(String userName) {
        ScimUserV2 user = new ScimUserV2();
        user.setId(userName);
        user.setExternalId(userName);
        user.setUserName(userName);
        user.setActive(true); // no status field exists on this target; always true when present
        Meta meta = new Meta("User");
        meta.setCreated(Instant.EPOCH);
        meta.setLastModified(Instant.EPOCH);
        user.setMeta(meta);
        return user;
    }

    // -------------------------------------------------------------------------
    // target -> SCIM: group catalog
    // -------------------------------------------------------------------------

    /** Maps a Get-Groups catalog entry -> Group (id=id, displayName=profile). */
    public static Group targetGroupToGroup(JsonNode node) {
        Group g = new Group();
        g.setId(text(node, "id"));
        g.setDisplayName(text(node, "profile"));
        return g;
    }

    /** Maps a Group catalog entry -> Entitlement (for entitlementCatalog()). */
    public static Entitlement groupToEntitlement(Group group) {
        Entitlement e = new Entitlement();
        e.setId(group.getId());
        e.setDisplayName(group.getDisplayName());
        e.setType(TYPE_GROUP);
        return e;
    }

    // -------------------------------------------------------------------------
    // SCIM -> target (payload builder)
    // -------------------------------------------------------------------------

    /**
     * Builds the unified write payload shared by createUser and
     * setEntitlement(add/remove) — the same target endpoint handles all
     * three, differentiated only by "action".
     *
     * requestorNtId is now mandatory on the target side (previously accepted
     * null) — mirrors userName, since the connector has no separate
     * requestor identity available from Okta.
     */
    public static Map<String, Object> writePayload(String action, String userName, String entitlementId,
                                                     String ci, String taskNumber) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("action", nvl(action));
        m.put("ci", nvl(ci));
        m.put("entitlementId", nvl(entitlementId));
        m.put("requestorNtId", nvl(userName));
        m.put("taskNumber", nvl(taskNumber));
        m.put("userName", nvl(userName));
        return m;
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    private static String text(JsonNode node, String field) {
        if (node == null) return "";
        JsonNode v = node.get(field);
        return (v == null || v.isNull()) ? "" : v.asText("");
    }

    private static String nvl(String v) {
        return v == null ? "" : v;
    }

    /** Exposed for testing: parses a JSON string into a JsonNode. */
    public static JsonNode parse(String json) {
        try {
            return OBJECT_MAPPER.readTree(json);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid JSON: " + e.getMessage(), e);
        }
    }

    /** Converts a map to a JSON string for request bodies. */
    public static String toJson(Map<String, Object> payload) {
        try {
            return OBJECT_MAPPER.writeValueAsString(payload);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to serialize payload", e);
        }
    }
}
