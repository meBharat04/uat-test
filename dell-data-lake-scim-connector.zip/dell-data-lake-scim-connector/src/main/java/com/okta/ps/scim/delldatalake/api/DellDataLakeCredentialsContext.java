package com.okta.ps.scim.delldatalake.api;

/**
 * Request-scoped holder for the target's username/password decoded from the
 * inbound Basic Authorization header.
 *
 * Okta encodes the target's real username/password as the Basic Auth
 * username/password on every incoming SCIM request (see the connector's
 * Application Notes); {@link DellDataLakeBasicAuthFilter} decodes that
 * header into this holder for the life of the request only. Nothing here is
 * ever logged or persisted — {@link #clear()} runs in the filter's
 * `finally` block on every request, including failures.
 *
 * Unlike synchro-scim's equivalent, there is no token to cache here: this
 * target has no login/token exchange at all — the decoded credential is
 * reused directly as outbound Basic Auth on every call.
 */
final class DellDataLakeCredentialsContext {

    record Credentials(String username, String password) {}

    private static final ThreadLocal<Credentials> CREDENTIALS = new ThreadLocal<>();

    private DellDataLakeCredentialsContext() {}

    static void setCredentials(String username, String password) {
        CREDENTIALS.set(new Credentials(username, password));
    }

    static Credentials getCredentials() {
        return CREDENTIALS.get();
    }

    static void clear() {
        CREDENTIALS.remove();
    }
}
