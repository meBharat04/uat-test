package com.okta.ps.scim.delldatalake.extpojos;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.okta.ps.scim.pojos.ServiceProviderConfigs;

import java.util.Map;

public class DellDataLakeServiceProviderConfigs extends ServiceProviderConfigs {

    @JsonProperty("urn:okta:schemas:scim:providerconfig:2.0")
    private Map<String, Object> customPropertiesMap;

    public DellDataLakeServiceProviderConfigs() {
        super();
        getAuthenticationSchemes().add(
                new AuthenticationScheme(
                        "httpbasic",
                        "HTTP Basic",
                        "Basic authentication via the Okta provisioning agent"));
    }

    public Map<String, Object> getCustomPropertiesMap() { return customPropertiesMap; }
    public void setCustomPropertiesMap(Map<String, Object> customPropertiesMap) { this.customPropertiesMap = customPropertiesMap; }
}
