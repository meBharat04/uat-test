package com.okta.ps.scim.delldatalake.api;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.delldatalake.mapper.DellDataLakeMapper;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import com.okta.ps.scim.utils.StandardLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

/**
 * Dell Data Lake ConnectorApi implementation.
 *
 * Auth is a per-request relay, simpler than synchro-scim's: this target has
 * no login/token exchange at all. Okta encodes the target's real
 * username/password as the Basic Auth username/password and sends
 * {@code Authorization: Basic <base64>} on every incoming SCIM request.
 * {@link DellDataLakeBasicAuthFilter} decodes that header into
 * {@link DellDataLakeCredentialsContext} for the life of the request only;
 * this class reads it from there (never from Vault/env/config) and reuses
 * the exact same decoded pair as the outbound Basic Auth header — no token
 * to obtain, nothing to cache.
 *
 * replaceUser, activateUser, and deactivateUser are documented no-ops: no
 * update, activate, or deactivate endpoint exists on this target at all.
 *
 * getUsers/getUser return a flat list of user-entitlement ASSIGNMENT rows,
 * not one row per user — {@link DellDataLakeMapper} groups them.
 */
@Component
public class DellDataLakeConnectorApi implements ConnectorApi {

    private static final StandardLogger LOG = StandardLogger.forClass(DellDataLakeConnectorApi.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Value("${delldatalake.base_url:}")
    private String baseUrl;

    @Value("${delldatalake.users_path:api/v1/platform/greenplum/user}")
    private String usersPath = "api/v1/platform/greenplum/user";

    @Value("${delldatalake.groups_path:api/v1/platform/greenplum/groups}")
    private String groupsPath = "api/v1/platform/greenplum/groups";

    @Value("${delldatalake.write_ci:CI0011}")
    private String writeCi = "CI0011";

    @Value("${delldatalake.write_task_number:IDNCreation}")
    private String writeTaskNumber = "IDNCreation";

    private final RestClient restClient = RestClient.create();

    @PostConstruct
    @Override
    public void init() {
        LOG.info("DellDataLakeConnectorApi initialized (per-request Basic Auth relay). base_url={}", baseUrl);
    }

    // -------------------------------------------------------------------------
    // getUsers — flat assignment rows, grouped by requesteentId
    // -------------------------------------------------------------------------

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        String basicAuth = currentBasicAuthHeader();
        // notFoundReturnsNull=false: a 404 on the users COLLECTION endpoint means the
        // target is unavailable/misconfigured, not "zero users exist". Conflating the two
        // (as a bare get() would) turns a paged-import failure into a silently truncated,
        // apparently-successful empty page — see Okta OPP-1123270 (unintended
        // deprovisioning from a premature/incomplete import).
        JsonNode rows = get(baseUrl + usersPath, basicAuth, false);

        List<ScimUserV2> all = DellDataLakeMapper.rowsToScimUsers(rows);
        if (filter == null) {
            return all;
        }
        List<ScimUserV2> filtered = new ArrayList<>();
        for (ScimUserV2 user : all) {
            if (matchesFilter(user, filter)) {
                filtered.add(user);
            }
        }
        return filtered;
    }

    // -------------------------------------------------------------------------
    // getUser
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 getUser(String id) {
        String basicAuth = currentBasicAuthHeader();
        JsonNode rows = get(baseUrl + usersPath + "/" + id, basicAuth);
        return DellDataLakeMapper.rowsToSingleScimUser(id, rows);
    }

    // -------------------------------------------------------------------------
    // getEntitlements — delegates to getUser
    // -------------------------------------------------------------------------

    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 user = getUser(userId);
        return user == null ? List.of() : new ArrayList<>(user.getEntitlements());
    }

    // -------------------------------------------------------------------------
    // createUser — no distinct create-account endpoint; action:"add" for
    // the first entitlement creates the account as a side effect
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        String basicAuth = currentBasicAuthHeader();
        String userName = user.getUserName() != null ? user.getUserName() : user.getId();
        // This target has no separate account ID — id/externalId are the userName itself
        // (same convention as DellDataLakeMapper.newUser()). Okta's provisioning agent
        // requires a populated id on the returned object; without this, createNewUser
        // fails with "Unable to find the id in the returned user scim object" even
        // though the target-side write(s) below succeed.
        user.setId(userName);

        List<UserEntitlement> entitlements = user.getEntitlements();
        if (entitlements == null || entitlements.isEmpty()) {
            LOG.debug("createUser: no entitlement supplied for {}; this target requires one to create an account", userName);
            return user;
        }

        for (UserEntitlement ue : entitlements) {
            if (ue == null || ue.getValue() == null) continue;
            Map<String, Object> payload = DellDataLakeMapper.writePayload("add", userName, ue.getValue(), writeCi, writeTaskNumber);
            LOG.info("createUser userName={} entitlementId={}", userName, ue.getValue());
            postJson(baseUrl + usersPath, payload, basicAuth);
        }
        return user;
    }

    // -------------------------------------------------------------------------
    // replaceUser / activateUser / deactivateUser — documented no-ops, no
    // update/activate/deactivate endpoint exists on this target
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        LOG.debug("replaceUser: no update endpoint exists on the Dell Data Lake target; returning current user unchanged. id={}", id);
        return getUser(id);
    }

    @Override
    public void activateUser(String id) {
        LOG.debug("activateUser: no activate/enable endpoint exists on the Dell Data Lake target; no-op. id={}", id);
    }

    @Override
    public void deactivateUser(String id) {
        LOG.debug("deactivateUser: no deactivate/disable endpoint exists on the Dell Data Lake target; no-op. id={}", id);
    }

    // -------------------------------------------------------------------------
    // setEntitlement — add/remove, same unified endpoint as createUser
    // -------------------------------------------------------------------------

    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        if (!add) {
            // Removing an already-absent entitlement must be a no-op (core's PATCH remove
            // path assumes this — see UserController's opp-patch.md §9 Idempotence comment).
            // Without this check, a redundant remove (e.g. Okta pushing both a profile PUT
            // and an entitlement-governance PATCH for the same revocation) posts a second
            // "remove" action for an entitlement the target no longer has.
            boolean currentlyAssigned = getEntitlements(userId).stream()
                    .anyMatch(ent -> entitlementId.equals(ent.getValue()));
            if (!currentlyAssigned) {
                LOG.debug("setEntitlement: '{}' already absent for userId={} — no-op", entitlementId, userId);
                return;
            }
        }
        String basicAuth = currentBasicAuthHeader();
        Map<String, Object> payload = DellDataLakeMapper.writePayload(
                add ? "add" : "remove", userId, entitlementId, writeCi, writeTaskNumber);
        LOG.info("setEntitlement userId={} entitlementId={} add={}", userId, entitlementId, add);
        postJson(baseUrl + usersPath, payload, basicAuth);
    }

    // -------------------------------------------------------------------------
    // getGroups — entitlement catalog
    // -------------------------------------------------------------------------

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        String basicAuth = currentBasicAuthHeader();
        JsonNode response = get(baseUrl + groupsPath, basicAuth);

        List<Group> all = new ArrayList<>();
        if (response != null && response.isArray()) {
            for (JsonNode node : response) {
                all.add(DellDataLakeMapper.targetGroupToGroup(node));
            }
        }
        return all;
    }

    // -------------------------------------------------------------------------
    // Per-request auth
    // -------------------------------------------------------------------------

    /** Returns the "Basic <base64>" header value built from this request's decoded credentials. */
    private String currentBasicAuthHeader() {
        DellDataLakeCredentialsContext.Credentials creds = DellDataLakeCredentialsContext.getCredentials();
        if (creds == null) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, "invalidValue",
                    "Missing Basic Authorization header with Dell Data Lake credentials");
        }
        String pair = creds.username() + ":" + creds.password();
        return "Basic " + Base64.getEncoder().encodeToString(pair.getBytes(StandardCharsets.UTF_8));
    }

    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------

    private JsonNode get(String url, String basicAuthHeader) {
        return get(url, basicAuthHeader, true);
    }

     /**
     * @param notFoundReturnsNull whether a 404 should be treated as "resource genuinely
     *                            absent" (single-resource GETs, e.g. getUser) vs. an error
     *                            to propagate (collection GETs, e.g. getUsers — see caller).
     */
    private JsonNode get(String url, String basicAuthHeader, boolean notFoundReturnsNull) {
        LOG.info("Dell Data Lake request: GET {}", url);
        try {
            ResponseEntity<String> response = restClient.get()
                    .uri(url)
                    .header(HttpHeaders.AUTHORIZATION, basicAuthHeader)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .toEntity(String.class);
            LOG.info("Dell Data Lake response: GET {} -> status={} body={}", url, response.getStatusCode().value(), response.getBody());
            return parseBody(response.getBody());
        } catch (HttpClientErrorException e) {
            LOG.info("Dell Data Lake response: GET {} -> status={} body={}", url, e.getStatusCode().value(), e.getResponseBodyAsString());
            if (notFoundReturnsNull && e.getStatusCode() == HttpStatus.NOT_FOUND) {
                return null;
            }
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        } catch (HttpServerErrorException e) {
            LOG.info("Dell Data Lake response: GET {} -> status={} body={}", url, e.getStatusCode().value(), e.getResponseBodyAsString());
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        }
    }

    private JsonNode postJson(String url, Map<String, Object> payload, String basicAuthHeader) {
        String requestBody = DellDataLakeMapper.toJson(payload);
        LOG.info("Dell Data Lake request: POST {} body={}", url, requestBody);
        try {
            ResponseEntity<String> response = restClient.method(HttpMethod.POST)
                    .uri(url)
                    .header(HttpHeaders.AUTHORIZATION, basicAuthHeader)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(requestBody)
                    .retrieve()
                    .toEntity(String.class);
            LOG.info("Dell Data Lake response: POST {} -> status={} body={}", url, response.getStatusCode().value(), response.getBody());
            return parseBody(response.getBody());
        } catch (HttpClientErrorException e) {
            LOG.info("Dell Data Lake response: POST {} -> status={} body={}", url, e.getStatusCode().value(), e.getResponseBodyAsString());
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        } catch (HttpServerErrorException e) {
            LOG.info("Dell Data Lake response: POST {} -> status={} body={}", url, e.getStatusCode().value(), e.getResponseBodyAsString());
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        }
    }

    private JsonNode parseBody(String body) {
        if (body == null || body.isBlank()) return null;
        try {
            return OBJECT_MAPPER.readTree(body);
        } catch (Exception e) {
            LOG.debug("Non-JSON response body: {}", body);
            return null;
        }
    }

    private static ScimErrorException toScimError(int status, String detail) {
        return new ScimErrorException(
                HttpStatus.valueOf(status),
                status == 404 ? "invalidValue" : "invalidSyntax",
                "Dell Data Lake API error " + status + ": " + detail);
    }

    private static boolean matchesFilter(ScimUserV2 user, ScimFilter filter) {
        if (filter == null) return true;
        if (filter.isUserNameEq()) {
            return filter.getValue() != null && filter.getValue().equalsIgnoreCase(user.getUserName());
        }
        return true;
    }

    // Package-private for test injection
    void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    void setWriteCi(String ci) { this.writeCi = ci; }
    void setWriteTaskNumber(String taskNumber) { this.writeTaskNumber = taskNumber; }
}
