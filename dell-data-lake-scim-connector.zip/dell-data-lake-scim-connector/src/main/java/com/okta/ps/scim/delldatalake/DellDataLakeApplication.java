package com.okta.ps.scim.delldatalake;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * Boot class for the Dell Data Lake connector WAR.
 * The connector package (com.okta.ps.scim.delldatalake) is a subpackage of
 * core's own (com.okta.ps.scim), so a single base package covers both.
 */
@SpringBootApplication(scanBasePackages = "com.okta.ps.scim")
public class DellDataLakeApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(DellDataLakeApplication.class, args);
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(DellDataLakeApplication.class);
    }
}
