package com.okta.ps.scim.delldatalake.api;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Decodes the inbound Basic Authorization header (Okta encodes the target's
 * real username/password as the Basic Auth username/password) into
 * {@link DellDataLakeCredentialsContext} for the life of this request only.
 *
 * Deliberately does not reject requests with a missing/malformed header —
 * the discovery endpoints (ServiceProviderConfig/ResourceTypes/Schemas)
 * don't need target credentials at all. Only an outbound call that actually
 * needs them (see DellDataLakeConnectorApi.currentCredentials) fails if
 * they're absent.
 */
@Component
public class DellDataLakeBasicAuthFilter extends OncePerRequestFilter {

    private static final String BASIC_PREFIX = "Basic ";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        try {
            String header = request.getHeader("Authorization");
            if (header != null && header.startsWith(BASIC_PREFIX)) {
                decodeAndStore(header.substring(BASIC_PREFIX.length()));
            }
            filterChain.doFilter(request, response);
        } finally {
            DellDataLakeCredentialsContext.clear();
        }
    }

    private static void decodeAndStore(String base64Credentials) {
        try {
            byte[] decoded = Base64.getDecoder().decode(base64Credentials.trim());
            String pair = new String(decoded, StandardCharsets.UTF_8);
            int colon = pair.indexOf(':');
            if (colon < 0) {
                return;
            }
            String username = pair.substring(0, colon);
            String password = pair.substring(colon + 1);
            DellDataLakeCredentialsContext.setCredentials(username, password);
        } catch (IllegalArgumentException ex) {
            // Malformed Base64 — leave credentials unset; an outbound call
            // that needs them will surface a clear 401 rather than this
            // filter silently guessing or logging the raw header value.
        }
    }
}
