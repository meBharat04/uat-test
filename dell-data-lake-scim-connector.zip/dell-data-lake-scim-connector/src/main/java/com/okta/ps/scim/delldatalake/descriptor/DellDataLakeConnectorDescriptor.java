package com.okta.ps.scim.delldatalake.descriptor;

import com.okta.ps.scim.delldatalake.extpojos.DellDataLakeResourceType;
import com.okta.ps.scim.delldatalake.extpojos.DellDataLakeServiceProviderConfigs;
import com.okta.ps.scim.delldatalake.mapper.DellDataLakeMapper;
import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.api.ConnectorDescriptor;
import com.okta.ps.scim.pojos.Entitlement;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.Meta;
import com.okta.ps.scim.pojos.ScimResource;
import com.okta.ps.scim.pojos.ScimSchema;
import com.okta.ps.scim.pojos.ScimSchemas;
import com.okta.ps.scim.pojos.SchemaAttribute;
import com.okta.ps.scim.pojos.ServiceProviderConfigs;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Advertises exactly the capabilities implemented for Dell Data Lake — see
 * scim_advertisement in framework/specs/dell-data-lake.yaml.
 * <p>
 * Capabilities: IMPORT_NEW_USERS, IMPORT_PROFILE_UPDATES, PUSH_NEW_USERS,
 * PUSH_PROFILE_UPDATES, OPP_SCIM_INCREMENTAL_IMPORTS.
 * <p>
 * patch: true (Okta entitlements-access PATCH support — core 1.1.0's
 * {@code UserController.patch()} dispatches entitlement add/remove/replace
 * ops onto {@code ConnectorApi.setEntitlement}, which this connector already
 * implements as a single-entitlement POST; this avoids the full-profile-PUT
 * entitlement diff on every unrelated attribute update).
 * <p>
 * PUSH_PROFILE_UPDATES is advertised solely so Okta renders the "Update
 * User Attributes" provisioning toggle (matching SynchroConnectorDescriptor,
 * which does the same for the same reason) — Dell Data Lake has no
 * profile-update endpoint, so {@code replaceUser} remains a documented
 * no-op regardless of this toggle's state; entitlements stay owned by
 * PATCH either way.
 * <p>
 * NEVER advertised: bulk, changePassword (no such endpoints exist);
 * PUSH_USER_DEACTIVATION / REACTIVATE_USERS (no activate/deactivate
 * endpoint exists on this target at all). No Group resource type — group
 * membership is modeled as OIG Entitlements.
 */
@Component
public class DellDataLakeConnectorDescriptor implements ConnectorDescriptor {

    private final ConnectorApi connectorApi;

    @Autowired
    public DellDataLakeConnectorDescriptor(ConnectorApi connectorApi) {
        this.connectorApi = connectorApi;
    }

    @Override
    public ServiceProviderConfigs serviceProviderConfig() {
        DellDataLakeServiceProviderConfigs cfg = new DellDataLakeServiceProviderConfigs();
        cfg.getSchemas().add("urn:okta:schemas:scim:providerconfig:2.0");
        cfg.setPatch(new ServiceProviderConfigs.Patch(true, ServiceProviderConfigs.Patch.DEFAULT_MAX_OPERATIONS));
        cfg.setBulk(new ServiceProviderConfigs.Bulk(false, 0, 0));
        cfg.setFilter(new ServiceProviderConfigs.FilterFeature(true, 200));
        cfg.setChangePassword(new ServiceProviderConfigs.Supported(false));
        cfg.setSort(new ServiceProviderConfigs.Supported(false));
        cfg.setEtag(new ServiceProviderConfigs.Supported(false));
        cfg.setCustomPropertiesMap(Map.of("userManagementCapabilities", List.of(
                "IMPORT_NEW_USERS", "IMPORT_PROFILE_UPDATES",
                "PUSH_NEW_USERS", "PUSH_PROFILE_UPDATES", "OPP_SCIM_INCREMENTAL_IMPORTS")));
        return cfg;
    }

    @Override
    public List<ScimResource> resourceTypes() {
        DellDataLakeResourceType user = new DellDataLakeResourceType();
        user.getSchemas().clear();
        user.getSchemas().add(ScimSchemas.RESOURCE_TYPE);
        user.setId("User");
        user.setName("User");
        user.setDescription("User Accounts");
        user.setSchema(ScimSchemas.USER);
        user.setEndpoint("/Users");

        DellDataLakeResourceType entitlement = new DellDataLakeResourceType();
        entitlement.getSchemas().clear();
        entitlement.getSchemas().add(ScimSchemas.RESOURCE_TYPE);
        entitlement.setId("Entitlement");
        entitlement.setName("Entitlement");
        entitlement.setDescription("Entitlements");
        entitlement.setSchema(ScimSchemas.ENTITLEMENT);
        entitlement.setEndpoint("/Entitlements");

        return List.of(user, entitlement);
    }

    @Override
    public List<ScimSchema> schemas() {
        return List.of(userSchema(), entitlementSchema());
    }

    private static ScimSchema userSchema() {
        ScimSchema s = schema(ScimSchemas.USER, "User", "User Account");
        s.setAttributes(List.of(
                attr("id", "string", false, "Unique identifier for the User. REQUIRED.", true, false,
                        "readWrite", "default", "server", null),
                attr("userName", "string", false, "Unique identifier for the User. REQUIRED.", true, false,
                        "readWrite", "default", "server", null),
                attr("active", "boolean", false, "A Boolean value indicating the User's administrative status.",
                        false, false, "readWrite", "default", null, null)));
        return s;
    }

    private static ScimSchema entitlementSchema() {
        ScimSchema s = schema(ScimSchemas.ENTITLEMENT, "Entitlements", "Entitlements");
        s.setAttributes(List.of(
                attr("entitlements", "complex", true,
                        "A list of entitlements for the User that collectively represent the groups the User belongs to.",
                        false, false, "readWrite", "default", null, List.of(
                                attr("value", "string", false,
                                        "The value of an entitlement.", false, false,
                                        "readWrite", "default", "none", null),
                                attr("display", "string", false,
                                        "A human-readable name, primarily used for display purposes. READ-ONLY.",
                                        false, false, "readWrite", "default", "none", null),
                                attr("type", "string", false,
                                        "A label indicating the attribute's function.", false, false,
                                        "readWrite", "default", "none", null)))));
        return s;
    }

    /**
     * Builds a bare {@link ScimSchema} shell (schemas urn, id, name, description, meta) with no attributes.
     */
    private static ScimSchema schema(String id, String name, String description) {
        ScimSchema s = new ScimSchema();
        s.getSchemas().clear();
        s.getSchemas().add(ScimSchemas.SCHEMA);
        s.setId(id);
        s.setName(name);
        s.setDescription(description);
        Meta meta = new Meta();
        meta.setResourceType("Schema");
        meta.setLocation("/v2/Schemas/" + id);
        s.setMeta(meta);
        return s;
    }

    /**
     * Builds one SchemaAttribute; pass {@code null} for uniqueness or subAttributes to omit them (NON_NULL).
     */
    private static SchemaAttribute attr(String name, String type, boolean multiValued,
                                        String description, boolean required, boolean caseExact,
                                        String mutability, String returned, String uniqueness,
                                        List<SchemaAttribute> subAttributes) {
        SchemaAttribute a = new SchemaAttribute();
        a.setName(name);
        a.setType(type);
        a.setMultiValued(multiValued);
        a.setDescription(description);
        a.setRequired(required);
        a.setCaseExact(caseExact);
        a.setMutability(mutability);
        a.setReturned(returned);
        a.setUniqueness(uniqueness);
        a.setSubAttributes(subAttributes);
        return a;
    }

    @Override
    public List<Entitlement> entitlementCatalog() {
        List<Entitlement> catalog = new ArrayList<>();
        try {
            for (Group g : connectorApi.getGroups(1, Integer.MAX_VALUE)) {
                catalog.add(DellDataLakeMapper.groupToEntitlement(g));
            }
        } catch (Exception ex) {
            // Catalog is best-effort; a transient target failure here must not
            // break discovery endpoints.
        }
        return catalog;
    }
}
