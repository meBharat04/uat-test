package com.okta.ps.scim.delldatalake.extpojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.okta.ps.scim.pojos.ScimResource;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class DellDataLakeResourceType extends ScimResource {
    private String name;
    private String description;
    private String schema;
    private String endpoint;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getSchema() { return schema; }
    public void setSchema(String schema) { this.schema = schema; }

    public String getEndpoint() { return endpoint; }
    public void setEndpoint(String endpoint) { this.endpoint = endpoint; }
}
