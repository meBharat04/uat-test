package com.okta.ps.scim.delldatalake.api;

import com.okta.ps.scim.utils.StandardLogger;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Logs the HTTP method on every /Users/{id} PUT and PATCH request. Without this,
 * distinguishing which verb Okta actually used for a given entitlement change requires
 * correlating Tomcat access-log timestamps against Okta's Assignment History UI -- unreliable
 * in practice since OPP is poll-based (the on-prem agent checks in periodically rather than
 * Okta pushing in real time), so the outbound call can lag the UI event by an unpredictable
 * amount. This log line is unambiguous and lands in the app's own log regardless of that delay.
 *
 * scim-connector-core is vendored here as a prebuilt jar (no UserController.java source in
 * this repo to add the equivalent log lines to directly), so this is done as a filter instead.
 */
@Component
public class DellDataLakeUserVerbLoggingFilter extends OncePerRequestFilter {

    private static final StandardLogger LOG = StandardLogger.forClass(DellDataLakeUserVerbLoggingFilter.class);
    private static final Pattern USERS_BY_ID = Pattern.compile("/Users/([^/]+)/?$");

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String method = request.getMethod();
        if ("PUT".equals(method) || "PATCH".equals(method)) {
            Matcher matcher = USERS_BY_ID.matcher(request.getRequestURI());
            if (matcher.find()) {
                LOG.info("{} /Users/{}", method, matcher.group(1));
            }
        }
        filterChain.doFilter(request, response);
    }
}
