#!/usr/bin/env bash
# Usage: ./scripts/release-core.sh <version>
# Builds scim-connector-core at the current pom version and deploys it to repo/.
set -euo pipefail
VERSION="${1:?Usage: $0 <version>}"
REPO_DIR="$(cd "$(dirname "$0")/.." && pwd)/repo"
ARTIFACT_DIR="${REPO_DIR}/com/okta/ps/scim/scim-connector-core/${VERSION}"

# On macOS the JDK must use the system keychain for trusted CA certs.
SSL_FLAG=""
[[ "$(uname)" == "Darwin" ]] && SSL_FLAG="-Djavax.net.ssl.trustStoreType=KeychainStore"

# Validate that the pom version matches the requested release version so the
# JAR filename (derived from the pom) agrees with the repo/ path we write to.
POM_VERSION="$(mvn -f scim-connector-core/pom.xml help:evaluate -Dexpression=project.version -q -DforceStdout ${SSL_FLAG})"
if [[ "${POM_VERSION}" != "${VERSION}" ]]; then
  echo "ERROR: scim-connector-core/pom.xml version is '${POM_VERSION}' but requested release version is '${VERSION}'."
  echo "       Bump the pom to '${VERSION}' before running this script."
  exit 1
fi

mvn -f scim-connector-core/pom.xml clean package -DskipTests ${SSL_FLAG}

# Deploy the jar via deploy-file (handles maven-metadata.xml and checksums for the jar).
mvn deploy:deploy-file \
  ${SSL_FLAG} \
  -Durl="file://${REPO_DIR}" \
  -DgroupId=com.okta.ps.scim \
  -DartifactId=scim-connector-core \
  -Dversion="${VERSION}" \
  -Dpackaging=jar \
  -Dfile="scim-connector-core/target/scim-connector-core-${VERSION}.jar" \
  -DgeneratePom=true

# Overwrite the deployed POM with a minimal one (no parent reference) so
# connectors resolving this artifact don't need to resolve the root pom.
# Extract Spring Boot version from the core pom to keep the dependency versions correct.
# NB: "spring-boot.version" isn't a resolvable property here (core's parent is the
# root aggregator pom, not spring-boot-starter-parent directly) - help:evaluate returns
# the literal string "null object or invalid expression" with exit code 0 for it, so a
# `|| fallback` never triggers. Walk up to the grandparent (spring-boot-starter-parent)
# instead, and only fall back if that command itself fails.
SB_VERSION="$(mvn -f scim-connector-core/pom.xml help:evaluate -Dexpression=project.parent.parent.version -q -DforceStdout ${SSL_FLAG} 2>/dev/null || echo "3.5.0")"
if [[ ! "${SB_VERSION}" =~ ^[0-9]+\.[0-9]+\.[0-9]+.*$ ]]; then
  echo "ERROR: could not resolve Spring Boot version (got '${SB_VERSION}')."
  exit 1
fi

cat > "${ARTIFACT_DIR}/scim-connector-core-${VERSION}.pom" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.okta.ps.scim</groupId>
    <artifactId>scim-connector-core</artifactId>
    <version>${VERSION}</version>
    <packaging>jar</packaging>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
            <version>${SB_VERSION}</version>
            <exclusions>
                <exclusion>
                    <groupId>org.springframework.boot</groupId>
                    <artifactId>spring-boot-starter-logging</artifactId>
                </exclusion>
            </exclusions>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-log4j2</artifactId>
            <version>${SB_VERSION}</version>
        </dependency>
    </dependencies>
</project>
EOF

# Recompute checksums for the updated POM.
if command -v md5 &>/dev/null; then
    md5 -q "${ARTIFACT_DIR}/scim-connector-core-${VERSION}.pom" > "${ARTIFACT_DIR}/scim-connector-core-${VERSION}.pom.md5"
else
    md5sum "${ARTIFACT_DIR}/scim-connector-core-${VERSION}.pom" | awk '{print $1}' > "${ARTIFACT_DIR}/scim-connector-core-${VERSION}.pom.md5"
fi
shasum -a 1 "${ARTIFACT_DIR}/scim-connector-core-${VERSION}.pom" | awk '{print $1}' > "${ARTIFACT_DIR}/scim-connector-core-${VERSION}.pom.sha1"

echo "Published com.okta.ps.scim:scim-connector-core:${VERSION} to repo/"
