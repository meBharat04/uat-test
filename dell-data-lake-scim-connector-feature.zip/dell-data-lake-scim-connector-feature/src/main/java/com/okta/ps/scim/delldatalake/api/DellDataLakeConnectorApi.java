package com.okta.ps.scim.delldatalake.api;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.okta.ps.scim.api.ConnectorApi;
import com.okta.ps.scim.delldatalake.mapper.DellDataLakeMapper;
import com.okta.ps.scim.pojos.Group;
import com.okta.ps.scim.pojos.ScimFilter;
import com.okta.ps.scim.pojos.ScimUserV2;
import com.okta.ps.scim.pojos.UserEntitlement;
import com.okta.ps.scim.scim.ScimErrorException;
import com.okta.ps.scim.utils.StandardLogger;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClient;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

/**
 * Dell Data Lake ConnectorApi implementation.
 *
 * Auth is a per-request relay, simpler than synchro-scim's: this target has
 * no login/token exchange at all. Okta encodes the target's real
 * username/password as the Basic Auth username/password and sends
 * {@code Authorization: Basic <base64>} on every incoming SCIM request.
 * {@link DellDataLakeBasicAuthFilter} decodes that header into
 * {@link DellDataLakeCredentialsContext} for the life of the request only;
 * this class reads it from there (never from Vault/env/config) and reuses
 * the exact same decoded pair as the outbound Basic Auth header — no token
 * to obtain, nothing to cache.
 *
 * replaceUser, activateUser, and deactivateUser are documented no-ops: no
 * update, activate, or deactivate endpoint exists on this target at all.
 *
 * getUsers/getUser return a flat list of user-entitlement ASSIGNMENT rows,
 * not one row per user — {@link DellDataLakeMapper} groups them.
 */
@Component
public class DellDataLakeConnectorApi implements ConnectorApi {

    private static final StandardLogger LOG = StandardLogger.forClass(DellDataLakeConnectorApi.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Value("${delldatalake.base_url:}")
    private String baseUrl;

    @Value("${delldatalake.users_path:api/v1/platform/greenplum/user}")
    private String usersPath = "api/v1/platform/greenplum/user";

    @Value("${delldatalake.groups_path:api/v1/platform/greenplum/groups}")
    private String groupsPath = "api/v1/platform/greenplum/groups";

    // Fallback only -- the normal path resolves "ci" per-entitlement from the groups/entitlement
    // catalog (see loadConfigurationItemsByEntitlementId); this applies only when an entitlement
    // is missing from the catalog or the catalog fetch fails. Confirmed against Dell's spec.
    @Value("${delldatalake.write_ci:ddl_tst_main}")
    private String writeCi = "ddl_tst_main";

    @Value("${delldatalake.write_task_number:IDNCreation}")
    private String writeTaskNumber = "IDNCreation";

    private final RestClient restClient = RestClient.create();

    @PostConstruct
    @Override
    public void init() {
        LOG.info("DellDataLakeConnectorApi initialized (per-request Basic Auth relay). base_url={}", baseUrl);
    }

    // -------------------------------------------------------------------------
    // getUsers — flat assignment rows, grouped by requesteentId
    // -------------------------------------------------------------------------

    @Override
    public List<ScimUserV2> getUsers(int startIndex, int count, ScimFilter filter) {
        String basicAuth = currentBasicAuthHeader();
        // notFoundReturnsNull=false: a 404 on the users COLLECTION endpoint means the
        // target is unavailable/misconfigured, not "zero users exist". Conflating the two
        // (as a bare get() would) turns a paged-import failure into a silently truncated,
        // apparently-successful empty page — see Okta OPP-1123270 (unintended
        // deprovisioning from a premature/incomplete import).
        JsonNode rows = get(baseUrl + usersPath, basicAuth, false);

        List<ScimUserV2> all = DellDataLakeMapper.rowsToScimUsers(rows);
        // Diagnostic for the full-import deprovisioning investigation: records exactly what the
        // target's collection endpoint returned on this call, so a reproduction can be matched
        // against this log instead of inferred after the fact.
        LOG.info("getUsers: target returned {} raw row(s) -> grouped into {} user(s) (startIndex={}, count={})",
                rows != null && rows.isArray() ? rows.size() : 0, all.size(), startIndex, count);
        if (filter == null) {
            return all;
        }
        List<ScimUserV2> filtered = new ArrayList<>();
        for (ScimUserV2 user : all) {
            if (matchesFilter(user, filter)) {
                filtered.add(user);
            }
        }
        LOG.info("getUsers: userName-eq filter value={} -> {} of {} user(s) matched",
                filter.isUserNameEq() ? filter.getValue() : "(non-userName-eq filter, no-op)",
                filtered.size(), all.size());
        return filtered;
    }

    // -------------------------------------------------------------------------
    // getUser
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 getUser(String id) {
        String basicAuth = currentBasicAuthHeader();
        JsonNode rows = get(baseUrl + usersPath + "/" + id, basicAuth);
        ScimUserV2 user = DellDataLakeMapper.rowsToSingleScimUser(id, rows);
        // Diagnostic for the full-import/push-failure investigation: records exactly what the
        // target returned for this specific id on this call.
        LOG.info("getUser id={}: target returned {} raw row(s) -> mapped user={}",
                id, rows != null && rows.isArray() ? rows.size() : 0, user != null ? "present" : "null (empty/404)");
        return user;
    }

    // -------------------------------------------------------------------------
    // getEntitlements — delegates to getUser
    // -------------------------------------------------------------------------

    @Override
    public List<UserEntitlement> getEntitlements(String userId) {
        ScimUserV2 user = getUser(userId);
        return user == null ? List.of() : new ArrayList<>(user.getEntitlements());
    }

    // -------------------------------------------------------------------------
    // createUser — no distinct create-account endpoint; action:"add" for
    // the first entitlement creates the account as a side effect
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 createUser(ScimUserV2 user) {
        String basicAuth = currentBasicAuthHeader();
        String userName = user.getUserName() != null ? user.getUserName() : user.getId();
        // This target has no separate account ID — id/externalId are the userName itself
        // (same convention as DellDataLakeMapper.newUser()). Okta's provisioning agent
        // requires a populated id on the returned object; without this, createNewUser
        // fails with "Unable to find the id in the returned user scim object" even
        // though the target-side write(s) below succeed.
        user.setId(userName);

        List<UserEntitlement> entitlements = user.getEntitlements();
        if (entitlements == null || entitlements.isEmpty()) {
            LOG.debug("createUser: no entitlement supplied for {}; this target requires one to create an account", userName);
            return user;
        }

        // "ci" is per-entitlement on the target side (confirmed against Dell's spec: the
        // entitlement catalog's own configurationItem field, not a single global constant --
        // see DellDataLakeMapper.configurationItemsByEntitlementId). Loaded once per call, not
        // once per entitlement, to avoid an extra catalog fetch per write.
        Map<String, String> configItems = loadConfigurationItemsByEntitlementId(basicAuth);
        for (UserEntitlement ue : entitlements) {
            if (ue == null || ue.getValue() == null) continue;
            String ci = configItems.getOrDefault(ue.getValue(), writeCi);
            Map<String, Object> payload = DellDataLakeMapper.writePayload("add", userName, ue.getValue(), ci, writeTaskNumber);
            LOG.info("createUser userName={} entitlementId={} ci={}", userName, ue.getValue(), ci);
            postJson(baseUrl + usersPath, payload, basicAuth);
        }
        return user;
    }

    // -------------------------------------------------------------------------
    // replaceUser / activateUser / deactivateUser — documented no-ops, no
    // update/activate/deactivate endpoint exists on this target
    // -------------------------------------------------------------------------

    @Override
    public ScimUserV2 replaceUser(String id, ScimUserV2 user) {
        LOG.debug("replaceUser: no update endpoint exists on the Dell Data Lake target; returning current user unchanged. id={}", id);
        // getUser(id) returns null whenever the target has no rows for this id yet -- including right
        // after Okta's own just-submitted write, since this target queues writes and can take minutes
        // to apply them (see DellDataLakeMapper.rowsToSingleScimUser). Okta calls replaceUser as a
        // profile-push check immediately after provisioning actions, well inside that window, so
        // returning null here is not a rare race -- it reproduces on nearly every assignment and fails
        // response serialization ("argument \"content\" is null"). Never return null: fall back to an
        // empty-but-valid user for this id so Okta gets a parseable response instead of a crash.
        ScimUserV2 current = getUser(id);
        return current != null ? current : DellDataLakeMapper.newUser(id);
    }

    @Override
    public void activateUser(String id) {
        LOG.debug("activateUser: no activate/enable endpoint exists on the Dell Data Lake target; no-op. id={}", id);
    }

    @Override
    public void deactivateUser(String id) {
        LOG.debug("deactivateUser: no deactivate/disable endpoint exists on the Dell Data Lake target; no-op. id={}", id);
    }

    // -------------------------------------------------------------------------
    // setEntitlement — add/remove, same unified endpoint as createUser
    // -------------------------------------------------------------------------

    @Override
    public void setEntitlement(String userId, String entitlementId, boolean add) {
        // Both directions must be idempotent (core's PATCH path assumes this — see
        // UserController's opp-patch.md §9 Idempotence comment). Without these checks, a
        // redundant PATCH (e.g. Okta pushing both a profile PUT and an entitlement-governance
        // PATCH for the same change, or re-running an import after a target-side change already
        // landed) posts a second "add"/"remove" action the target either already reflects or no
        // longer has.
        boolean currentlyAssigned = getEntitlements(userId).stream()
                .anyMatch(ent -> entitlementId.equals(ent.getValue()));
        if (add && currentlyAssigned) {
            LOG.debug("setEntitlement: '{}' already assigned for userId={} — no-op", entitlementId, userId);
            return;
        }
        if (!add && !currentlyAssigned) {
            LOG.debug("setEntitlement: '{}' already absent for userId={} — no-op", entitlementId, userId);
            return;
        }
        String basicAuth = currentBasicAuthHeader();
        String ci = loadConfigurationItemsByEntitlementId(basicAuth).getOrDefault(entitlementId, writeCi);
        Map<String, Object> payload = DellDataLakeMapper.writePayload(
                add ? "add" : "remove", userId, entitlementId, ci, writeTaskNumber);
        LOG.info("setEntitlement userId={} entitlementId={} add={} ci={}", userId, entitlementId, add, ci);
        postJson(baseUrl + usersPath, payload, basicAuth);
    }

    /**
     * Loads entitlementId -> configurationItem ("ci") from the groups/entitlement catalog --
     * the target's own source of truth per entitlement (see
     * DellDataLakeMapper.configurationItemsByEntitlementId). Best-effort: a catalog fetch
     * failure must not block the write itself, so this returns an empty map on any error,
     * letting the caller fall back to the configured write_ci default.
     */
    private Map<String, String> loadConfigurationItemsByEntitlementId(String basicAuth) {
        try {
            JsonNode response = get(baseUrl + groupsPath, basicAuth);
            return DellDataLakeMapper.configurationItemsByEntitlementId(response);
        } catch (Exception ex) {
            LOG.debug("loadConfigurationItemsByEntitlementId: catalog fetch failed, falling back to configured write_ci. {}", ex.getMessage());
            return Map.of();
        }
    }

    // -------------------------------------------------------------------------
    // getGroups — entitlement catalog
    // -------------------------------------------------------------------------

    @Override
    public List<Group> getGroups(int startIndex, int count) {
        String basicAuth = currentBasicAuthHeader();
        JsonNode response = get(baseUrl + groupsPath, basicAuth);

        List<Group> all = new ArrayList<>();
        if (response != null && response.isArray()) {
            for (JsonNode node : response) {
                all.add(DellDataLakeMapper.targetGroupToGroup(node));
            }
        }
        return all;
    }

    // -------------------------------------------------------------------------
    // Per-request auth
    // -------------------------------------------------------------------------

    /** Returns the "Basic <base64>" header value built from this request's decoded credentials. */
    private String currentBasicAuthHeader() {
        DellDataLakeCredentialsContext.Credentials creds = DellDataLakeCredentialsContext.getCredentials();
        if (creds == null) {
            throw new ScimErrorException(HttpStatus.UNAUTHORIZED, "invalidValue",
                    "Missing Basic Authorization header with Dell Data Lake credentials");
        }
        String pair = creds.username() + ":" + creds.password();
        return "Basic " + Base64.getEncoder().encodeToString(pair.getBytes(StandardCharsets.UTF_8));
    }

    // -------------------------------------------------------------------------
    // HTTP helpers
    // -------------------------------------------------------------------------

    private JsonNode get(String url, String basicAuthHeader) {
        return get(url, basicAuthHeader, true);
    }

    /**
     * @param notFoundReturnsNull whether a 404 should be treated as "resource genuinely
     *                            absent" (single-resource GETs, e.g. getUser) vs. an error
     *                            to propagate (collection GETs, e.g. getUsers — see caller).
     */
    private JsonNode get(String url, String basicAuthHeader, boolean notFoundReturnsNull) {
        try {
            String body = restClient.get()
                    .uri(url)
                    .header(HttpHeaders.AUTHORIZATION, basicAuthHeader)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .body(String.class);
            return parseBody(body);
        } catch (HttpClientErrorException e) {
            if (notFoundReturnsNull && e.getStatusCode() == HttpStatus.NOT_FOUND) {
                return null;
            }
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        } catch (HttpServerErrorException e) {
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        }
    }

    private JsonNode postJson(String url, Map<String, Object> payload, String basicAuthHeader) {
        try {
            String body = restClient.method(HttpMethod.POST)
                    .uri(url)
                    .header(HttpHeaders.AUTHORIZATION, basicAuthHeader)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(DellDataLakeMapper.toJson(payload))
                    .retrieve()
                    .body(String.class);
            return parseBody(body);
        } catch (HttpClientErrorException e) {
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        } catch (HttpServerErrorException e) {
            throw toScimError(e.getStatusCode().value(), e.getMessage());
        }
    }

    private JsonNode parseBody(String body) {
        if (body == null || body.isBlank()) return null;
        try {
            return OBJECT_MAPPER.readTree(body);
        } catch (Exception e) {
            LOG.debug("Non-JSON response body: {}", body);
            return null;
        }
    }

    private static ScimErrorException toScimError(int status, String detail) {
        return new ScimErrorException(
                HttpStatus.valueOf(status),
                status == 404 ? "invalidValue" : "invalidSyntax",
                "Dell Data Lake API error " + status + ": " + detail);
    }

    private static boolean matchesFilter(ScimUserV2 user, ScimFilter filter) {
        if (filter == null) return true;
        if (filter.isUserNameEq()) {
            return filter.getValue() != null && filter.getValue().equalsIgnoreCase(user.getUserName());
        }
        return true;
    }

    // Package-private for test injection
    void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    void setWriteCi(String ci) { this.writeCi = ci; }
    void setWriteTaskNumber(String taskNumber) { this.writeTaskNumber = taskNumber; }
}
